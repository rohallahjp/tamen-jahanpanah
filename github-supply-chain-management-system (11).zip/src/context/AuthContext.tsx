
import React, { createContext, useState, ReactNode } from 'react';
// FIX: Replaced '@' alias with a relative path to resolve module error.
import { Person } from '../types';

interface AuthContextType {
  currentUser: Person | null;
  isAuthenticated: boolean;
  login: (user: Person) => void;
  logout: () => void;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<Person | null>(() => {
      try {
        const item = sessionStorage.getItem('currentUser');
        return item ? JSON.parse(item) : null;
      } catch (error) {
        return null;
      }
  });

  const isAuthenticated = !!currentUser;

  const login = (user: Person) => {
    sessionStorage.setItem('currentUser', JSON.stringify(user));
    setCurrentUser(user);
  };

  const logout = () => {
    sessionStorage.removeItem('currentUser');
    setCurrentUser(null);
  };

  return (
    <AuthContext.Provider value={{ currentUser, isAuthenticated, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
