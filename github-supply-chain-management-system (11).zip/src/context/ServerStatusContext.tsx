import { createContext, useContext } from 'react';

export type ServerStatus = 'online' | 'offline' | 'checking';

interface ServerStatusContextType {
  status: ServerStatus;
}

export const ServerStatusContext = createContext<ServerStatusContextType | undefined>(undefined);

export const useServerStatus = () => {
  const context = useContext(ServerStatusContext);
  if (context === undefined) {
    throw new Error('useServerStatus must be used within a ServerStatusProvider');
  }
  return context;
};
