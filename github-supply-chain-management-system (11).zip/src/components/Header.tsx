import React, { useState, useRef, useEffect, useMemo } from 'react';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { useAuth } from '../hooks/useAuth';
// FIX: Replaced named imports from 'react-router-dom' with a namespace import to resolve module export errors.
import * as ReactRouterDOM from 'react-router-dom';
const { useNavigate, Link } = ReactRouterDOM;
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { ServerStatus } from '../context/ServerStatusContext';
import NotificationBell from './NotificationBell';

interface HeaderProps {
  onShowSidebar: () => void;
  userFullName?: string;
  userPosition?: string;
  serverStatus: ServerStatus;
}

const ServerStatusIndicator: React.FC<{ status: ServerStatus }> = ({ status }) => {
    const indicator = useMemo(() => {
        switch (status) {
            case 'online':
                return { color: 'bg-green-500', text: 'سرور متصل است. برنامه آماده استفاده می‌باشد.' };
            case 'offline':
                return { color: 'bg-red-500', text: 'خطا در اتصال به سرور! عملیات ثبت و ویرایش غیرفعال است.' };
            default:
                return { color: 'bg-yellow-500 animate-pulse', text: 'در حال بررسی اتصال...' };
        }
    }, [status]);

    return (
        <div className="group relative flex items-center gap-2" aria-label={`وضعیت سرور: ${status}`}>
            <div className={`w-3 h-3 rounded-full ${indicator.color}`} />
            <span className="text-xs text-gray-500 hidden sm:block">{status === 'online' ? 'آنلاین' : status === 'offline' ? 'آفلاین' : 'در حال بررسی'}</span>
            <div className="absolute bottom-full right-0 mb-2 w-64 hidden group-hover:block bg-gray-800 text-white text-xs rounded-lg py-2 px-3 z-50 shadow-lg text-center" role="tooltip">
                {indicator.text}
            </div>
        </div>
    );
};


const Header: React.FC<HeaderProps> = ({ onShowSidebar, userFullName, userPosition, serverStatus }) => {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [menuRef]);

  return (
    <header className="bg-white shadow-sm p-4 flex justify-between items-center sticky top-0 z-40 no-print">
      <div className="flex items-center gap-4">
        <button onClick={onShowSidebar} className="text-gray-600 hover:text-fuchsia-600">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
        <h1 className="text-xl font-bold text-gray-800 hidden sm:block">سامانه مدیریت زنجیره تامین</h1>
      </div>
      <div className="flex items-center gap-4">
        <ServerStatusIndicator status={serverStatus} />
        <NotificationBell />
        <div className="flex items-center gap-3 relative" ref={menuRef}>
            <div className="text-left">
              <p className="font-semibold text-gray-800">{userFullName || 'کاربر مهمان'}</p>
              <p className="text-xs text-gray-500">{userPosition || 'بدون سمت'}</p>
            </div>
            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="cursor-pointer">
                <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-500 ring-1 ring-gray-300">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                </div>
            </button>
            {isMenuOpen && (
                <div className="absolute top-full left-0 mt-2 w-48 bg-white rounded-md shadow-lg border z-50">
                    <Link to="/profile" onClick={() => setIsMenuOpen(false)} className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                        پروفایل من
                    </Link>
                    <button onClick={handleLogout} className="w-full text-right block px-4 py-2 text-sm text-red-600 hover:bg-gray-100">
                        خروج
                    </button>
                </div>
            )}
        </div>
      </div>
    </header>
  );
};

export default Header;