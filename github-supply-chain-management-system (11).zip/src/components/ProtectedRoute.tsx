import React from 'react';
// FIX: Using a namespace import for react-router-dom to work around module resolution issues.
import * as ReactRouterDOM from 'react-router-dom';
const { useLocation, Navigate } = ReactRouterDOM;
// FIX: Replaced '@' alias with a relative path to resolve module error.
import { useAuth } from '../hooks/useAuth';

interface ProtectedRouteProps {
  children: React.ReactNode;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children }) => {
  const { isAuthenticated } = useAuth();
  const location = useLocation();

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return <>{children}</>;
};

export default ProtectedRoute;
