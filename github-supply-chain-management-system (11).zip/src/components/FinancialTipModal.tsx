import React, { useEffect, useState } from 'react';

interface FinancialTipModalProps {
    tip: string;
    avatarSrc: string;
    onClose: () => void;
}

const defaultAvatarSvgString = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
  <circle cx="50" cy="50" r="48" fill="#e0e0e0" stroke="#bdbdbd" stroke-width="2"/>
  <path d="M50,60 C70,60 70,40 50,40 C30,40 30,60 50,60 Z" fill="#bdbdbd"/>
  <path d="M50,65 C30,65 25,85 50,85 C75,85 70,65 50,65 Z" fill="#bdbdbd"/>
</svg>`;
const DEFAULT_AVATAR_SVG = `data:image/svg+xml;base64,${btoa(defaultAvatarSvgString)}`;

const FinancialTipModal: React.FC<FinancialTipModalProps> = ({ tip, avatarSrc, onClose }) => {
    const [progress, setProgress] = useState(100);

    useEffect(() => {
        const timerDuration = 8000; // 8 seconds
        const intervalDuration = 50; // Update every 50ms for smooth animation
        
        const timer = setTimeout(() => {
            onClose();
        }, timerDuration);
        
        const interval = setInterval(() => {
            setProgress(prev => Math.max(0, prev - (100 * intervalDuration / timerDuration)));
        }, intervalDuration);

        return () => {
            clearTimeout(timer);
            clearInterval(interval);
        };
    }, [onClose]);

    return (
        <div 
            className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-[200] p-4 transition-opacity duration-300"
            role="dialog"
            aria-modal="true"
            aria-labelledby="tip-modal-title"
        >
            <div 
                className="bg-white rounded-2xl shadow-2xl w-full max-w-lg transform transition-all duration-300 scale-95 animate-scale-in"
                onClick={e => e.stopPropagation()}
            >
                <div className="p-8 text-center relative">
                    <div className="absolute top-0 right-0 p-4">
                        <button onClick={onClose} className="text-gray-400 hover:text-gray-700" aria-label="بستن">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>
                    </div>

                    <div className="flex flex-col items-center">
                        <img src={avatarSrc || DEFAULT_AVATAR_SVG} alt="Avatar" className="w-24 h-24 rounded-full border-4 border-fuchsia-200 shadow-lg mb-4" />
                        <h2 id="tip-modal-title" className="text-xl font-bold text-fuchsia-700 mb-2">نکته روز</h2>
                        <blockquote className="text-lg text-gray-700 leading-relaxed my-4">
                            <p>"{tip}"</p>
                        </blockquote>
                    </div>

                    <button
                        onClick={onClose}
                        className="mt-6 bg-fuchsia-600 text-white px-8 py-2 rounded-lg font-semibold hover:bg-fuchsia-700 transition-colors"
                    >
                        متوجه شدم
                    </button>
                </div>
                 <div className="h-1 bg-gray-200 rounded-b-2xl overflow-hidden">
                    <div 
                        className="h-full bg-fuchsia-500 transition-all duration-100 ease-linear" 
                        style={{ width: `${progress}%` }}
                    ></div>
                </div>
            </div>
        </div>
    );
};

export default FinancialTipModal;