


import React from 'react';
// FIX: Replaced '@' alias with a relative path to resolve module error.
import { ToastMessage } from '../context/ToastContext';

interface ToastContainerProps {
  toasts: ToastMessage[];
  removeToast: (id: number) => void;
}

const ICONS = {
    success: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>,
    error: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>,
    info: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>,
};

const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, removeToast }) => {
  const getColorClasses = (type: ToastMessage['type']) => {
    switch (type) {
        case 'success': return 'bg-green-100 border-green-400 text-green-800';
        case 'error': return 'bg-red-100 border-red-400 text-red-800';
        case 'info': return 'bg-blue-100 border-blue-400 text-blue-800';
        default: return '';
    }
  };

  return (
    <div className="fixed top-20 left-4 z-[100] space-y-2">
      {toasts.map(toast => (
        <div
          key={toast.id}
          className={`w-80 max-w-sm p-4 border-l-4 rounded-md shadow-lg flex items-start gap-3 animate-fade-in-right ${getColorClasses(toast.type)}`}
          role="alert"
          aria-live="assertive"
        >
          <div className="flex-shrink-0">{ICONS[toast.type]}</div>
          <div className="flex-grow text-sm font-semibold">{toast.message}</div>
          <button onClick={() => removeToast(toast.id)} className="flex-shrink-0 text-current opacity-70 hover:opacity-100 text-2xl leading-none">&times;</button>
        </div>
      ))}
    </div>
  );
};

export default ToastContainer;