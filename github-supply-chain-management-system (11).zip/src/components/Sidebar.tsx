

import React, { useState, useEffect, useMemo } from 'react';
// FIX: Replaced named imports from 'react-router-dom' with a namespace import to resolve module export errors.
import * as ReactRouterDOM from 'react-router-dom';
const { useLocation, NavLink } = ReactRouterDOM;
// FIX: Replaced '@' alias with relative paths and removed file extensions to resolve module errors.
import { usePermissions } from '../hooks/usePermissions';
import { useAuth } from '../hooks/useAuth';
import { Person } from '../types';

const ICON_PATHS = {
    DASHBOARD: "M9 17v-2a3 3 0 00-3-3H4a3 3 0 00-3 3v2h8zM14 17a3 3 0 003-3v-2a3 3 0 00-3-3h-2a3 3 0 00-3 3v2a3 3 0 003 3h2zM4 7a3 3 0 013-3h2a3 3 0 013 3v2a3 3 0 01-3 3H7a3 3 0 01-3-3V7zm12 0a3 3 0 013-3h0a3 3 0 013 3v2a3 3 0 01-3 3h0a3 3 0 01-3-3V7z",
    REPORTS: "M9 4H7a2 2 0 00-2 2v10a2 2 0 002 2h6a2 2 0 002-2V6a2 2 0 00-2-2h-1m-4 4h4m-4 4h4m-4 4h2",
    PETTY_CASH: "M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z",
    BASE_INFO: "M3 4a1 1 0 011-1h12a1 1 0 011 1v12a1 1 0 01-1 1H4a1 1 0 01-1-1V4zm2 2v2h10V6H5zm0 4v2h10v-2H5zm0 4v2h10v-2H5z",
    SECURITY: "M12 11c.64 0 1.25-.13 1.84-.36l-1.09-1.09a2.5 2.5 0 00-3.11-3.11L8.55 7.53A4.5 4.5 0 0012 11zm-1.06 2.53L12 14.59l1.06-1.06a1.5 1.5 0 012.12 0l.71.71a1.5 1.5 0 010 2.12l-5.66 5.66a1.5 1.5 0 01-2.12 0L2.34 16.2a1.5 1.5 0 010-2.12l.71-.71a1.5 1.5 0 012.12 0L6.24 14.5l1.06 1.06-3.18 3.18L3.06 17.7a3.5 3.5 0 010-4.95l5.66-5.66a3.5 3.5 0 014.95 0l1.06 1.06-1.77 1.77-1.06-1.06a1.5 1.5 0 00-2.12 0L9.94 11.47z",
    SETTINGS: "M10.325 4.317a1.75 1.75 0 012.35 2.35l-1.35 1.35a.75.75 0 01-1.06 0l-2.35-2.35a.75.75 0 010-1.06l1.35-1.35zM9 10a1 1 0 011-1h.01a1 1 0 110 2H10a1 1 0 01-1-1zm.635 5.75a1.75 1.75 0 00-2.35-2.35l-1.35-1.35a.75.75 0 00-1.06 0l-2.35 2.35a.75.75 0 000 1.06l1.35 1.35a1.75 1.75 0 002.35 2.35l1.35 1.35a.75.75 0 001.06 0l2.35-2.35a.75.75 0 000-1.06l-1.35-1.35zM17.25 4.365a1.75 1.75 0 00-2.35 2.35l1.35 1.35a.75.75 0 001.06 0l2.35-2.35a.75.75 0 000-1.06l-1.35-1.35a1.75 1.75 0 00-2.35-2.35l-1.35-1.35a.75.75 0 00-1.06 0L9.25 4.365a.75.75 0 000 1.06l1.35 1.35a1.75 1.75 0 002.35 2.35l1.35 1.35a.75.75 0 001.06 0l2.35-2.35a.75.75 0 000-1.06l-1.35-1.35z",
    HELP: "M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.79 4 4s-1.79 4-4 4-4-1.79-4-4c0-.662.108-1.29.308-1.872l-3.74-3.74A10.025 10.025 0 012 12c0 5.523 4.477 10 10 10s10-4.477 10-10S17.523 2 12 2c-2.73 0-5.216.99-7.168 2.632l3.74 3.74zM12 6a2 2 0 100 4 2 2 0 000-4z"
};

const Icon: React.FC<{ path: string; className?: string }> = ({ path, className = "h-5 w-5" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d={path} />
    </svg>
);

type ChildLink = {
    id: string;
    label: string;
    href: string;
    resource: string;
};

type PageLink = {
    id: string;
    label: string;
    href?: string;
    icon?: React.ReactNode;
    resource: string;
    children?: ChildLink[];
};

const PETTY_CASH_ROLE_ID = 15;

const getPageLinks = (currentUser: Person | null): PageLink[] => {
    const hasPettyCashRole = currentUser?.roleIds?.includes(PETTY_CASH_ROLE_ID);

    return [
        { id: 'dashboard', resource: 'DASHBOARD', label: 'داشبورد', href: '/dashboard', icon: <Icon path={ICON_PATHS.DASHBOARD} /> },
        { id: 'reports', resource: 'REPORTS', label: 'گزارش‌ها و جستجو', icon: <Icon path={ICON_PATHS.REPORTS} />, children: [
            { id: 'supply-reports', resource: 'REPORTS', label: 'گزارش درخواست‌ها', href: '/reports' },
            { id: 'invoice-explorer', resource: 'INVOICE_EXPLORER', label: 'کاوشگر اقلام فاکتور', href: '/invoice-explorer' },
        ]},
        ...(hasPettyCashRole ? [{ id: 'my-petty-cash', resource: 'PETTY_CASH', label: 'تنخواه من', href: '/my-petty-cash', icon: <Icon path={ICON_PATHS.PETTY_CASH} /> }] : []),
        { id: 'base-info', resource: 'UNITS', label: 'داده‌های پایه', icon: <Icon path={ICON_PATHS.BASE_INFO} />, children: [
            { id: 'units', resource: 'UNITS', label: 'ساختار سازمانی', href: '/units' },
            { id: 'persons', resource: 'PERSONS', label: 'مدیریت اشخاص و ذی‌نفعان', href: '/persons' },
            { id: 'projects', resource: 'PROJECTS', label: 'پروژه‌ها', href: '/projects' },
            { id: 'contracts', resource: 'CONTRACTS', label: 'مدیریت قراردادها', href: '/contracts' },
            { id: 'debit-cards', resource: 'DEBIT', label: 'کارت‌های بدهی', href: '/debit-cards' },
            { id: 'request-types', resource: 'REQUEST_TYPES', label: 'انواع درخواست', href: '/request-types' },
        ]},
        { id: 'security', resource: 'SECURITY', label: 'مدیریت سیستم امنیتی', icon: <Icon path={ICON_PATHS.SECURITY} />, children: [
            { id: 'users', resource: 'SECURITY', label: 'کاربران و امنیت', href: '/security' },
            { id: 'security-overview', resource: 'SECURITY', label: 'خلاصه وضعیت امنیتی', href: '/security-overview' },
            // FIX: The resources for "Roles" and "Audit Log" are changed to "SECURITY" to consolidate
            // permissions for this section and ensure they are visible to security administrators.
            { id: 'roles', resource: 'SECURITY', label: 'نقش‌ها', href: '/roles' },
            { id: 'audit-log', resource: 'SECURITY', label: 'گزارش رویدادها', href: '/audit-log' },
        ]},
        { id: 'settings', resource: 'WORKFLOW', label: 'پیکربندی سیستم', icon: <Icon path={ICON_PATHS.SETTINGS} />, children: [
            { id: 'workflow', resource: 'WORKFLOW', label: 'گردش‌های کاری', href: '/workflow' },
            { id: 'internal-workflows', resource: 'INTERNAL_WORKFLOWS', label: 'فرآیندهای داخلی', href: '/internal-workflows' },
            { id: 'petty-cash-management', resource: 'PETTY_CASH_MANAGEMENT', label: 'مدیریت تنخواه', href: '/petty-cash-management' },
            { id: 'appearance', resource: 'APPEARANCE', label: 'تنظیمات ظاهری', href: '/appearance' },
            { id: 'tips-management', resource: 'APPEARANCE', label: 'مدیریت نکات روز', href: '/tips-management' },
            { id: 'backup-recovery', resource: 'BACKUP', label: 'پشتیبان‌گیری', href: '/backup-recovery' },
        ]},
         { id: 'help', resource: 'DASHBOARD', label: 'راهنما', href: '/help', icon: <Icon path={ICON_PATHS.HELP} /> },
    ];
};


const NavItem: React.FC<{ link: PageLink }> = ({ link }) => {
    const location = useLocation();
    const { currentUser } = useAuth();
    const { read: canReadParent } = usePermissions(link.resource);
    const userPermissions = useMemo(() => new Set(currentUser?.permissions || []), [currentUser]);

    const permittedChildren = useMemo(() => link.children?.filter(child => {
        if (child.resource === 'PETTY_CASH_MANAGEMENT') {
            return userPermissions.has('PETTY_CASH_MANAGEMENT:read_all') || userPermissions.has('PETTY_CASH_MANAGEMENT:read_own_unit');
        }
        return userPermissions.has(`${child.resource}:read`);
    }) || [], [link.children, userPermissions]);

    const isParentActive = permittedChildren?.some(child => location.pathname.startsWith(child.href));
    const [isOpen, setIsOpen] = useState(isParentActive);

    useEffect(() => { setIsOpen(isParentActive); }, [isParentActive, location.pathname]);
    
    // For single links like Petty Cash, handle permission here as well.
    if (!canReadParent && link.resource !== 'PETTY_CASH') return null;
    // For petty cash, the link presence is already decided by role, so no further permission check needed.

    if (!link.children) {
        return (
            <NavLink to={link.href!} className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-md text-sm transition-colors text-gray-600 hover:bg-gray-100 hover:text-gray-900 ${isActive ? "bg-fuchsia-100 text-fuchsia-700 font-bold" : ""}`}>
                {link.icon}<span>{link.label}</span>
            </NavLink>
        );
    }
    
    if (permittedChildren.length === 0) return null;

    return (
        <div>
            <button onClick={() => setIsOpen(!isOpen)} className={`w-full flex items-center justify-between gap-3 px-3 py-2.5 rounded-md text-sm transition-colors ${isParentActive ? 'text-fuchsia-700 font-semibold' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'}`}>
                <div className="flex items-center gap-3">{link.icon}<span>{link.label}</span></div>
                <svg className={`h-5 w-5 transform transition-transform ${isOpen ? 'rotate-180' : ''}`} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
            </button>
            {isOpen && (
                <div className="mt-1 pr-4 pl-2 space-y-1">
                    {permittedChildren.map((child) => (
                        <NavLink key={child.id} to={child.href} className={({ isActive }) => `block px-3 py-2 rounded-md text-sm text-gray-500 hover:bg-gray-100 hover:text-gray-800 ${isActive ? "bg-fuchsia-100 text-fuchsia-700 font-bold" : ""}`}>
                            {child.label}
                        </NavLink>
                    ))}
                </div>
            )}
        </div>
    );
};

interface SidebarProps {
  isSidebarVisible: boolean;
  onHide: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isSidebarVisible, onHide }) => {
    const { currentUser } = useAuth();
    const PAGES = useMemo(() => getPageLinks(currentUser), [currentUser]);
    
    return (
        <aside className={`fixed top-0 right-0 h-full w-64 bg-white border-l border-gray-200 flex flex-col z-50 transition-transform duration-300 ease-in-out ${isSidebarVisible ? 'translate-x-0' : 'translate-x-full'} no-print`}>
            <div className="flex items-center justify-between p-4 border-b">
                <h2 className="text-xl font-bold text-fuchsia-600">پنل مدیریت</h2>
                <button onClick={onHide} className="text-gray-500 hover:text-gray-800 lg:hidden">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
            </div>
            <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
                {PAGES.map(link => <NavItem key={link.id} link={link} />)}
            </nav>
        </aside>
    );
};

export default Sidebar;
