import React from 'react';
// FIX: Add explicit types to useMutation to fix type inference issue
import { useMutation } from '@tanstack/react-query';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { backupApi } from '../../services/api';
import { useToast } from '../../hooks/useToast';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';

const BackupRecoveryPage: React.FC = () => {
    const { read: canRead, create: canCreate } = usePermissions('BACKUP');
    const toast = useToast();

    // FIX: Add explicit types to useMutation to fix type inference issue
    const backupMutation = useMutation<string, Error>({
        mutationFn: backupApi.create,
        onSuccess: (sqlContent) => {
            try {
                const blob = new Blob([sqlContent], { type: 'application/sql' });
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.style.display = 'none';
                a.href = url;

                const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
                a.download = `supply_chain_backup_${timestamp}.sql`;
                
                document.body.appendChild(a);
                a.click();
                
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
                
                toast.success('فایل پشتیبان با موفقیت ایجاد و دانلود شد.');
            } catch (error) {
                console.error("Download error:", error);
                toast.error('خطا در هنگام آماده‌سازی فایل برای دانلود.');
            }
        },
        onError: (error: Error) => {
            toast.error(`خطا در ایجاد پشتیبان: ${error.message}`);
        }
    });

    const handleCreateBackup = () => {
        backupMutation.mutate();
    };

    if (!canRead) {
        return <AccessDenied />;
    }

    return (
        <div className="space-y-8 max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold text-gray-800">پشتیبان‌گیری و بازیابی</h2>
            
            <div className="bg-white p-6 rounded-lg shadow-sm border">
                <h3 className="text-lg font-semibold text-gray-800 mb-2">پشتیبان‌گیری دستی</h3>
                <p className="text-sm text-gray-600 mb-4">
                    با کلیک بر روی دکمه زیر، یک فایل پشتیبان کامل از وضعیت فعلی پایگاه داده ایجاد و دانلود می‌شود. این فایل شامل تمام داده‌ها و ساختار جداول است. لطفاً این فایل را در مکانی امن نگهداری کنید.
                </p>
                <button
                    onClick={handleCreateBackup}
                    disabled={!canCreate || backupMutation.isPending}
                    className="bg-fuchsia-600 text-white px-6 py-2.5 rounded-lg font-semibold flex items-center gap-2 hover:bg-fuchsia-700 disabled:bg-gray-400 disabled:cursor-wait"
                >
                    {backupMutation.isPending ? (
                        <>
                            <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-white"></div>
                            <span>در حال ایجاد فایل...</span>
                        </>
                    ) : (
                        <>
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
                            </svg>
                            <span>ایجاد و دانلود فایل پشتیبان</span>
                        </>
                    )}
                </button>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm border">
                <h3 className="text-lg font-semibold text-gray-800 mb-2">پشتیبان‌گیری خودکار</h3>
                <p className="text-sm text-gray-600">
                    سیستم به صورت خودکار و روزانه یک نسخه پشتیبان از پایگاه داده تهیه می‌کند. این نسخه‌ها برای بازیابی در مواقع اضطراری توسط مدیر سیستم استفاده می‌شوند و تا ۳۰ روز نگهداری می‌گردند.
                </p>
            </div>
            
            <div className="bg-yellow-50 text-yellow-800 p-6 rounded-lg shadow-sm border border-yellow-200">
                <h3 className="text-lg font-semibold mb-2">بازیابی اطلاعات</h3>
                <p className="text-sm">
                    فرآیند بازیابی اطلاعات از یک فایل پشتیبان یک عملیات حساس است و باید توسط مدیر سیستم یا تیم فنی انجام شود. در صورت نیاز به بازیابی، لطفاً با پشتیبانی فنی تماس بگیرید و فایل پشتیبان مورد نظر را در اختیار ایشان قرار دهید.
                </p>
            </div>
        </div>
    );
};

export default BackupRecoveryPage;
