import React, { useState, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useForm, SubmitHandler } from 'react-hook-form';
// FIX: Replaced named imports from 'react-router-dom' with a namespace import to resolve module export errors.
import * as ReactRouterDOM from 'react-router-dom';
const { useLocation, useNavigate } = ReactRouterDOM;
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { PaginatedResponse, SupplyRequest, Person, RequestCategory, Workflow, InternalWorkflow } from '../../types';
import RequestDetailsModal from '../Dashboard/RequestDetailsModal';
import { formatCurrency } from '../../utils/formatters';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import { useMainLayoutContext } from '../../context/MainLayoutContext';
import { reportsApi, personsApi, requestCategoriesApi, workflowsApi, internalWorkflowsApi } from '../../services/api';
import ReportSummary from './ReportSummary';
import { useAuth } from '../../hooks/useAuth';
import { useServerStatus } from '../../context/ServerStatusContext';
import ProcessStepper from '../Dashboard/ProcessStepper';

type SearchFormData = {
  status: string;
  requestTypeId: string;
  workflowId: string;
  requesterId: string;
  requestingUnitId: string;
  dateFrom: string; 
  dateTo: string;
  amountFrom: number | '';
  amountTo: number | '';
  imprestHolderId: string;
  assigneeId?: string;
};

const ReportsPage: React.FC = () => {
    const { read: canRead } = usePermissions('REPORTS');
    const { currentUser } = useAuth();
    const queryClient = useQueryClient();
    const location = useLocation();
    const navigate = useNavigate();

    const {
        units,
        roles,
        isLoading: isContextLoading,
    } = useMainLayoutContext();

    const { status: serverStatus } = useServerStatus();
    const isServerOffline = serverStatus === 'offline';

    const { data: persons, isLoading: isPersonsLoading } = useQuery<Person[]>({ queryKey: ['persons_all'], queryFn: () => personsApi.getAllUnpaginated(), enabled: serverStatus === 'online' });
    const { data: categories, isLoading: isCategoriesLoading } = useQuery<RequestCategory[]>({ queryKey: ['requestCategories_all'], queryFn: () => requestCategoriesApi.getAllUnpaginated(), enabled: serverStatus === 'online' });
    const { data: workflows, isLoading: isWorkflowsLoading } = useQuery<Workflow[]>({ queryKey: ['workflows_all'], queryFn: () => workflowsApi.getAllUnpaginated(), enabled: serverStatus === 'online' });
    const { data: internalWorkflows, isLoading: isInternalWorkflowsLoading } = useQuery<InternalWorkflow[]>({ queryKey: ['internalWorkflows_all'], queryFn: () => internalWorkflowsApi.getAllUnpaginated(), enabled: serverStatus === 'online' });

    const [searchFilters, setSearchFilters] = useState<Partial<SearchFormData> | null>(null);
    const [viewingRequest, setViewingRequest] = useState<SupplyRequest | null>(null);
    const [page, setPage] = useState(1);
    const [expandedRowId, setExpandedRowId] = useState<string | null>(null);


    const { register, handleSubmit, reset, watch } = useForm<SearchFormData>();
    const watchedDateFrom = watch('dateFrom');
    const watchedDateTo = watch('dateTo');

    useEffect(() => {
        const prefilledFilters = location.state?.filters as Partial<SearchFormData> | undefined;
        if (prefilledFilters) {
            const defaultFilters: Partial<SearchFormData> = {
                status: '', requestTypeId: '', workflowId: '', requesterId: '', requestingUnitId: '',
                dateFrom: '', dateTo: '', amountFrom: '', amountTo: '', imprestHolderId: '',
                assigneeId: '',
            };
            const allFilters = {
                ...defaultFilters,
                ...prefilledFilters
            };
            setPage(1);
            setSearchFilters(allFilters);
            reset(allFilters);
            navigate(location.pathname, { replace: true, state: null });
        }
    }, [location, navigate, reset]);

    const { data: summaryData, isLoading: isSummaryLoading } = useQuery({
        queryKey: ['reportSummary', searchFilters, currentUser?.id],
        queryFn: () => reportsApi.getSummary({ ...searchFilters, userId: currentUser!.id }),
        enabled: !!searchFilters && !!currentUser && serverStatus === 'online',
    });

    const { data: searchResponse, isLoading: isSearchLoading } = useQuery<PaginatedResponse<SupplyRequest>>({
        queryKey: ['reportList', searchFilters, page, currentUser?.id],
        queryFn: () => reportsApi.search({ ...searchFilters, userId: currentUser!.id }, page),
        enabled: !!searchFilters && !!currentUser && serverStatus === 'online',
    });

    const onSubmit: SubmitHandler<SearchFormData> = (data) => {
        const cleanedData = Object.fromEntries(
            Object.entries(data).filter(([, value]) => value !== '' && value !== null && value !== undefined)
        ) as Partial<SearchFormData>;
        setPage(1);
        setSearchFilters(cleanedData);
    };

    const clearSearch = () => {
        const emptyFilters: SearchFormData = { status: '', requestTypeId: '', workflowId: '', requesterId: '', requestingUnitId: '', dateFrom: '', dateTo: '', amountFrom: '', amountTo: '', imprestHolderId: '', assigneeId: '' };
        reset(emptyFilters);
        setSearchFilters(null);
        setPage(1);
    };

    const getStatusBadge = (status: SupplyRequest['status']) => {
      const statusMap = { 'IN_REVIEW': { text: 'در حال بررسی', dot: 'bg-blue-500', bg: 'bg-blue-100', border: 'border-blue-300' }, 'APPROVED': { text: 'تایید نهایی', dot: 'bg-green-500', bg: 'bg-green-100', border: 'border-green-300' }, 'REJECTED': { text: 'رد شده', dot: 'bg-red-500', bg: 'bg-red-100', border: 'border-red-300' } };
      return statusMap[status] || { text: status, dot: 'bg-gray-500', bg: 'bg-gray-100', border: 'border-gray-300' };
    };
    
    if (!canRead) return <AccessDenied />;
    
    const isLoading = isContextLoading || isPersonsLoading || isCategoriesLoading || isWorkflowsLoading || isInternalWorkflowsLoading;
    if (isLoading && serverStatus !== 'offline') return <div className="flex justify-center items-center h-full"><div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div></div>;
    
    const totalPages = Math.ceil((searchResponse?.total || 0) / 20);

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-800">گزارش‌ها و جستجوی پیشرفته</h2>

            <details className="p-4 bg-white rounded-lg border shadow-sm space-y-4" open>
                <summary className="font-semibold cursor-pointer">جستجوی دستی و پیشرفته</summary>
                <form onSubmit={handleSubmit(onSubmit)} className="mt-4 pt-4 border-t space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        <div><label className="text-sm block mb-1">وضعیت</label><select {...register('status')} className="w-full border p-2 rounded text-sm bg-white"><option value="">همه</option><option value="IN_REVIEW">در حال بررسی</option><option value="APPROVED">تایید نهایی</option><option value="REJECTED">رد شده</option></select></div>
                        <div><label className="text-sm block mb-1">نوع درخواست</label><select {...register('requestTypeId')} className="w-full border p-2 rounded text-sm bg-white"><option value="">همه</option>{(categories || []).map(c => <option key={c.id} value={c.id}>{c.label}</option>)}</select></div>
                        <div><label className="text-sm block mb-1">خط فرآیند</label><select {...register('workflowId')} className="w-full border p-2 rounded text-sm bg-white"><option value="">همه</option>{(workflows || []).map(w => <option key={w.id} value={w.id}>{w.name}</option>)}</select></div>
                        <div><label className="text-sm block mb-1">درخواست‌کننده</label><select {...register('requesterId')} className="w-full border p-2 rounded text-sm bg-white"><option value="">همه</option>{(persons || []).filter(p=>p.isSystemUser).map(p => <option key={p.id} value={p.id}>{p.fullName}</option>)}</select></div>
                        <div><label className="text-sm block mb-1">واحد درخواست‌کننده</label><select {...register('requestingUnitId')} className="w-full border p-2 rounded text-sm bg-white"><option value="">همه</option>{units.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}</select></div>
                        <div><label className="text-sm block mb-1">مسئول فعلی</label><select {...register('assigneeId')} className="w-full border p-2 rounded text-sm bg-white"><option value="">همه</option>{(persons || []).filter(p=>p.isSystemUser).map(p => <option key={p.id} value={p.id}>{p.fullName}</option>)}</select></div>
                        <div>
                            <label className="text-sm block mb-1">تاریخ ثبت (از)</label>
                            <input type="date" {...register('dateFrom')} className="w-full border p-2 rounded text-sm"/>
                            {watchedDateFrom && <div className="text-sm font-semibold text-gray-700 mt-1 text-center">{new Date(watchedDateFrom).toLocaleDateString('fa-IR')}</div>}
                        </div>
                        <div>
                            <label className="text-sm block mb-1">تاریخ ثبت (تا)</label>
                            <input type="date" {...register('dateTo')} className="w-full border p-2 rounded text-sm"/>
                            {watchedDateTo && <div className="text-sm font-semibold text-gray-700 mt-1 text-center">{new Date(watchedDateTo).toLocaleDateString('fa-IR')}</div>}
                        </div>
                        <div><label className="text-sm block mb-1">مبلغ (از)</label><input type="number" {...register('amountFrom')} className="w-full border p-2 rounded text-sm"/></div>
                        <div><label className="text-sm block mb-1">مبلغ (تا)</label><input type="number" {...register('amountTo')} className="w-full border p-2 rounded text-sm"/></div>
                    </div>
                    <div className="flex justify-end items-center gap-2 pt-4 border-t">
                        <button type="button" onClick={clearSearch} className="bg-gray-200 text-gray-800 px-6 py-2 rounded-md font-semibold hover:bg-gray-300">پاک کردن</button>
                        <button type="submit" className="bg-blue-600 text-white px-6 py-2 rounded-md font-semibold hover:bg-blue-700">جستجو</button>
                    </div>
                </form>
            </details>
            
            {searchFilters && <ReportSummary summary={summaryData!} units={units} isLoading={isSummaryLoading} />}

            {searchFilters && (
                <div className="mt-6">
                    <h3 className="text-xl font-bold text-gray-800 mb-4">
                        نتایج جستجو {isSearchLoading && serverStatus !== 'offline' ? '(در حال بارگذاری...)' : ''}
                    </h3>
                     <div className="rounded-lg border border-gray-200 bg-white shadow-sm overflow-hidden">
                        <div className="overflow-x-auto">
                           <table className="w-full text-sm">
                                <thead className="bg-gray-50 text-gray-600">
                                    <tr className="text-right">
                                        <th className="p-3 w-12 text-center"></th>
                                        <th className="p-3">شماره</th>
                                        <th className="p-3">موضوع</th>
                                        <th className="p-3">درخواست‌کننده</th>
                                        <th className="p-3">مبلغ</th>
                                        <th className="p-3">تاریخ ثبت</th>
                                        <th className="p-3">وضعیت</th>
                                        <th className="p-3 text-center">عملیات</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-200">
                                {isSearchLoading && serverStatus !== 'offline' ? (
                                    <tr><td colSpan={8} className="text-center p-8"><div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500 mx-auto"></div></td></tr>
                                ) : (searchResponse?.data || []).length === 0 ? (
                                    <tr><td colSpan={8} className="text-center p-8 text-gray-500">موردی برای نمایش وجود ندارد.</td></tr>
                                ) : (
                                    (searchResponse?.data || []).map(req => {
                                        const isExpanded = expandedRowId === req.id;
                                        const statusInfo = getStatusBadge(req.status);
                                        return (
                                            <React.Fragment key={req.id}>
                                                <tr className="hover:bg-gray-50">
                                                    <td className="p-3 text-center"><button onClick={() => setExpandedRowId(isExpanded ? null : req.id)} className="text-gray-500 font-bold text-lg hover:text-blue-600 w-6 h-6 flex items-center justify-center rounded">{isExpanded ? '−' : '+'}</button></td>
                                                    <td className="p-3 font-mono text-gray-500">{req.id}</td>
                                                    <td className="p-3 font-semibold text-gray-800">{req.requestCategoryLabel}</td>
                                                    <td className="p-3">{req.requesterName}</td>
                                                    <td className="p-3 font-mono">{formatCurrency(req.amount, req.currency)}</td>
                                                    <td className="p-3">{req.submissionDate}</td>
                                                    <td className="p-3"><div className={`inline-flex items-center gap-2 px-2.5 py-1 rounded-full text-xs font-medium border ${statusInfo.bg} ${statusInfo.border}`}><span className={`h-2 w-2 rounded-full ${statusInfo.dot}`}></span><span className="text-gray-800">{statusInfo.text}</span></div></td>
                                                    <td className="p-3 text-center"><button onClick={() => setViewingRequest(req)} className="text-blue-600 hover:underline font-semibold">مشاهده جزئیات</button></td>
                                                </tr>
                                                {isExpanded && req.workflow && (
                                                    <tr className="bg-slate-50">
                                                        <td colSpan={8} className="p-0"><div className="p-4"><ProcessStepper request={req} /></div></td>
                                                    </tr>
                                                )}
                                            </React.Fragment>
                                        );
                                    })
                                )}
                                </tbody>
                            </table>
                        </div>
                        {totalPages > 1 && (
                            <div className="flex justify-between items-center p-3 border-t border-gray-200 text-sm">
                                <span className="text-gray-600">
                                    مجموع: <span className="font-semibold">{(searchResponse?.total || 0).toLocaleString('fa-IR')}</span> مورد
                                </span>
                                <div className="flex items-center gap-2">
                                    <button onClick={() => setPage(page - 1)} disabled={page === 1} className="px-3 py-1 border rounded-md bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed">قبلی</button>
                                    <span className="text-gray-700 font-mono">{page.toLocaleString('fa-IR')} / {totalPages.toLocaleString('fa-IR')}</span>
                                    <button onClick={() => setPage(page + 1)} disabled={page >= totalPages} className="px-3 py-1 border rounded-md bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed">بعدی</button>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            )}

            {viewingRequest && currentUser && (
                <RequestDetailsModal
                    requestId={viewingRequest.id}
                    onClose={() => setViewingRequest(null)}
                    onActionComplete={() => {
                        setViewingRequest(null);
                        queryClient.invalidateQueries({ queryKey: ['reportList'] });
                        queryClient.invalidateQueries({ queryKey: ['reportSummary'] });
                    }}
                    loggedInUserId={currentUser.id}
                    isServerOffline={isServerOffline}
                />
            )}
        </div>
    );
};

export default ReportsPage;