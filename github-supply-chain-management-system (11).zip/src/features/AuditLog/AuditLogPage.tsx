import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { useDebounce } from '../../hooks/useDebounce';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import { auditLogApi, personsApi } from '../../services/api';
import { AuditLogEntry, PaginatedResponse, Person } from '../../types';
import { DataTable, ColumnDef } from '../../components/DataTable';
import { RESOURCES } from '../../constants/resources';
import Modal from '../../components/Modal';

type SearchFormData = {
    personId: string;
    action: string;
    resourceType: string;
    dateFrom: string;
    dateTo: string;
};

const AuditLogPage: React.FC = () => {
    const { read: canRead } = usePermissions('AUDIT_LOG');
    const [page, setPage] = useState(1);
    const { register, handleSubmit, reset } = useForm<SearchFormData>();
    const [filters, setFilters] = useState<Partial<SearchFormData>>({});
    const [details, setDetails] = useState<any | null>(null);

    const { data: users } = useQuery<Person[]>({
        queryKey: ['system_users_for_log'],
        queryFn: () => personsApi.getAllUnpaginated({ isSystemUser: true }),
    });

    const { data: logResponse, isLoading } = useQuery<PaginatedResponse<AuditLogEntry>>({
        queryKey: ['audit_log', page, filters],
        // FIX: Replaced non-existent `getLogs` with `getAll` and passed filters correctly.
        queryFn: () => auditLogApi.getAll(page, undefined, filters),
        placeholderData: (previousData) => previousData,
    });

    const onSubmit = (data: SearchFormData) => {
        const cleanedFilters = Object.fromEntries(Object.entries(data).filter(([, v]) => v !== ''));
        setPage(1);
        setFilters(cleanedFilters);
    };

    const columns: ColumnDef<AuditLogEntry>[] = [
        { accessorKey: 'timestamp', header: 'زمان', cell: (item) => new Date(item.timestamp).toLocaleString('fa-IR') },
        { accessorKey: 'personName', header: 'کاربر' },
        { accessorKey: 'action', header: 'رویداد' },
        { accessorKey: 'resourceType', header: 'منبع', cell: (item) => (RESOURCES[item.resourceType as keyof typeof RESOURCES] || item.resourceType) },
        { accessorKey: 'resourceId', header: 'شناسه منبع' },
        { accessorKey: 'details', header: 'جزئیات', cell: (item) => (
            <button onClick={() => setDetails(item.details)} className="text-blue-600 hover:underline">مشاهده</button>
        )},
    ];

    if (!canRead) return <AccessDenied />;

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-800">گزارش رویدادهای سیستم (Audit Log)</h2>

            <form onSubmit={handleSubmit(onSubmit)} className="p-4 bg-white rounded-lg border shadow-sm grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
                <select {...register('personId')} className="w-full border p-2 rounded text-sm bg-white"><option value="">همه کاربران</option>{(users || []).map(u => <option key={u.id} value={u.id}>{u.fullName}</option>)}</select>
                <input {...register('action')} placeholder="رویداد (مثال: CREATE)" className="w-full border p-2 rounded text-sm" />
                <select {...register('resourceType')} className="w-full border p-2 rounded text-sm bg-white"><option value="">همه منابع</option>{Object.entries(RESOURCES).map(([key, label]) => <option key={key} value={key}>{label}</option>)}</select>
                <input type="date" {...register('dateFrom')} className="w-full border p-2 rounded text-sm" />
                <input type="date" {...register('dateTo')} className="w-full border p-2 rounded text-sm" />
                <div className="lg:col-span-5 flex justify-end gap-2">
                    <button type="button" onClick={() => { reset(); setFilters({}); }} className="bg-gray-200 px-4 py-2 rounded font-semibold">پاک کردن</button>
                    <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded font-semibold">جستجو</button>
                </div>
            </form>

            {isLoading ? <p>در حال بارگذاری...</p> : 
                <DataTable 
                    columns={columns}
                    data={logResponse?.data || []}
                    pagination={{ page, total: logResponse?.total || 0, itemsPerPage: 20 }}
                    onPageChange={setPage}
                />
            }

            {details && (
                <Modal title="جزئیات رویداد" onClose={() => setDetails(null)}>
                    <pre className="p-4 bg-gray-800 text-white rounded-md text-sm overflow-auto max-h-[60vh]">
                        {JSON.stringify(details, null, 2)}
                    </pre>
                </Modal>
            )}
        </div>
    );
};

export default AuditLogPage;