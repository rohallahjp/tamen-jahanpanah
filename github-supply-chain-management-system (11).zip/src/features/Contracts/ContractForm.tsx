import React, { useEffect, useMemo } from 'react';
import { useForm, useFieldArray, SubmitHandler, useWatch, Resolver } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { Contract, ContractData, ContractSchema, Person, PaymentTerm, Unit } from '../../types';
import { contractsApi, unitsApi } from '../../services/api';
import Modal from '../../components/Modal';
import { useToast } from '../../hooks/useToast';
import { formatCurrency } from '../../utils/formatters';
import { useAuth } from '../../hooks/useAuth';
import { useServerStatus } from '../../context/ServerStatusContext';

type FormData = z.infer<typeof ContractSchema>;

interface ContractFormProps {
    contract: Contract | null;
    persons: Person[];
    onClose: () => void;
}

const defaultFormValues: FormData = {
    contractNumber: '',
    contractTitle: '',
    partyId: '',
    contractAmount: 0,
    status: 'ACTIVE',
    paymentTerms: [{ id: String(Date.now()), type: 'PROGRESS_PAYMENT', description: '', percentage: 100, amount: 0, status: 'PENDING' }],
    unitIds: [],
    contractDate: undefined,
    startDate: undefined,
    endDate: undefined,
};

const ContractForm: React.FC<ContractFormProps> = ({ contract, persons, onClose }) => {
    const queryClient = useQueryClient();
    const toast = useToast();
    const { currentUser } = useAuth();
    const { status: serverStatus } = useServerStatus();
    
    const { data: units, isLoading: isLoadingUnits } = useQuery<Unit[]>({
        queryKey: ['units_all'],
        queryFn: () => unitsApi.getAllUnpaginated(),
        enabled: !!currentUser && serverStatus === 'online',
    });
    
    const { register, handleSubmit, control, watch, setValue, reset, formState: { errors } } = useForm<FormData>({
        resolver: zodResolver(ContractSchema) as unknown as Resolver<FormData>,
        defaultValues: defaultFormValues,
    });
    
    const watchedContractDate = watch('contractDate');
    const watchedStartDate = watch('startDate');
    const watchedEndDate = watch('endDate');

    const { fields, append, remove } = useFieldArray({ control, name: "paymentTerms" });
    const watchedPaymentTerms = useWatch({ control, name: "paymentTerms" });
    const watchedContractAmount = watch('contractAmount');

    useEffect(() => {
        if (contract) {
            reset({
                ...contract,
                partyId: String(contract.partyId),
                contractDate: contract.contractDate?.split('T')[0],
                startDate: contract.startDate?.split('T')[0],
                endDate: contract.endDate?.split('T')[0],
                unitIds: contract.unitIds || [],
            });
        } else {
            reset(defaultFormValues);
        }
    }, [contract, reset]);

    useEffect(() => {
        watchedPaymentTerms.forEach((term, index) => {
            const newAmount = (watchedContractAmount * (term.percentage || 0)) / 100;
            if (term.amount !== newAmount) {
                setValue(`paymentTerms.${index}.amount`, newAmount);
            }
        });
    }, [watchedContractAmount, watchedPaymentTerms, setValue]);

    const totalPercentage = useMemo(
        () => watchedPaymentTerms.reduce((sum, term) => sum + (term.percentage || 0), 0),
        [watchedPaymentTerms]
    );

    const mutation = useMutation({
        mutationFn: (data: { formData: FormData, id?: number }) => {
            const { partyId, ...rest } = data.formData;
            const finalData: ContractData = {
                ...rest,
                partyId: Number(partyId),
                paidAmount: contract?.paidAmount || 0,
            };
            return data.id ? contractsApi.update(data.id, finalData) : contractsApi.create(finalData);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['contracts'] });
            onClose();
            toast.success('قرارداد با موفقیت ذخیره شد.');
        },
        onError: (error: Error) => toast.error(`خطا: ${error.message}`),
    });
    
    const onSubmit: SubmitHandler<FormData> = (data) => {
        mutation.mutate({ formData: data, id: contract?.id });
    };

    return (
        <Modal title={contract ? 'ویرایش قرارداد' : 'ثبت قرارداد جدید'} onClose={onClose} size="4xl">
            <form onSubmit={handleSubmit(onSubmit)}>
                <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">شماره قرارداد</label>
                            <input {...register('contractNumber')} className="w-full border p-2 rounded" />
                            {errors.contractNumber && <p className="text-red-500 text-xs mt-1">{String(errors.contractNumber.message)}</p>}
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">عنوان قرارداد</label>
                            <input {...register('contractTitle')} className="w-full border p-2 rounded" />
                            {errors.contractTitle && <p className="text-red-500 text-xs mt-1">{String(errors.contractTitle.message)}</p>}
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">طرف قرارداد (ذی‌نفع)</label>
                            <select {...register('partyId')} className="w-full border p-2 rounded bg-white">
                                <option value="">...</option>
                                {persons.map(p => <option key={p.id} value={p.id}>{p.fullName}</option>)}
                            </select>
                            {errors.partyId && <p className="text-red-500 text-xs mt-1">{String(errors.partyId.message)}</p>}
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">مبلغ کل قرارداد (ریال)</label>
                            <input type="number" {...register('contractAmount', { valueAsNumber: true })} className="w-full border p-2 rounded" />
                            {errors.contractAmount && <p className="text-red-500 text-xs mt-1">{String(errors.contractAmount.message)}</p>}
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">تاریخ امضا</label>
                            <input type="date" {...register('contractDate')} className="w-full border p-2 rounded" />
                            {watchedContractDate && <div className="text-sm font-semibold text-gray-700 mt-1 text-center">{new Date(watchedContractDate).toLocaleDateString('fa-IR')}</div>}
                            {errors.contractDate && <p className="text-red-500 text-xs mt-1">{String(errors.contractDate.message)}</p>}
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">تاریخ شروع</label>
                            <input type="date" {...register('startDate')} className="w-full border p-2 rounded" />
                            {watchedStartDate && <div className="text-sm font-semibold text-gray-700 mt-1 text-center">{new Date(watchedStartDate).toLocaleDateString('fa-IR')}</div>}
                            {errors.startDate && <p className="text-red-500 text-xs mt-1">{String(errors.startDate.message)}</p>}
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">تاریخ پایان</label>
                            <input type="date" {...register('endDate')} className="w-full border p-2 rounded" />
                            {watchedEndDate && <div className="text-sm font-semibold text-gray-700 mt-1 text-center">{new Date(watchedEndDate).toLocaleDateString('fa-IR')}</div>}
                            {errors.endDate && <p className="text-red-500 text-xs mt-1">{String(errors.endDate.message)}</p>}
                        </div>
                    </div>
                    
                    <div className="pt-4 border-t">
                        <h3 className="text-md font-semibold text-gray-800 mb-2">واحدهای مرتبط (اختیاری)</h3>
                        <p className="text-xs text-gray-500 mb-3">اگر هیچ واحدی انتخاب نشود، این قرارداد برای تمام واحدها قابل مشاهده خواهد بود.</p>
                        {isLoadingUnits ? <p>در حال بارگذاری واحدها...</p> : (
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                                {(units || []).map(unit => (
                                    <label key={unit.id} className="flex items-center gap-2 p-2 border rounded-md hover:bg-gray-50 cursor-pointer">
                                        <input type="checkbox" value={unit.id} {...register('unitIds')} />
                                        <span className="text-sm">{unit.name}</span>
                                    </label>
                                ))}
                            </div>
                        )}
                        {errors.unitIds && <p className="text-red-500 text-xs mt-1">{String(errors.unitIds.message)}</p>}
                    </div>


                    <div className="pt-4 border-t">
                        <h3 className="text-md font-semibold text-gray-800 mb-2">شروط پرداخت</h3>
                        <div className="space-y-2">
                            {fields.map((field, index) => (
                                <div key={field.id} className="grid grid-cols-[1fr_1fr_100px_150px_auto] gap-2 items-center p-2 bg-gray-50 rounded">
                                    <select {...register(`paymentTerms.${index}.type`)} className="w-full border p-1.5 rounded bg-white text-xs">
                                        <option value="PREPAYMENT">پیش پرداخت</option>
                                        <option value="PROGRESS_PAYMENT">صورت وضعیت</option>
                                        <option value="RETENTION">حسن انجام کار</option>
                                        <option value="FINAL_PAYMENT">پرداخت نهایی</option>
                                    </select>
                                    
                                    <input 
                                        {...register(`paymentTerms.${index}.description`)} 
                                        placeholder="توضیحات (مثلا: صورت وضعیت اول)"
                                        className="w-full border p-1.5 rounded text-xs"
                                        disabled={(field as PaymentTerm).status !== 'PENDING'}
                                    />

                                    <input 
                                        type="number"
                                        step="0.01"
                                        {...register(`paymentTerms.${index}.percentage`, { valueAsNumber: true })} 
                                        placeholder="درصد"
                                        className="w-full border p-1.5 rounded text-xs text-center"
                                        disabled={(field as PaymentTerm).status !== 'PENDING'}
                                    />
                                    
                                    <div className="text-center border p-1.5 rounded text-xs bg-gray-100 font-mono" dir="ltr">
                                        {formatCurrency(watchedPaymentTerms[index]?.amount, 'RIAL')}
                                    </div>
                                    
                                    <button 
                                        type="button" 
                                        onClick={() => remove(index)} 
                                        className="bg-red-100 text-red-700 h-8 w-8 flex items-center justify-center rounded-md hover:bg-red-200 font-bold text-lg disabled:opacity-50 disabled:cursor-not-allowed"
                                        disabled={(field as PaymentTerm).status !== 'PENDING'}
                                        title={(field as PaymentTerm).status !== 'PENDING' ? 'امکان حذف شرط پرداخت شده یا در حال پرداخت وجود ندارد' : 'حذف'}
                                    >
                                        &times;
                                    </button>
                                </div>
                            ))}
                        </div>
                        <button 
                            type="button" 
                            onClick={() => append({ id: String(Date.now()), type: 'PROGRESS_PAYMENT', description: '', percentage: 0, amount: 0, status: 'PENDING' })} 
                            className="text-sm text-blue-600 font-semibold hover:underline mt-2"
                        >
                            + افزودن شرط پرداخت
                        </button>
                        <div className={`mt-2 text-sm font-semibold ${Math.round(totalPercentage) === 100 ? 'text-green-600' : 'text-red-600'}`}>
                            مجموع درصدها: {totalPercentage.toFixed(2)}٪
                        </div>
                        {errors.paymentTerms && <p className="text-red-500 text-xs mt-1">{String(errors.paymentTerms.message) || String((errors.paymentTerms as any).root?.message)}</p>}
                    </div>
                </div>
                <div className="flex justify-end gap-2 p-4 border-t bg-gray-50">
                    <button type="button" onClick={onClose} className="bg-gray-200 text-gray-800 px-4 py-2 rounded font-semibold">لغو</button>
                    <button type="submit" disabled={mutation.isPending} className="bg-green-500 text-white px-4 py-2 rounded disabled:bg-gray-400 font-semibold">
                        {mutation.isPending ? 'در حال ذخیره...' : 'ذخیره'}
                    </button>
                </div>
            </form>
        </Modal>
    );
};

export default ContractForm;