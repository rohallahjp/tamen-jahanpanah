import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { appearanceApi } from '../../services/api';
import { AppearanceSettings, AppearanceImage } from '../../types';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import { useToast } from '../../hooks/useToast';
import { useServerStatus } from '../../context/ServerStatusContext';

const fileToBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
});

const AppearancePage: React.FC = () => {
    const { read: canRead, update: canUpdate } = usePermissions('APPEARANCE');
    const queryClient = useQueryClient();
    const [localSettings, setLocalSettings] = useState<AppearanceSettings | null>(null);
    const [isUploading, setIsUploading] = useState(false);
    const toast = useToast();
    const { status: serverStatus } = useServerStatus();

    const { data: settings, isLoading } = useQuery<AppearanceSettings>({
        queryKey: ['appearanceSettings'],
        queryFn: appearanceApi.get,
        enabled: serverStatus === 'online',
    });

    useEffect(() => {
        if (settings) {
            const completeSettings: AppearanceSettings = {
                mode: settings.mode || 'default',
                staticImageId: settings.staticImageId !== undefined ? settings.staticImageId : null,
                images: settings.images || [],
            };
            setLocalSettings(JSON.parse(JSON.stringify(completeSettings)));
        }
    }, [settings]);

    const mutation = useMutation({
        mutationFn: (updatedSettings: AppearanceSettings) => appearanceApi.update(updatedSettings),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['appearanceSettings'] });
            toast.success('تنظیمات با موفقیت ذخیره شد.');
        },
        onError: (error: Error) => toast.error(`خطا در ذخیره سازی: ${error.message}`),
    });

    const handleModeChange = (mode: AppearanceSettings['mode']) => {
        if (localSettings) {
            setLocalSettings({ ...localSettings, mode });
        }
    };

    const handleSetStatic = (imageId: number) => {
        if (localSettings) {
            setLocalSettings({ ...localSettings, staticImageId: imageId, mode: 'static' });
        }
    };

    const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file && localSettings) {
            setIsUploading(true);
            try {
                const url = await fileToBase64(file);
                const newImage: AppearanceImage = {
                    id: Date.now(),
                    name: file.name,
                    url,
                };
                setLocalSettings({
                    ...localSettings,
                    images: [...localSettings.images, newImage],
                });
            } catch (error) {
                toast.error('خطا در بارگذاری تصویر.');
            } finally {
                setIsUploading(false);
                // Reset file input
                e.target.value = '';
            }
        }
    };
    
    const handleDeleteImage = (imageId: number) => {
        if (localSettings && window.confirm('آیا از حذف این تصویر مطمئن هستید؟')) {
            setLocalSettings({
                ...localSettings,
                images: localSettings.images.filter(img => img.id !== imageId),
                staticImageId: localSettings.staticImageId === imageId ? null : localSettings.staticImageId,
            });
        }
    };

    const handleSave = () => {
        if (localSettings) {
            mutation.mutate(localSettings);
        }
    };

    if (!canRead) return <AccessDenied />;
    if ((isLoading && serverStatus !== 'offline') || !localSettings) {
      return <div className="flex justify-center items-center h-full"><div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-fuchsia-500"></div></div>;
    }

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-800">شخصی‌سازی ظاهر صفحه ورود</h2>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-lg font-semibold text-gray-800 mb-4 border-b pb-3">حالت نمایش پس‌زمینه</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <label className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${localSettings.mode === 'default' ? 'border-fuchsia-500 bg-fuchsia-50 ring-2 ring-fuchsia-200' : 'border-gray-200 bg-white hover:border-fuchsia-300'}`}>
                        <input type="radio" name="bg-mode" value="default" checked={localSettings.mode === 'default'} onChange={() => handleModeChange('default')} className="sr-only" />
                        <h4 className="font-bold text-gray-800">حالت پیش‌فرض</h4>
                        <p className="text-sm text-gray-600 mt-1">نمایش گرادینت آبی به همراه نماد تحقیقاتی.</p>
                    </label>
                    <label className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${localSettings.mode === 'static' ? 'border-fuchsia-500 bg-fuchsia-50 ring-2 ring-fuchsia-200' : 'border-gray-200 bg-white hover:border-fuchsia-300'}`}>
                        <input type="radio" name="bg-mode" value="static" checked={localSettings.mode === 'static'} onChange={() => handleModeChange('static')} className="sr-only" />
                        <h4 className="font-bold text-gray-800">تصویر ثابت</h4>
                        <p className="text-sm text-gray-600 mt-1">نمایش یک تصویر ثابت از میان تصاویر آپلود شده.</p>
                    </label>
                    <label className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${localSettings.mode === 'slideshow' ? 'border-fuchsia-500 bg-fuchsia-50 ring-2 ring-fuchsia-200' : 'border-gray-200 bg-white hover:border-fuchsia-300'}`}>
                        <input type="radio" name="bg-mode" value="slideshow" checked={localSettings.mode === 'slideshow'} onChange={() => handleModeChange('slideshow')} className="sr-only" />
                        <h4 className="font-bold text-gray-800">اسلایدشو</h4>
                        <p className="text-sm text-gray-600 mt-1">نمایش چرخشی تمام تصاویر آپلود شده.</p>
                    </label>
                </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="flex justify-between items-center mb-4 border-b pb-3">
                    <h3 className="text-lg font-semibold text-gray-800">مدیریت تصاویر</h3>
                    <label className="bg-green-100 text-green-800 px-4 py-2 rounded-lg font-semibold text-sm cursor-pointer hover:bg-green-200">
                        {isUploading ? 'در حال بارگذاری...' : 'آپلود تصویر جدید'}
                        <input type="file" onChange={handleImageUpload} accept="image/*" className="hidden" disabled={isUploading || !canUpdate} />
                    </label>
                </div>
                {localSettings.images.length === 0 ? (
                    <p className="text-center text-gray-500 py-8">هیچ تصویری آپلود نشده است.</p>
                ) : (
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                        {localSettings.images.map(image => (
                            <div key={image.id} className={`relative group border-2 rounded-lg overflow-hidden ${localSettings.staticImageId === image.id && localSettings.mode === 'static' ? 'border-fuchsia-500 ring-2 ring-fuchsia-200' : 'border-transparent'}`}>
                                <img src={image.url} alt={image.name} className="w-full h-32 object-cover" />
                                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-2 text-white text-center">
                                    <p className="text-xs font-semibold truncate w-full mb-2">{image.name}</p>
                                    <div className="flex flex-col gap-1.5 w-full">
                                        <button onClick={() => handleSetStatic(image.id)} disabled={!canUpdate} className="bg-fuchsia-500 text-white text-xs px-2 py-1 rounded w-full hover:bg-fuchsia-600 disabled:bg-gray-400">تنظیم به عنوان ثابت</button>
                                        <button onClick={() => handleDeleteImage(image.id)} disabled={!canUpdate} className="bg-red-500 text-white text-xs px-2 py-1 rounded w-full hover:bg-red-600 disabled:bg-gray-400">حذف</button>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            <div className="flex justify-end pt-6 border-t mt-6">
                <button onClick={handleSave} disabled={!canUpdate || mutation.isPending} className="bg-fuchsia-600 text-white px-8 py-2.5 rounded-lg font-semibold hover:bg-fuchsia-700 shadow-md disabled:bg-gray-400">
                    {mutation.isPending ? 'در حال ذخیره...' : 'ذخیره تغییرات'}
                </button>
            </div>
        </div>
    );
};

export default AppearancePage;
