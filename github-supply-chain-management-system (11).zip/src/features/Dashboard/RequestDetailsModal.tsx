
import React, { useState, useMemo, useEffect } from 'react';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { SupplyRequest, Attachment } from '../../types';
import Modal from '../../components/Modal';
import ImageLightbox from '../../components/ImageLightbox';
import ProcessStepper from './ProcessStepper';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { formatCurrency } from '../../utils/formatters';
import { workflowEngineApi } from '../../services/api';
import DigitalSignatureModal from '../../components/DigitalSignatureModal';
import { useToast } from '../../hooks/useToast';
import { usePermissions } from '../../hooks/usePermissions';

interface RequestDetailsModalProps {
  requestId: string;
  onClose: () => void;
  onActionComplete: () => void;
  loggedInUserId: number;
  isServerOffline: boolean;
}

const formatDuration = (start?: string, end?: string) => {
    if (!start || !end) return '';
    const diff = new Date(end).getTime() - new Date(start).getTime();
    if (diff < 0) return '';
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
    const minutes = Math.floor((diff / 1000 / 60) % 60);
    let parts = [];
    if (days > 0) parts.push(`${days} روز`);
    if (hours > 0) parts.push(`${hours} ساعت`);
    if (minutes >= 0) parts.push(`${minutes} دقیقه`);
    if (parts.length === 0) return "کمتر از یک دقیقه";
    return parts.join(' و ');
};

const InternalReviewStepper: React.FC<{ request: SupplyRequest; }> = ({ request }) => {
    const { _internalReview, internalWorkflow } = request;
    if (!_internalReview || !internalWorkflow) return null;
    const { activeInternalStepId } = _internalReview;
    const currentStepIndex = internalWorkflow.steps.findIndex(s => s.id === activeInternalStepId);

    return (
        <div className="p-4 border border-yellow-300 bg-yellow-50 rounded-lg">
            <h4 className="font-bold text-gray-800 mb-4">فرآیند بررسی داخلی</h4>
            <div className="flex items-start justify-between w-full overflow-x-auto">
                {internalWorkflow.steps.map((step, index) => {
                    const isCompleted = currentStepIndex > index;
                    const isActive = index === currentStepIndex;
                    let circleClasses = isCompleted ? 'bg-green-500 text-white' : isActive ? 'bg-blue-600 text-white ring-4 ring-blue-200' : 'bg-gray-200 text-gray-500';
                    return (
                        <React.Fragment key={step.id}>
                            <div className="flex flex-col items-center text-center w-28 flex-shrink-0">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm transition-all duration-300 ${circleClasses}`}>{isCompleted ? '✓' : index + 1}</div>
                                <p className={`mt-2 text-xs font-semibold ${isActive ? 'text-blue-600' : 'text-gray-700'}`}>{step.name}</p>
                                <p className="text-[10px] text-gray-500 mt-1">{step.assigneeName || 'ناشناس'}</p>
                            </div>
                            {index < internalWorkflow.steps.length - 1 && <div className={`flex-1 h-0.5 mt-4 mx-1 rounded ${isCompleted ? 'bg-green-500' : 'bg-gray-200'}`} />}
                        </React.Fragment>
                    );
                })}
            </div>
            {_internalReview.initiatorComment && <div className="mt-3 pt-3 border-t text-sm"><p><span className="font-semibold">توضیح ارجاع دهنده:</span> {_internalReview.initiatorComment}</p></div>}
        </div>
    );
};

const RequestDetailsModal: React.FC<RequestDetailsModalProps> = ({ requestId, onClose, onActionComplete, loggedInUserId, isServerOffline }) => {
  const [lightbox, setLightbox] = useState<{ src: string, alt: string } | null>(null);
  const [rejectionReason, setRejectionReason] = useState("");
  const [isRejecting, setIsRejecting] = useState(false);
  const [isApproving, setIsApproving] = useState(false);
  const [approvalComment, setApprovalComment] = useState("");
  const [isReferring, setIsReferring] = useState(false);
  const [referralData, setReferralData] = useState({ workflowId: '', comment: '' });
  const [expertComment, setExpertComment] = useState('');
  const [elapsedTime, setElapsedTime] = useState('');
  const [isSigning, setIsSigning] = useState(false);
  const toast = useToast();
  const { delete: canDelete } = usePermissions('WORKFLOW');
  
  const { data: request, isLoading } = useQuery<SupplyRequest>({
      queryKey: ['supplyRequest_details', requestId],
      queryFn: () => workflowEngineApi.getRequestById(requestId),
  });

  const activeStep = request?._activeSteps?.[0];

  const totalAmountFromInvoices = useMemo(() => {
    if (!request?.invoices) return 0;
    return request.invoices.reduce((total, invoice) => {
        const invoiceSum = invoice.items?.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0) || 0;
        return total + invoiceSum;
    }, 0);
  }, [request?.invoices]);

  const requestAmount = Number(request?.amount) || 0;
  const finalAmount = requestAmount > 0 ? requestAmount : totalAmountFromInvoices;

  useEffect(() => {
    if (activeStep) {
      const updateElapsedTime = () => setElapsedTime(formatDuration(activeStep.startTimestamp, new Date().toISOString()));
      updateElapsedTime();
      const interval = setInterval(updateElapsedTime, 60000);
      return () => clearInterval(interval);
    }
  }, [activeStep]);

  const canTakeAction = request?.status === 'IN_REVIEW' && activeStep?.assigneeId === loggedInUserId && !request._internalReview;
  const canReferInternally = canTakeAction && request.canReferInternally;
  const availableInternalWorkflows = useMemo(() => request?.availableInternalWorkflows || [], [request]);
  const isUnderInternalReview = !!request?._internalReview;
  const isMyInternalTurn = isUnderInternalReview && request?._internalReview?.activeInternalAssigneeId === loggedInUserId;

  const mutationOptions = { onSuccess: (msg: string) => { toast.success(msg); onActionComplete(); }, onError: (err: Error) => toast.error(`خطا: ${err.message}`) };

  const approveMutation = useMutation({ mutationFn: (data: { requestId: string; stepId: number; userId: number; comment?: string }) => workflowEngineApi.approveStep(data.requestId, data.stepId, data.userId, data.comment), ...mutationOptions, onSuccess: () => mutationOptions.onSuccess("درخواست تایید شد.") });
  const rejectMutation = useMutation({ mutationFn: (data: { requestId: string; stepId: number; userId: number; comment: string }) => workflowEngineApi.rejectRequest(data.requestId, data.stepId, data.userId, data.comment), ...mutationOptions, onSuccess: () => mutationOptions.onSuccess("درخواست رد شد.") });
  const startInternalReviewMutation = useMutation({ mutationFn: (data: { requestId: string; stepId: number; userId: number; internalWorkflowId: number; comment?: string }) => workflowEngineApi.startInternalReview(data.requestId, data.stepId, data.userId, data.internalWorkflowId, data.comment), ...mutationOptions, onSuccess: () => mutationOptions.onSuccess("درخواست به واحد داخلی ارجاع شد.") });
  const advanceInternalReviewMutation = useMutation({ mutationFn: (data: { requestId: string; internalStepId: number; userId: number; comment?: string }) => workflowEngineApi.advanceInternalReview(data.requestId, data.internalStepId, data.userId, 'FORWARD', data.comment), ...mutationOptions, onSuccess: () => mutationOptions.onSuccess("نظر شما در فرآیند داخلی ثبت شد و به مدیر بازگردانده شد.") });
  const deleteMutation = useMutation({
    mutationFn: (id: string) => workflowEngineApi.deleteRequest(id),
    onSuccess: () => {
        toast.success("درخواست با موفقیت حذف شد.");
        onActionComplete();
    },
    onError: (err: Error) => toast.error(`خطا در حذف: ${err.message}`),
  });

  const handleConfirmReject = () => { if (request && rejectionReason.trim() && activeStep) rejectMutation.mutate({ requestId: request.id, stepId: activeStep.stepId, userId: loggedInUserId, comment: rejectionReason }); };
  const handleConfirmApprove = () => { if (request && activeStep) approveMutation.mutate({ requestId: request.id, stepId: activeStep.stepId, userId: loggedInUserId, comment: approvalComment.trim() || undefined }); };
  const handleStartInternalReview = () => { if (request && referralData.workflowId && activeStep) startInternalReviewMutation.mutate({ requestId: request.id, stepId: activeStep.stepId, userId: loggedInUserId, internalWorkflowId: Number(referralData.workflowId), comment: referralData.comment }); else toast.error("لطفا یک فرآیند داخلی انتخاب کنید."); };
  const handleInternalReviewAction = () => { if (request?._internalReview) advanceInternalReviewMutation.mutate({ requestId: request.id, internalStepId: request._internalReview.activeInternalStepId, userId: loggedInUserId, comment: expertComment || undefined }); };
  const handleDelete = () => {
    if (request && window.confirm(`آیا از حذف درخواست شماره ${request.id} مطمئن هستید؟ این عمل غیرقابل بازگشت است.`)) {
        deleteMutation.mutate(request.id);
    }
  };
  
  const DetailItem: React.FC<{ label: string, value?: React.ReactNode, fullWidth?: boolean }> = ({ label, value, fullWidth = false }) => value ? (<div className={fullWidth ? 'col-span-2 md:col-span-4' : ''}><p className="text-xs text-gray-500">{label}</p><p className="font-semibold text-gray-800 break-words">{value}</p></div>) : null;

  const renderDueDateInfo = () => {
    if (!request?.dueDate) return null;
    const dueDate = new Date(request.dueDate);
    const now = new Date();
    const diffTime = dueDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    let statusText = '';
    let statusColor = 'text-gray-800';
    if (request.status === 'IN_REVIEW') {
         if (diffDays > 0) {
            statusText = `(${diffDays} روز باقی مانده)`;
            statusColor = 'text-green-600';
        } else if (diffDays === 0) {
            statusText = '(امروز)';
            statusColor = 'text-yellow-600';
        } else {
            statusText = `(${Math.abs(diffDays)} روز تاخیر)`;
            statusColor = 'text-red-600';
        }
    }
    return (
        <span>
            {dueDate.toLocaleDateString('fa-IR')} <span className={`text-xs font-semibold ${statusColor}`}>{statusText}</span>
        </span>
    );
  };

  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="flex justify-center items-center h-96">
            <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      );
    }

    if (!request) {
        return <div className="p-8 text-center text-red-600">خطا: اطلاعات درخواست یافت نشد.</div>;
    }

    return (
      <div className="space-y-6 printable-area">
          <div className="p-6 border-b"><ProcessStepper request={request} /></div>
          <div className="p-6 space-y-6">
            {isUnderInternalReview && <InternalReviewStepper request={request} />}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-x-6 gap-y-4">
                <DetailItem label="عنوان درخواست" value={request.requestCategoryLabel} />
                <DetailItem label="مبلغ کل" value={<span className="font-mono">{formatCurrency(finalAmount > 0 ? finalAmount : undefined, request.currency)}</span>} />
                <DetailItem label="درخواست کننده" value={request.requesterName} />
                <DetailItem label="واحد درخواست کننده" value={request.requestingUnitName} />
                <DetailItem label="تاریخ سررسید" value={renderDueDateInfo()} />
                <DetailItem label="منبع اعتبار" value={request.fundingSource === 'PRODUCTION' ? 'تولیدی' : 'تحقیقاتی'} />
                <DetailItem label="تنخواه بگیر" value={request.imprestHolderName} />
                <DetailItem label="نوع پرداخت قرارداد" value={request.paymentType} />
                <DetailItem label="شماره قرارداد مرتبط" value={request.relatedContractId} />
                <DetailItem label="توضیحات" value={request.itemDescription} fullWidth={true} />
            </div>
            {request.invoices?.length > 0 && (
              <div>
                  <h4 className="font-bold text-gray-800 mb-2">فاکتورها</h4>
                  <div className="space-y-3">
                      {request.invoices.map((invoice, index) => {
                          const invoiceTotal = invoice.items?.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0) || 0;
                          return (
                              <div key={invoice.id ?? index} className="border rounded-lg p-3 bg-gray-50 text-sm">
                                  <div className="flex justify-between items-start">
                                      <div>
                                          <p className="font-semibold">فاکتور #{index + 1}: {invoice.invoiceNumber || 'بدون شماره'}</p>
                                          <p className="text-xs text-gray-600">ذی‌نفع: {invoice.beneficiaryName || 'ناشناخته'}</p>
                                          {invoice.beneficiaryAccountNumber && (
                                              <div className="text-xs text-gray-500 mt-1 font-mono" dir="ltr" style={{ textAlign: 'right' }}>
                                                  <span>حساب: {invoice.beneficiaryAccountNumber}</span>
                                                  {invoice.beneficiaryCardNumber && <span className="mr-2">| کارت: {invoice.beneficiaryCardNumber}</span>}
                                                  {invoice.beneficiaryIban && <span className="mr-2">| شبا: {invoice.beneficiaryIban}</span>}
                                              </div>
                                          )}
                                      </div>
                                      <div className="text-left flex-shrink-0">
                                          {invoice.attachmentUrl && <button onClick={() => setLightbox({ src: invoice.attachmentUrl!, alt: invoice.attachmentName })} className="text-xs text-blue-600 hover:underline font-semibold no-print">مشاهده پیوست</button>}
                                          {invoiceTotal > 0 && <p className="font-semibold text-gray-800 mt-1">{formatCurrency(invoiceTotal, request.currency)}</p>}
                                      </div>
                                  </div>
                                  {invoice.items && invoice.items.length > 0 && (
                                      <div className="mt-2 pt-2 border-t border-gray-200">
                                          <div className="max-h-48 overflow-y-auto relative border rounded-md">
                                              <table className="w-full text-xs">
                                                  <thead className="sticky top-0 bg-gray-100 z-10">
                                                      <tr className="text-right text-gray-500">
                                                          <th className="font-normal p-2">شرح</th>
                                                          <th className="font-normal p-2 text-center w-20">تعداد</th>
                                                          <th className="font-normal p-2 text-left w-28">قیمت واحد</th>
                                                          <th className="font-normal p-2 text-left w-28">قیمت کل</th>
                                                      </tr>
                                                  </thead>
                                                  <tbody>
                                                      {invoice.items.map((item, itemIndex) => (
                                                          <tr key={itemIndex} className="border-t border-gray-200/50 bg-white">
                                                              <td className="p-2">{item.description}</td>
                                                              <td className="p-2 text-center">{item.quantity}</td>
                                                              <td className="p-2 text-left font-mono">{formatCurrency(item.unitPrice, request.currency)}</td>
                                                              <td className="p-2 text-left font-mono">{formatCurrency(item.quantity * item.unitPrice, request.currency)}</td>
                                                          </tr>
                                                      ))}
                                                  </tbody>
                                              </table>
                                          </div>
                                      </div>
                                  )}
                              </div>
                          );
                      })}
                  </div>
              </div>
            )}
            {Object.keys(request.attachments || {}).length > 0 && <div><h4 className="font-bold text-gray-800 mb-2">سایر پیوست‌ها</h4><div className="grid grid-cols-2 md:grid-cols-4 gap-2">{Object.entries(request.attachments || {}).map(([key, attachment]) => <div key={key} className="border rounded-lg p-2 bg-gray-50 text-sm text-center"><button onClick={() => setLightbox({ src: (attachment as Attachment).url, alt: (attachment as Attachment).name })} className="text-blue-600 hover:underline font-semibold no-print">{key}</button></div>)}</div></div>}
            <div>
              <h4 className="font-bold text-gray-800 mb-4">تاریخچه اقدامات</h4>
              <div className="border-r-2 border-gray-200 relative ml-1">
                  {activeStep && <div className="relative pr-8 mb-6"><div className="absolute -right-[9px] top-1 h-4 w-4 rounded-full bg-blue-500 border-2 border-white animate-pulse"></div><div className="flex justify-between items-baseline"><p className="font-bold text-blue-600">{request.workflow?.steps.find(s => s.id === activeStep.stepId)?.name}</p><p className="text-xs text-blue-500">در حال انجام (زمان سپری شده: {elapsedTime})</p></div><p className="text-sm text-gray-600 mt-1">در انتظار اقدام: <span className="font-semibold">{activeStep.assigneeName}</span></p></div>}
                  {request._history.length > 0 ? <div className="space-y-6">{[...request._history].reverse().map((h, i) => { if (h.action === 'RESUBMIT') return <div key={i} className="relative pr-8"><div className="absolute -right-[9px] top-1 h-4 w-4 rounded-full bg-purple-500 border-2 border-white"></div><div className="flex justify-between items-baseline"><p className="font-bold text-purple-600">اصلاح و ارسال مجدد</p><p className="text-xs text-gray-500">{new Date(h.endTimestamp).toLocaleString('fa-IR')}</p></div><p className="text-sm text-gray-600 mt-1">توسط <span className="font-semibold">{h.personName}</span></p></div>; if (h.action === 'INTERNAL_REVIEW_START') { return (<div key={i} className="relative pr-8"><div className="absolute -right-[9px] top-1 h-4 w-4 rounded-full bg-purple-500 border-2 border-white"></div><div className="flex justify-between items-baseline"><p className="font-bold text-purple-600">ارجاع به بررسی داخلی</p><p className="text-xs text-gray-500">{new Date(h.endTimestamp).toLocaleString('fa-IR')}</p></div><p className="text-sm text-gray-600 mt-1">توسط <span className="font-semibold">{h.personName}</span></p>{h.comment && <blockquote className="mt-2 p-3 bg-gray-50 rounded-lg text-sm text-gray-700 border-r-4 border-gray-300"><p>{h.comment}</p></blockquote>}</div>); } if (h.action === 'INTERNAL_REVIEW_END' && h.internalReviewDetails) { const finalInternalAction = h.internalReviewDetails.history.length > 0 ? h.internalReviewDetails.history[h.internalReviewDetails.history.length - 1] : null; return (<div key={i} className="relative pr-8"><div className="absolute -right-[9px] top-1 h-4 w-4 rounded-full bg-purple-500 border-2 border-white"></div><div className="flex justify-between items-baseline"><p className="font-bold text-purple-600">پایان بررسی داخلی: {request.internalWorkflow?.name}</p><p className="text-xs text-gray-500">{new Date(h.endTimestamp).toLocaleString('fa-IR')}</p></div>{finalInternalAction?.comment && (<blockquote className="mt-2 p-3 bg-yellow-50 rounded-lg text-sm text-gray-700 border-r-4 border-yellow-400"><p className="font-semibold mb-1">نظر کارشناس ({finalInternalAction.personName}):</p><p className="italic">"{finalInternalAction.comment}"</p></blockquote>)}</div>); } const step = request.workflow?.steps.find(s => s.id === h.stepId); const actionText = h.action === 'APPROVE' ? 'تایید شد' : 'رد شد'; const actionColor = h.action === 'APPROVE' ? 'text-green-600' : 'text-red-600'; const iconBg = h.action === 'APPROVE' ? 'bg-green-500' : 'bg-red-500'; const duration = formatDuration(h.startTimestamp, h.endTimestamp); return <div key={i} className="relative pr-8"><div className={`absolute -right-[9px] top-1 h-4 w-4 rounded-full ${iconBg} border-2 border-white`}></div><div className="flex justify-between items-baseline"><p className="font-bold text-gray-800">{step?.name}</p><p className="text-xs text-gray-500">{new Date(h.endTimestamp).toLocaleString('fa-IR')}</p></div><p className="text-sm text-gray-600 mt-1">توسط <span className="font-semibold">{h.personName}</span>: <span className={`${actionColor} font-bold`}>{actionText}</span><span className="text-gray-500 text-xs mr-2">(مدت زمان: {duration})</span></p>{h.comment && <blockquote className="mt-2 p-3 bg-gray-50 rounded-lg text-sm text-gray-700 border-r-4 border-gray-300"><p>{h.comment}</p></blockquote>}</div>; })}</div> : <div className="pr-8">{!activeStep && <p className="text-sm text-gray-500">هیچ اقدامی ثبت نشده است.</p>}</div>}
              </div>
            </div>
          </div>
          {(canTakeAction || isMyInternalTurn) && (
              <div className="p-4 bg-gray-50 border-t space-y-2 no-print">
                  <h3 className="font-bold text-lg text-gray-800 mb-3">اقدام شما</h3>
                  {isServerOffline ? (
                    <div className="p-4 bg-yellow-50 border-yellow-200 border rounded-lg text-center text-yellow-800 font-semibold">
                        سرور در دسترس نیست. امکان انجام عملیات وجود ندارد.
                    </div>
                  ) : isApproving ? (
                      <div className="p-4 bg-green-50 border-green-200 border rounded-lg">
                          <label htmlFor="approvalComment" className="font-semibold text-sm text-gray-700 block mb-2">نظر شما (اختیاری):</label>
                          <textarea id="approvalComment" value={approvalComment} onChange={(e) => setApprovalComment(e.target.value)} className="w-full p-2 border rounded-md" rows={2}></textarea>
                          <div className="flex gap-2 mt-2 justify-end">
                              <button onClick={() => setIsApproving(false)} className="bg-gray-200 text-gray-800 px-4 py-2 text-sm rounded-md hover:bg-gray-300">انصراف</button>
                              <button onClick={() => setIsSigning(true)} disabled={approveMutation.isPending} className="bg-green-600 text-white px-4 py-2 text-sm rounded-md font-semibold hover:bg-green-700 disabled:bg-gray-400">
                                {approveMutation.isPending ? 'در حال ثبت...' : 'ثبت تایید'}
                              </button>
                          </div>
                      </div>
                  ) : isRejecting ? (
                      <div className="p-4 bg-red-50 border-red-200 border rounded-lg">
                          <label htmlFor="rejectionReason" className="font-semibold text-sm text-gray-700 block mb-2">لطفا دلیل رد درخواست را ذکر کنید (اجباری):</label>
                          <textarea id="rejectionReason" value={rejectionReason} onChange={(e) => setRejectionReason(e.target.value)} className="w-full p-2 border rounded-md" rows={2}></textarea>
                          <div className="flex gap-2 mt-2 justify-end">
                              <button onClick={() => setIsRejecting(false)} className="bg-gray-200 text-gray-800 px-4 py-2 text-sm rounded-md hover:bg-gray-300">انصراف</button>
                              <button onClick={handleConfirmReject} disabled={!rejectionReason.trim() || rejectMutation.isPending} className="bg-red-600 text-white px-4 py-2 text-sm rounded-md font-semibold hover:bg-red-700 disabled:bg-gray-400">
                                {rejectMutation.isPending ? 'در حال ثبت...' : 'ثبت رد'}
                              </button>
                          </div>
                      </div>
                  ) : isReferring ? (
                      <div className="p-4 bg-blue-50 border-blue-200 border rounded-lg space-y-3">
                          <div><label className="font-semibold text-sm text-gray-700 block mb-1">انتخاب فرآیند داخلی:</label><select value={referralData.workflowId} onChange={e => setReferralData(d => ({...d, workflowId: e.target.value}))} className="w-full p-2 border rounded-md bg-white"><option value="">...</option>{availableInternalWorkflows.map(iw => <option key={iw.id} value={iw.id}>{iw.name}</option>)}</select></div>
                          <div><label className="font-semibold text-sm text-gray-700 block mb-1">توضیحات (اختیاری):</label><textarea value={referralData.comment} onChange={e => setReferralData(d => ({...d, comment: e.target.value}))} className="w-full p-2 border rounded-md" rows={2}></textarea></div>
                          <div className="flex gap-2 mt-2 justify-end"><button onClick={() => setIsReferring(false)} className="bg-gray-200 text-gray-800 px-4 py-2 text-sm rounded-md hover:bg-gray-300">انصراف</button><button onClick={handleStartInternalReview} disabled={!referralData.workflowId || startInternalReviewMutation.isPending} className="bg-blue-600 text-white px-4 py-2 text-sm rounded-md font-semibold hover:bg-blue-700 disabled:bg-gray-400">{startInternalReviewMutation.isPending ? '...' : 'شروع فرآیند داخلی'}</button></div>
                      </div>
                  ) : isMyInternalTurn ? (
                      <div className="p-4 bg-yellow-50 border-yellow-200 border rounded-lg">
                          <label className="font-semibold text-sm text-gray-700 block mb-2">نظر کارشناسی شما:</label>
                          <textarea value={expertComment} onChange={(e) => setExpertComment(e.target.value)} className="w-full p-2 border rounded-md" rows={3}></textarea>
                          <div className="flex justify-end mt-2">
                            <button onClick={handleInternalReviewAction} disabled={advanceInternalReviewMutation.isPending} className="bg-green-600 text-white px-6 py-2 rounded-md font-semibold hover:bg-green-700 disabled:bg-gray-400">
                                {advanceInternalReviewMutation.isPending ? 'در حال ثبت...' : 'ثبت نظر و بازگشت به مدیر'}
                            </button>
                          </div>
                      </div>
                  ) : (
                      <div className="flex justify-end gap-3">
                          <button onClick={() => setIsRejecting(true)} disabled={approveMutation.isPending || rejectMutation.isPending} className="bg-red-500 text-white px-6 py-2 rounded-md font-semibold hover:bg-red-600 disabled:bg-gray-400">رد درخواست</button>
                          {canReferInternally && <button onClick={() => setIsReferring(true)} className="bg-purple-600 text-white px-6 py-2 rounded-md font-semibold hover:bg-purple-700">ارجاع داخلی</button>}
                          <button onClick={() => setIsApproving(true)} disabled={approveMutation.isPending || rejectMutation.isPending} className="bg-green-500 text-white px-6 py-2 rounded-md font-semibold hover:bg-green-600 disabled:bg-gray-400">تایید و ارسال به مرحله بعد</button>
                      </div>
                  )}
              </div>
          )}
          <div className="flex justify-between items-center gap-2 p-4 bg-gray-50 border-t no-print">
            <div>
              <button
                type="button"
                onClick={handleDelete}
                disabled={!canDelete || isServerOffline || deleteMutation.isPending}
                className="bg-red-600 text-white px-4 py-2 rounded font-semibold hover:bg-red-700 disabled:bg-gray-400"
              >
                {deleteMutation.isPending ? 'در حال حذف...' : 'حذف درخواست'}
              </button>
            </div>
            <div className="flex gap-2">
              <button type="button" onClick={() => window.print()} className="bg-blue-600 text-white px-4 py-2 rounded font-semibold hover:bg-blue-700">چاپ</button>
              <button type="button" onClick={onClose} className="bg-gray-200 text-gray-800 px-4 py-2 rounded font-semibold hover:bg-gray-300">بستن</button>
            </div>
          </div>
      </div>
    );
  };
  
  return (
    <>
      <Modal title={`جزئیات درخواست #${requestId}`} onClose={onClose} size="4xl">
        {renderContent()}
      </Modal>
      {lightbox && <ImageLightbox src={lightbox.src} alt={lightbox.alt} onClose={() => setLightbox(null)} />}
      {isSigning && (
        <DigitalSignatureModal
            actionText="تایید درخواست"
            onClose={() => setIsSigning(false)}
            onConfirm={() => {
                setIsSigning(false);
                handleConfirmApprove();
            }}
        />
      )}
    </>
  );
};

export default RequestDetailsModal;