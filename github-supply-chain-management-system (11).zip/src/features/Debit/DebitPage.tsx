
import React, { useState, useEffect } from 'react';
import { useForm, SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { DebitCard, DebitCardData, DebitCardSchema, PaginatedResponse } from '../../types';
import { debitCardsApi } from '../../services/api';
import Modal from '../../components/Modal';
import { DataTable, ColumnDef } from '../../components/DataTable';
import { formatCurrency } from '../../utils/formatters';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import { z } from 'zod';
import { useToast } from '../../hooks/useToast';
import { useDebounce } from '../../hooks/useDebounce';
import { useServerStatus } from '../../context/ServerStatusContext';

type FormData = z.infer<typeof DebitCardSchema>;

const DebitPage: React.FC = () => {
  const { read: canRead, create: canCreate, update: canUpdate, delete: canDelete } = usePermissions('DEBIT');
  const queryClient = useQueryClient();
  const toast = useToast();
  const [page, setPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const debouncedSearch = useDebounce(searchQuery, 300);
  const { status: serverStatus } = useServerStatus();

  const { data: debitCardsResponse, isLoading } = useQuery({
    queryKey: ['debitCards', page, debouncedSearch],
    queryFn: () => debitCardsApi.getAll(page, debouncedSearch),
    placeholderData: (previousData) => previousData,
    enabled: serverStatus === 'online',
  });
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCard, setEditingCard] = useState<DebitCard | null>(null);

  const { register, handleSubmit, reset, formState: { errors } } = useForm<FormData>({ resolver: zodResolver(DebitCardSchema) });

  const mutation = useMutation({
    mutationFn: (data: { cardData: DebitCardData, id?: number }) => data.id ? debitCardsApi.update(data.id, data.cardData) : debitCardsApi.create(data.cardData),
    onSuccess: () => { 
      queryClient.invalidateQueries({ queryKey: ['debitCards'] }); 
      handleCloseModal();
      toast.success('کارت با موفقیت ذخیره شد.');
    },
    onError: (error: Error) => toast.error(`عملیات با خطا مواجه شد: ${error.message}`)
  });
  
  const deleteMutation = useMutation({
    mutationFn: (id: number) => debitCardsApi.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['debitCards'] });
      toast.success('کارت با موفقیت حذف شد.');
    },
    onError: (error: Error) => toast.error(`حذف با خطا مواجه شد: ${error.message}`)
  });

  useEffect(() => {
    if (editingCard) reset(editingCard);
    else reset({ holderName: '', cardNumber: '', limit: 0 });
  }, [editingCard, reset, isModalOpen]);

  useEffect(() => {
    setPage(1);
  }, [debouncedSearch]);


  const handleOpenModal = (card: DebitCard | null = null) => { setEditingCard(card); setIsModalOpen(true); };
  const handleCloseModal = () => { setIsModalOpen(false); setEditingCard(null); };
  const onSubmit: SubmitHandler<FormData> = (data) => mutation.mutate({ cardData: data, id: editingCard?.id });
  const handleDelete = (id: number) => { if (window.confirm('آیا از حذف این کارت مطمئن هستید؟')) deleteMutation.mutate(id); };
  
  const columns: ColumnDef<DebitCard>[] = [
    { accessorKey: 'holderName', header: 'نام دارنده' },
    { accessorKey: 'cardNumber', header: 'شماره کارت' },
    { accessorKey: 'limit', header: 'سقف اعتبار (ریال)', cell: (c) => formatCurrency(c.limit, 'RIAL') },
    { accessorKey: 'actions', header: 'عملیات', width: '120px', cell: (card) => (
        <div className="flex justify-center gap-4">
            <button onClick={() => handleOpenModal(card)} disabled={!canUpdate} className="text-blue-600 hover:underline font-semibold disabled:text-gray-400 disabled:no-underline">ویرایش</button>
            <button onClick={() => handleDelete(card.id)} disabled={!canDelete} className="text-red-600 hover:underline font-semibold disabled:text-gray-400 disabled:no-underline">حذف</button>
        </div>
    )}
  ];

  if (!canRead) return <AccessDenied />;

  return (
    <section className="space-y-6">
       <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold text-gray-800">مدیریت کارت‌های بدهی</h2>
            <button onClick={() => handleOpenModal()} disabled={!canCreate} className="bg-blue-600 text-white px-5 py-2 rounded-lg font-semibold hover:bg-blue-700 shadow-md flex items-center gap-2 disabled:bg-gray-400">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110 2h3V6a1 1 0 011-1z" /></svg>
                افزودن کارت جدید
            </button>
        </div>
         <div className="relative">
            <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="جستجو بر اساس نام دارنده یا شماره کارت..."
                className="w-full p-2 pl-10 border rounded-md"
            />
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
        </div>
        {isLoading && serverStatus !== 'offline' ? <p>در حال بارگذاری...</p> : 
            <DataTable 
                columns={columns} 
                data={debitCardsResponse?.data || []}
                pagination={{ page, total: debitCardsResponse?.total || 0, itemsPerPage: 20 }}
                onPageChange={setPage}
            />
        }
        {isModalOpen && (
            <Modal title={editingCard ? 'ویرایش کارت' : 'افزودن کارت جدید'} onClose={handleCloseModal}>
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 p-6">
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">نام دارنده</label><input {...register("holderName")} className="w-full border p-2 rounded" />{errors.holderName && <p className="text-red-500 text-xs mt-1">{errors.holderName.message as string}</p>}</div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">شماره کارت</label><input {...register("cardNumber")} className="w-full border p-2 rounded" />{errors.cardNumber && <p className="text-red-500 text-xs mt-1">{errors.cardNumber.message as string}</p>}</div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">سقف اعتبار (ریال)</label><input type="number" {...register("limit", { valueAsNumber: true })} className="w-full border p-2 rounded" min="0" />{errors.limit && <p className="text-red-500 text-xs mt-1">{errors.limit.message as string}</p>}</div>
                    <div className="flex justify-end gap-2 pt-4 border-t mt-2">
                        <button type="button" onClick={handleCloseModal} className="bg-gray-200 text-gray-800 px-4 py-2 rounded font-semibold">لغو</button>
                        <button type="submit" disabled={mutation.isPending} className="bg-green-500 text-white px-4 py-2 rounded disabled:bg-gray-400 font-semibold">{mutation.isPending ? '...' : (editingCard ? 'ذخیره' : 'افزودن')}</button>
                    </div>
                </form>
            </Modal>
        )}
    </section>
  );
};

export default DebitPage;
