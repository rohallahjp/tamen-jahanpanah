
import React, { useState, useEffect } from 'react';
import { useForm, SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { Project, ProjectData, ProjectSchema } from '../../types';
import { projectsApi } from '../../services/api';
import Modal from '../../components/Modal';
import { DataTable, ColumnDef } from '../../components/DataTable';
import { formatNumber } from '../../utils/formatters';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import { z } from 'zod';
import { useToast } from '../../hooks/useToast';
import { useDebounce } from '../../hooks/useDebounce';
import { useServerStatus } from '../../context/ServerStatusContext';

type FormData = z.infer<typeof ProjectSchema>;

const ProjectsPage: React.FC = () => {
  const { read: canRead, create: canCreate, update: canUpdate, delete: canDelete } = usePermissions('PROJECTS');
  const queryClient = useQueryClient();
  const toast = useToast();
  const [page, setPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const debouncedSearch = useDebounce(searchQuery, 300);
  const { status: serverStatus } = useServerStatus();

  const { data: projectsResponse, isLoading } = useQuery({
    queryKey: ['projects', page, debouncedSearch],
    queryFn: () => projectsApi.getAll(page, debouncedSearch),
    placeholderData: (previousData) => previousData,
    enabled: serverStatus === 'online',
  });
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);

  const { register, handleSubmit, reset, formState: { errors } } = useForm<FormData>({ resolver: zodResolver(ProjectSchema) });

  const mutation = useMutation({
    mutationFn: (data: { projectData: ProjectData, id?: number }) => data.id ? projectsApi.update(data.id, data.projectData) : projectsApi.create(data.projectData),
    onSuccess: () => { 
      queryClient.invalidateQueries({ queryKey: ['projects'] }); 
      handleCloseModal();
      toast.success('پروژه با موفقیت ذخیره شد.');
    },
    onError: (error: Error) => toast.error(`عملیات با خطا مواجه شد: ${error.message}`)
  });
  
  const deleteMutation = useMutation({
    mutationFn: (id: number) => projectsApi.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      toast.success('پروژه با موفقیت حذف شد.');
    },
    onError: (error: Error) => toast.error(`حذف با خطا مواجه شد: ${error.message}`)
  });

  useEffect(() => {
    if (editingProject) reset(editingProject);
    else reset({ name: '', manager: '', budget: 0 });
  }, [editingProject, reset, isModalOpen]);

  useEffect(() => {
    setPage(1);
  }, [debouncedSearch]);


  const handleOpenModal = (project: Project | null = null) => { setEditingProject(project); setIsModalOpen(true); };
  const handleCloseModal = () => { setIsModalOpen(false); setEditingProject(null); };
  const onSubmit: SubmitHandler<FormData> = (data) => mutation.mutate({ projectData: data, id: editingProject?.id });
  const handleDelete = (id: number) => { if (window.confirm('آیا از حذف این پروژه مطمئن هستید؟')) deleteMutation.mutate(id); };
  
  const columns: ColumnDef<Project>[] = [
    { accessorKey: 'name', header: 'نام پروژه' },
    { accessorKey: 'manager', header: 'مدیر پروژه' },
    { accessorKey: 'budget', header: 'بودجه (ریال)', cell: (p) => formatNumber(p.budget) },
    { accessorKey: 'actions', header: 'عملیات', width: '120px', cell: (project) => (
        <div className="flex justify-center gap-4">
            <button onClick={() => handleOpenModal(project)} disabled={!canUpdate} className="text-blue-600 hover:underline font-semibold disabled:text-gray-400 disabled:no-underline">ویرایش</button>
            <button onClick={() => handleDelete(project.id)} disabled={!canDelete} className="text-red-600 hover:underline font-semibold disabled:text-gray-400 disabled:no-underline">حذف</button>
        </div>
    )}
  ];

  if (!canRead) return <AccessDenied />;

  return (
    <section className="space-y-6">
       <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold text-gray-800">مدیریت پروژه‌ها</h2>
            <button onClick={() => handleOpenModal()} disabled={!canCreate} className="bg-blue-600 text-white px-5 py-2 rounded-lg font-semibold hover:bg-blue-700 shadow-md flex items-center gap-2 disabled:bg-gray-400">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110 2h3V6a1 1 0 011-1z" /></svg>
                افزودن پروژه جدید
            </button>
        </div>
         <div className="relative">
            <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="جستجو بر اساس نام پروژه یا مدیر..."
                className="w-full p-2 pl-10 border rounded-md"
            />
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
        </div>
        {isLoading && serverStatus !== 'offline' ? <p>در حال بارگذاری...</p> : 
            <DataTable 
                columns={columns} 
                data={projectsResponse?.data || []}
                pagination={{ page, total: projectsResponse?.total || 0, itemsPerPage: 20 }}
                onPageChange={setPage}
            />
        }
        {isModalOpen && (
            <Modal title={editingProject ? 'ویرایش پروژه' : 'افزودن پروژه جدید'} onClose={handleCloseModal}>
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 p-6">
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">نام پروژه</label><input {...register("name")} className="w-full border p-2 rounded" />{errors.name && <p className="text-red-500 text-xs mt-1">{errors.name.message as string}</p>}</div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">مدیر پروژه</label><input {...register("manager")} className="w-full border p-2 rounded" />{errors.manager && <p className="text-red-500 text-xs mt-1">{errors.manager.message as string}</p>}</div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">بودجه (ریال)</label><input type="number" {...register("budget", { valueAsNumber: true })} className="w-full border p-2 rounded" min="0" />{errors.budget && <p className="text-red-500 text-xs mt-1">{errors.budget.message as string}</p>}</div>
                    <div className="flex justify-end gap-2 pt-4 border-t mt-2">
                        <button type="button" onClick={handleCloseModal} className="bg-gray-200 text-gray-800 px-4 py-2 rounded font-semibold">لغو</button>
                        <button type="submit" disabled={mutation.isPending} className="bg-green-500 text-white px-4 py-2 rounded disabled:bg-gray-400 font-semibold">{mutation.isPending ? '...' : (editingProject ? 'ذخیره' : 'افزودن')}</button>
                    </div>
                </form>
            </Modal>
        )}
    </section>
  );
};

export default ProjectsPage;