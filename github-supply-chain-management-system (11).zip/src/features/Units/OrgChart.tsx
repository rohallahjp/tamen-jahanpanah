// This component is obsolete and is no longer used.
// The new master-detail view in UnitsPage.tsx replaces this graphical chart.
import React from 'react';
const OrgChart: React.FC = () => null;
export default OrgChart;