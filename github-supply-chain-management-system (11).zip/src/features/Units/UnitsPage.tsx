
import React, { useState, useCallback, useEffect, useMemo } from 'react';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { Unit, Person, UnitData, PaginatedResponse, UnitNode } from '../../types';
import { unitsApi, personsApi } from '../../services/api';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import UnitFormModal from './UnitFormModal';
import Modal from '../../components/Modal';
import { useToast } from '../../hooks/useToast';
import { useDebounce } from '../../hooks/useDebounce';
import { useServerStatus } from '../../context/ServerStatusContext';

const AssignPersonModal: React.FC<{
    unit: UnitNode;
    onClose: () => void;
}> = ({ unit, onClose }) => {
    const queryClient = useQueryClient();
    const toast = useToast();
    const [searchQuery, setSearchQuery] = useState('');
    const debouncedSearch = useDebounce(searchQuery, 300);
    const { status: serverStatus } = useServerStatus();

    const { data: personsResponse, isLoading } = useQuery<PaginatedResponse<Person>>({
        queryKey: ['persons_unassigned_search', debouncedSearch],
        // Updated query to fetch ALL internal personnel, not just unassigned ones.
        queryFn: () => personsApi.getAll(1, debouncedSearch, { isBeneficiary: false }),
        enabled: serverStatus === 'online',
    });
    
    const assignMutation = useMutation({
        mutationFn: (personId: number) => unitsApi.assignPerson(unit.id, personId),
        onSuccess: () => {
            toast.success('شخص با موفقیت به این سمت منصوب شد.');
            queryClient.invalidateQueries({ queryKey: ['units_tree'] });
            queryClient.invalidateQueries({ queryKey: ['persons'] });
            onClose();
        },
        onError: (error: Error) => toast.error(`خطا: ${error.message}`),
    });

    return (
        <Modal title={`انتصاب شخص به ${unit.name}`} onClose={onClose}>
            <div className="p-4">
                 <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="جستجو بر اساس نام یا کد ملی شخص..."
                    className="w-full p-2 border rounded-md"
                    autoFocus
                />
                <div className="mt-4 max-h-80 overflow-y-auto">
                    {isLoading && serverStatus !== 'offline' ? (
                        <p className="text-center text-gray-500 py-4">در حال جستجو...</p>
                    ) : (personsResponse?.data || []).length > 0 ? (
                        <ul className="divide-y">
                            {(personsResponse?.data || []).map(person => (
                                <li key={person.id} className="p-2 flex justify-between items-center hover:bg-gray-50">
                                    <div>
                                        <span className="font-semibold">{person.fullName}</span>
                                        {person.unitName && <span className="text-xs text-gray-500 mr-2">({person.unitName})</span>}
                                    </div>
                                    <button
                                        onClick={() => assignMutation.mutate(person.id)}
                                        disabled={assignMutation.isPending}
                                        className="bg-blue-500 text-white px-3 py-1 text-sm rounded hover:bg-blue-600 disabled:bg-gray-400"
                                    >
                                        {assignMutation.isPending ? '...' : 'انتصاب'}
                                    </button>
                                </li>
                            ))}
                        </ul>
                    ) : (
                        <p className="text-center text-gray-500 py-4">
                            هیچ شخصی یافت نشد. می‌توانید از بخش <a href="/persons" className="text-blue-600">مدیریت اشخاص</a> فرد جدیدی اضافه کنید.
                        </p>
                    )}
                </div>
            </div>
        </Modal>
    );
};

const UnitsPage: React.FC = () => {
  const { read: canRead, create: canCreate, update: canUpdate, delete: canDelete } = usePermissions('UNITS');
  const queryClient = useQueryClient();
  const toast = useToast();
  const [currentUnitId, setCurrentUnitId] = useState<number | null>(null);
  const [search, setSearch] = useState({ title: '', person: '' });
  const [modalState, setModalState] = useState<{ type: 'unit' | 'assign' | null; unit: UnitNode | null; parentId?: number | null }>({ type: null, unit: null });
  const { status: serverStatus } = useServerStatus();

  const { data: treeData = [], isLoading: isTreeLoading } = useQuery<UnitNode[]>({
    queryKey: ['units_tree'],
    queryFn: unitsApi.getTree,
    enabled: serverStatus === 'online',
  });

  const unitMap = useMemo(() => {
    const map = new Map<number, UnitNode>();
    const traverse = (nodes: UnitNode[]) => {
      nodes.forEach(node => {
        map.set(node.id, node);
        if (node.children) traverse(node.children);
      });
    };
    traverse(treeData);
    return map;
  }, [treeData]);
  
  const breadcrumbs = useMemo(() => {
    const path: UnitNode[] = [];
    let current = currentUnitId ? unitMap.get(currentUnitId) : null;
    while (current) {
      path.unshift(current);
      current = current.parentId ? unitMap.get(current.parentId) : null;
    }
    return path;
  }, [currentUnitId, unitMap]);

  const currentUnit = useMemo(() => currentUnitId ? unitMap.get(currentUnitId) : null, [currentUnitId, unitMap]);
  const childrenToShow = useMemo(() => currentUnit ? currentUnit.children : treeData, [currentUnit, treeData]);

  const mutation = useMutation({
    mutationFn: (data: { unitData: UnitData, id?: number }) => data.id ? unitsApi.update(data.id, data.unitData) : unitsApi.create(data.unitData),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['units_tree'] }); setModalState({ type: null, unit: null }); toast.success('عملیات با موفقیت انجام شد.'); },
    onError: (err: Error) => toast.error(`خطا: ${err.message}`),
  });
  
  const deleteMutation = useMutation({
    mutationFn: (id: number) => unitsApi.delete(id),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['units_tree'] }); toast.success('واحد با موفقیت حذف شد.'); },
    onError: (err: Error) => toast.error(`حذف با خطا مواجه شد: ${err.message}`),
  });

  const unassignMutation = useMutation({
    mutationFn: (data: { unitId: number; personId: number }) => unitsApi.unassignPerson(data.unitId, data.personId),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['units_tree'] }); queryClient.invalidateQueries({ queryKey: ['persons'] }); toast.success('انتصاب شخص لغو شد.'); },
    onError: (err: Error) => toast.error(`خطا: ${err.message}`),
  });

  const onSaveUnit = useCallback((unitData: UnitData, id?: number) => mutation.mutate({ unitData, id }), [mutation]);
  const handleDeleteUnit = useCallback((id: number) => { if (window.confirm('آیا از حذف این واحد و تمام زیرمجموعه‌های آن مطمئن هستید؟')) deleteMutation.mutate(id); }, [deleteMutation]);
  const handleUnassignPerson = useCallback((unitId: number, personId: number) => unassignMutation.mutate({ unitId, personId }), [unassignMutation]);
  
  const openUnitModal = (unit: UnitNode | null = null, parentId: number | null = currentUnitId) => setModalState({ type: 'unit', unit, parentId });
  const openAssignModal = (unit: UnitNode) => setModalState({ type: 'assign', unit });

  if (!canRead) return <AccessDenied />;

  return (
    <section className="space-y-4">
      <h2 className="text-2xl font-bold text-gray-800">ساختار سازمانی</h2>
      
      <div className="bg-white border rounded-lg shadow-sm">
        <div className="p-3 border-b grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
            <input type="text" value={search.title} onChange={(e) => setSearch(s => ({ ...s, title: e.target.value }))} placeholder="جستجو عنوان..." className="w-full p-1.5 border rounded-sm text-sm" />
            <input type="text" value={search.person} onChange={(e) => setSearch(s => ({ ...s, person: e.target.value }))} placeholder="جستجو اشخاص..." className="w-full p-1.5 border rounded-sm text-sm" />
        </div>
        
        <div className="p-3 border-b flex items-center justify-between text-sm bg-gray-50">
          <div className="flex items-center gap-1.5 overflow-x-auto">
            <button onClick={() => setCurrentUnitId(null)} className="font-semibold text-blue-600 hover:underline flex-shrink-0">ریشه</button>
            {breadcrumbs.map(b => <React.Fragment key={b.id}><span>/</span><button onClick={() => setCurrentUnitId(b.id)} className="font-semibold text-blue-600 hover:underline flex-shrink-0">{b.name}</button></React.Fragment>)}
          </div>
          <div className="flex gap-2">
              {currentUnit && <button onClick={() => handleDeleteUnit(currentUnit.id)} disabled={!canDelete} className="text-xs px-3 py-1 bg-red-100 text-red-700 border border-red-300 rounded-sm disabled:opacity-50">حذف</button>}
              <button onClick={() => openUnitModal(null, currentUnitId)} disabled={!canCreate} className="text-xs px-3 py-1 bg-gray-200 border border-gray-400 rounded-sm disabled:opacity-50">ایجاد زیرمجموعه</button>
          </div>
        </div>

        {isTreeLoading && serverStatus !== 'offline' ? <p className="p-8 text-center">در حال بارگذاری ساختار سازمانی...</p> : (
            <div className="overflow-auto">
                <table className="w-full text-sm">
                    <thead className="bg-gray-100 text-gray-600"><tr><th className="p-2 text-right font-semibold w-1/3">عنوان</th><th className="p-2 text-right font-semibold">کد</th><th className="p-2 text-right font-semibold">اشخاص</th><th className="p-2 text-center font-semibold w-56">عملیات</th></tr></thead>
                    <tbody className="divide-y">
                        {childrenToShow.map(unit => (
                            <tr key={unit.id} className="hover:bg-blue-50">
                                <td className="p-2"><button onClick={() => setCurrentUnitId(unit.id)} className="font-semibold text-gray-800 hover:text-blue-600">{unit.name}</button></td>
                                <td className="p-2 text-gray-500 font-mono">{unit.code}</td>
                                <td className="p-2 text-gray-600">{unit.persons.map((p: any) => p.fullName).join('، ')}</td>
                                <td className="p-2">
                                    <div className="flex justify-center items-center gap-3 text-xs">
                                        {unit.children && unit.children.length > 0 && (
                                            <button onClick={() => setCurrentUnitId(unit.id)} className="font-semibold text-gray-600 hover:underline px-2 py-1 bg-gray-100 rounded-md" title="مشاهده زیرشاخه‌ها">مشاهده</button>
                                        )}
                                        <button onClick={() => openUnitModal(null, unit.id)} disabled={!canCreate} className="font-semibold text-green-600 hover:underline disabled:text-gray-400 px-2 py-1 bg-green-100 rounded-md" title="ایجاد زیرمجموعه برای این واحد">زیرمجموعه</button>
                                        <button onClick={() => openAssignModal(unit)} className="font-semibold text-blue-600 hover:underline disabled:text-gray-400 px-2 py-1 bg-blue-100 rounded-md" title="انتصاب یک شخص به این واحد">انتصاب</button>
                                        <button onClick={() => openUnitModal(unit, unit.parentId)} disabled={!canUpdate} className="font-semibold text-yellow-600 hover:underline disabled:text-gray-400 px-2 py-1 bg-yellow-100 rounded-md" title="ویرایش مشخصات این واحد">ویرایش</button>
                                        <button onClick={() => handleDeleteUnit(unit.id)} disabled={!canDelete} className="font-semibold text-red-600 hover:underline disabled:text-gray-400 px-2 py-1 bg-red-100 rounded-md" title="حذف این واحد">حذف</button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                         {currentUnit?.persons.map(person => (
                            <tr key={`p-${person.id}`} className="bg-gray-50 hover:bg-gray-100">
                                <td className="p-2 pl-6">{person.fullName}</td>
                                <td className="p-2 text-gray-500" colSpan={2}>- شخص منتسب -</td>
                                <td className="p-2 text-center"><button onClick={() => handleUnassignPerson(currentUnit.id, person.id)} className="text-xs font-semibold text-red-600 hover:underline">لغو انتصاب</button></td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        )}
      </div>

      {modalState.type === 'unit' && <UnitFormModal unit={modalState.unit} parentId={modalState.parentId ?? null} onClose={() => setModalState({ type: null, unit: null })} onSave={onSaveUnit} isPending={mutation.isPending} />}
      {modalState.type === 'assign' && modalState.unit && <AssignPersonModal unit={modalState.unit} onClose={() => setModalState({ type: null, unit: null })} />}
    </section>
  );
};

export default UnitsPage;