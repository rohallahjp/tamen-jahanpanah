import {
    Role, Person, Unit, Workflow, SupplyRequest, RequestCategory, Project,
    PersonData, UnitData, SupplyRequestData, RoleData, WorkflowData, RequestCategoryData, ProjectData,
    InternalWorkflow, InternalWorkflowData,
    ExpenseReport, ExpenseReportData,
    Contract, ContractData,
    DebitCard, DebitCardData,
    AppearanceSettings, TipsSettings,
    ReportSummary,
    DashboardSummary,
    InvoiceExplorerItem,
    PaginatedResponse,
    UnitNode,
    Notification,
// FIX: Replaced '@' alias with a relative path to resolve module error.
    AuditLogEntry,
    SecuritySummary,
} from '../types';

// Use a relative path for API requests to leverage the Vite proxy in development.
// This avoids CORS issues and problems with unexposed ports in containerized environments.
const API_BASE_URL = '/api';

const apiFetch = async <T>(url: string, options: RequestInit = {}): Promise<T> => {
    try {
        // Create a new Headers object to correctly handle different header formats.
        const headers = new Headers(options.headers);

        // Only set Content-Type for requests that have a body and it's not already set.
        if (options.body && !headers.has('Content-Type')) {
            headers.set('Content-Type', 'application/json');
        }

        // Add cache-busting headers to ensure fresh data.
        headers.set('Cache-Control', 'no-cache, no-store, must-revalidate');
        headers.set('Pragma', 'no-cache');
        headers.set('Expires', '0');

        const response = await fetch(`${API_BASE_URL}${url}`, {
            ...options,
            headers: headers,
        });

        if (response.status === 204) {
            return {} as T;
        }

        const contentType = response.headers.get('content-type');

        if (!response.ok) {
            let errorBody;
            if (contentType && contentType.includes('application/json')) {
                errorBody = await response.json();
            } else {
                const text = await response.text();
                errorBody = { message: text || `Request failed with status ${response.status}` };
            }
            throw new Error(errorBody.message || `یک خطای ناشناخته در سرور رخ داد.`);
        }

        if (contentType && contentType.includes('application/json')) {
            return response.json();
        }

        return response.text() as unknown as T;

    } catch (error: any) {
        console.error(`API fetch error for ${url}:`, error.message);
        throw error;
    }
};

const createCrudApiService = <T, TData>(collection: string) => ({
    getAll: (page?: number, q?: string, filters: Record<string, any> = {}): Promise<PaginatedResponse<T>> => {
        const params = new URLSearchParams();
        if (page) params.append('page', String(page));
        if (q) params.append('q', q);
        Object.entries(filters).forEach(([key, value]) => {
            if (value !== undefined && value !== null && value !== '') {
                params.append(key, String(value));
            }
        });
        const queryString = params.toString();
        return apiFetch<PaginatedResponse<T>>(`/${collection}${queryString ? `?${queryString}` : ''}`);
    },
    getAllUnpaginated: (filters: Record<string, any> = {}): Promise<T[]> => {
        const params = new URLSearchParams({ _nopagination: 'true' });
        Object.entries(filters).forEach(([key, value]) => {
            if (value !== undefined && value !== null && value !== '') {
                params.append(key, String(value));
            }
        });
        const queryString = params.toString();
        // Backend returns { data, total } even for unpaginated calls. We extract `data`.
        return apiFetch<PaginatedResponse<T>>(`/${collection}?${queryString}`).then(res => res.data);
    },
    create: (data: TData): Promise<T> => apiFetch<T>(`/${collection}`, {
        method: 'POST',
        body: JSON.stringify(data),
    }),
    update: (id: number, data: Partial<TData>): Promise<T> => apiFetch<T>(`/${collection}/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
    }),
    delete: (id: number): Promise<void> => apiFetch<void>(`/${collection}/${id}`, {
        method: 'DELETE',
    }),
});

// --- API Service Definitions ---

export const personsApi = {
    ...createCrudApiService<Person, (PersonData | Partial<Person>) & { actingUserId?: number }>('persons'),
    resetPassword: (userId: number, newPassword: string): Promise<{ success: boolean }> =>
        apiFetch(`/persons/${userId}/reset-password`, {
            method: 'PUT',
            body: JSON.stringify({ newPassword }),
        }),
    revokeAccess: (userId: number): Promise<{ success: boolean }> =>
        apiFetch(`/persons/${userId}/revoke-access`, { method: 'POST' }),
    changePassword: (userId: number, currentPassword: string, newPassword: string): Promise<{ success: boolean }> =>
        apiFetch(`/persons/${userId}/change-password`, {
            method: 'PUT',
            body: JSON.stringify({ currentPassword, newPassword }),
        }),
    verifyPassword: (userId: number, password: string): Promise<{ success: boolean }> =>
        apiFetch(`/persons/${userId}/verify-password`, {
            method: 'POST',
            body: JSON.stringify({ password }),
        }),
    getPettyCashStatus: (personId: number): Promise<{ limit: number; outstandingAmount: number; availableBalance: number; }> =>
        apiFetch(`/persons/${personId}/petty-cash-status`),
};

export const unitsApi = {
    ...createCrudApiService<Unit, UnitData>('units'),
    getTree: (): Promise<UnitNode[]> => apiFetch<UnitNode[]>('/units/tree'),
    assignPerson: (unitId: number, personId: number): Promise<{ success: boolean }> =>
        apiFetch(`/units/${unitId}/persons`, {
            method: 'POST',
            body: JSON.stringify({ personId }),
        }),
    unassignPerson: (unitId: number, personId: number): Promise<{ success: boolean }> =>
        apiFetch(`/units/${unitId}/persons/${personId}`, { method: 'DELETE' }),
};

export const rolesApi = createCrudApiService<Role, RoleData>('roles');
export const projectsApi = createCrudApiService<Project, ProjectData>('projects');
export const requestCategoriesApi = createCrudApiService<RequestCategory, RequestCategoryData>('requestCategories');
export const workflowsApi = createCrudApiService<Workflow, WorkflowData>('workflows');
export const internalWorkflowsApi = createCrudApiService<InternalWorkflow, InternalWorkflowData>('internalWorkflows');
export const expenseReportsApi = createCrudApiService<ExpenseReport, ExpenseReportData>('expenseReports');
export const contractsApi = createCrudApiService<Contract, ContractData>('contracts');
export const debitCardsApi = createCrudApiService<DebitCard, DebitCardData>('debitCards');
// FIX: Added auditLogApi to provide an endpoint for fetching audit log data.
export const auditLogApi = createCrudApiService<AuditLogEntry, Partial<AuditLogEntry>>('audit-log');

export const diagnosticsApi = {
    healthCheck: (): Promise<{ status: string }> => apiFetch('/health'),
};

export const authApi = {
    login: (username: string, password: string): Promise<Person> =>
        apiFetch<Person>('/login', {
            method: 'POST',
            body: JSON.stringify({ username, password }),
        }),
};

export const appearanceApi = {
    get: (): Promise<AppearanceSettings> => apiFetch('/appearanceSettings'),
    update: (settings: AppearanceSettings): Promise<AppearanceSettings> =>
        apiFetch('/appearanceSettings', {
            method: 'POST',
            body: JSON.stringify(settings),
        }),
};

export const tipsApi = {
    getSettings: (): Promise<TipsSettings> => apiFetch('/tips-settings'),
    updateSettings: (settings: { settings: TipsSettings; actingUserId: number }): Promise<TipsSettings> =>
        apiFetch('/tips-settings', {
            method: 'POST',
            body: JSON.stringify(settings),
        }),
};

export const notificationsApi = {
    getForUser: (userId: number): Promise<{ notifications: Notification[], unreadCount: number }> =>
        apiFetch(`/notifications?userId=${userId}`),
    markAllAsRead: (userId: number): Promise<void> =>
        apiFetch('/notifications/mark-read', {
            method: 'POST',
            body: JSON.stringify({ userId }),
        }),
};

export const workflowEngineApi = {
    submitNewRequest: (data: SupplyRequestData): Promise<SupplyRequest> =>
        apiFetch('/requests/submit', { method: 'POST', body: JSON.stringify(data) }),
    resubmitRejectedRequest: (requestId: string, data: SupplyRequestData): Promise<SupplyRequest> =>
        apiFetch(`/requests/${requestId}/resubmit`, { method: 'POST', body: JSON.stringify(data) }),
    approveStep: (requestId: string, stepId: number, userId: number, comment?: string): Promise<SupplyRequest> =>
        apiFetch(`/requests/${requestId}/approve`, {
            method: 'POST',
            body: JSON.stringify({ currentStepId: stepId, personId: userId, comment }),
        }),
    rejectRequest: (requestId: string, stepId: number, userId: number, comment: string): Promise<SupplyRequest> =>
        apiFetch(`/requests/${requestId}/reject`, {
            method: 'POST',
            body: JSON.stringify({ currentStepId: stepId, personId: userId, comment }),
        }),
    startInternalReview: (requestId: string, stepId: number, userId: number, internalWorkflowId: number, comment?: string): Promise<SupplyRequest> =>
        apiFetch(`/requests/${requestId}/internal-review/start`, {
            method: 'POST',
            body: JSON.stringify({ mainStepId: stepId, mainAssigneeId: userId, internalWorkflowId, comment }),
        }),
    advanceInternalReview: (requestId: string, internalStepId: number, userId: number, action: 'FORWARD' | 'RETURN_TO_MANAGER', comment?: string): Promise<SupplyRequest> =>
        apiFetch(`/requests/${requestId}/internal-review/advance`, {
            method: 'POST',
            body: JSON.stringify({ currentInternalStepId: internalStepId, personId: userId, action, comment }),
        }),
    getRequestById: (id: string): Promise<SupplyRequest> => apiFetch(`/requests/${id}`),
    deleteRequest: (id: string): Promise<void> => apiFetch(`/requests/${id}`, { method: 'DELETE' }),
};

export const dashboardApi = {
    getSummary: (filters: { userId: number }): Promise<DashboardSummary> => {
        const params = new URLSearchParams({ userId: String(filters.userId) });
        return apiFetch(`/dashboard/summary?${params.toString()}`); // Default method is GET
    },
    getRequests: (filters: { userId: number }, page: number): Promise<PaginatedResponse<SupplyRequest>> =>
        apiFetch(`/dashboard/requests?page=${page}`, { method: 'POST', body: JSON.stringify(filters) }),
};

export const reportsApi = {
    search: (filters: any, page: number): Promise<PaginatedResponse<SupplyRequest>> =>
        apiFetch(`/reports/search?page=${page}`, { method: 'POST', body: JSON.stringify(filters) }),
    getSummary: (filters: any): Promise<ReportSummary> =>
        apiFetch('/reports/summary', { method: 'POST', body: JSON.stringify(filters) }),
    searchInvoiceItems: (filters: any, page: number): Promise<PaginatedResponse<InvoiceExplorerItem>> =>
        apiFetch(`/reports/invoice-items?page=${page}`, { method: 'POST', body: JSON.stringify(filters) }),
};

export const backupApi = {
    create: (): Promise<string> => apiFetch<string>('/backup/create'),
};

export const securityApi = {
    getSummary: (): Promise<SecuritySummary> => apiFetch('/security/summary'),
};