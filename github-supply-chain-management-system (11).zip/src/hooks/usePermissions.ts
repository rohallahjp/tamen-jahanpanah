
// FIX: Replaced '@' alias with a relative path to resolve module error.
import { useAuth } from './useAuth';
import { useMemo } from 'react';

export const usePermissions = (resource: string) => {
  const { currentUser } = useAuth();

  const permissions = useMemo(() => {
    const defaultPermissions = { create: false, read: false, update: false, delete: false };
    
    if (!currentUser?.permissions) {
      return defaultPermissions;
    }
    
    const userPermissionsSet = new Set(currentUser.permissions);

    return {
      create: userPermissionsSet.has(`${resource}:create`),
      read: userPermissionsSet.has(`${resource}:read`),
      update: userPermissionsSet.has(`${resource}:update`),
      delete: userPermissionsSet.has(`${resource}:delete`),
    };
  }, [currentUser, resource]);

  return permissions;
};
