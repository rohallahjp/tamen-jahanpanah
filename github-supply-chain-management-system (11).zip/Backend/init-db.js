// This script is deprecated and should not be run.
// To initialize the database, please use the new npm script.
console.error('\x1b[31m%s\x1b[0m', 'This script (init-db.js) is deprecated.');
console.log('\x1b[33m%s\x1b[0m', 'To initialize the database, please run the following command in your terminal:');
console.log('\x1b[36m%s\x1b[0m', 'npm run init-db');
console.log('\x1b[33m%s\x1b[0m', 'This will execute the `Backend/init.sql` file correctly.');
process.exit(1);
