// This script is deprecated.
console.error('\x1b[31m%s\x1b[0m', 'This command `npm run init-db` is no longer used.');
console.log('\x1b[33m%s\x1b[0m', 'Database initialization is now handled automatically through the web interface.');
console.log('\x1b[33m%s\x1b[0m', 'Please start the application servers and open the app in your browser:');
console.log('\x1b[36m%s\x1b[0m', '1. Run `npm run dev:backend` in a terminal.');
console.log('\x1b[36m%s\x1b[0m', '2. Run `npm run dev` in a separate terminal.');
process.exit(0);
