import path from 'path';
import crypto from 'crypto';
import fs from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import express from 'express';
import cors from 'cors';
import { Pool } from 'pg';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load environment variables from .env file in the project root
dotenv.config({ path: path.resolve(__dirname, '..', '.env') });

// --- Global Exception Handlers (Safety Net) ---
process.on('uncaughtException', (err, origin) => {
    console.error(`\x1b[31m[FATAL_ERROR] Uncaught Exception at: ${origin}\x1b[0m`, err);
});
process.on('unhandledRejection', (reason, promise) => {
    console.error('\x1b[31m[FATAL_ERROR] Unhandled Rejection at:\x1b[0m', promise, '\x1b[31mreason:\x1b[0m', reason);
});


// --- Check for required environment variables ---
const requiredEnvVars = ['DB_HOST', 'DB_DATABASE', 'DB_USER', 'DB_PASSWORD'];
const missingVars = requiredEnvVars.filter(v => !process.env[v]);

if (missingVars.length > 0) {
    console.error('\x1b[31m%s\x1b[0m', '[FATAL_ERROR] Missing critical environment variables:', missingVars.join(', '));
    console.error('\x1b[33m%s\x1b[0m', 'Please create a `.env` file in the root of your project and add the required variables.');
    process.exit(1);
}


// --- Express App Setup ---
const app = express();
const PORT = process.env.PORT || 4000;
app.use(cors());
app.use(express.json({ limit: '50mb' }));

const buildPath = path.join(__dirname, '..');
app.use(express.static(buildPath, {
  setHeaders: (res, filePath) => {
    if (filePath.endsWith('.tsx') || filePath.endsWith('.ts')) {
      // Allow browser to fetch TS/TSX files for module loading.
      // This is normally handled by the Vite dev server, but this fix
      // helps in environments where the production server is pointed at source files.
      res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
    }
  }
}));

// --- Database Connection ---
const pool = new Pool({
  host: process.env.DB_HOST,
  database: process.env.DB_DATABASE,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT || 5432,
});

pool.on('error', (err, client) => {
    console.error('CRITICAL: Unexpected error on idle database client.', err);
});

// --- Centralized Error Handler ---
const handleApiError = (err, res, context = 'processing request') => {
    console.error(`[SERVER_ERROR] Error while ${context}:`, err);
    // Send the actual database error message if available. This is invaluable for debugging.
    const message = err.message || 'An unknown internal server error occurred.';
    res.status(500).json({ message });
};


// --- Helper Functions ---
const hashPassword = (password) => {
    return crypto.createHash('sha256').update(password).digest('hex');
};

const createNotification = async (client, personId, message, link) => {
    if (!personId) return;
    try {
        await client.query(
            'INSERT INTO "notifications" ("personId", "message", "link") VALUES ($1, $2, $3)',
            [personId, message, link]
        );
    } catch (e) {
        // FIX: Gracefully handle cases where the notifications table might not exist
        // in the user's database schema, preventing transaction rollbacks.
        if (e.code === '42P01') { // 42P01 is PostgreSQL's code for "undefined_table"
             console.warn(`[SERVER_WARNING] "notifications" table does not exist. Could not create notification for person ${personId}.`);
        } else {
            // Log other errors but don't fail the main transaction
            console.error(`Failed to create notification for person ${personId}:`, e);
        }
    }
};

/**
 * Logs a user action to the audit log table. Does not throw errors.
 * @param {number} personId - The ID of the user performing the action.
 * @param {string} action - A short descriptor of the action (e.g., 'CREATE', 'APPROVE_STEP').
 * @param {string} resourceType - The type of resource being affected (e.g., 'PERSONS', 'SUPPLY_REQUESTS').
 * @param {string | number} resourceId - The ID of the affected resource.
 * @param {object} details - A JSON object containing relevant details about the action.
 */
const logAction = async (personId, action, resourceType, resourceId, details = {}) => {
    if (!personId) {
        console.warn('[AUDIT_LOG] Attempted to log an action without a personId.');
        return;
    }
    const client = await pool.connect();
    try {
        const { rows } = await client.query('SELECT "fullName" FROM "persons" WHERE id = $1', [personId]);
        const personName = rows[0]?.fullName || `User #${personId}`;
        
        await client.query(
            `INSERT INTO "audit-log" ("personId", "personName", "action", "resourceType", "resourceId", "details")
             VALUES ($1, $2, $3, $4, $5, $6)`,
            [personId, personName, action, resourceType, String(resourceId), JSON.stringify(details)]
        );
    } catch (err) {
        // Log the error but don't disrupt the main API call
        console.error('[AUDIT_LOG_ERROR] Failed to write to audit log:', err);
    } finally {
        client.release();
    }
};


/**
 * Finds the assignee for a workflow step based on its rule.
 * @param {object} rule The assigneeRule object from the workflow step.
 * @param {number} requesterUnitId The unit ID of the person who created the request.
 * @param {pg.PoolClient} dbClient A connected database client.
 * @returns {Promise<number|null>} The ID of the assignee person, or null if not found.
 */
const findNextAssignee = async (rule, requesterUnitId, dbClient) => {
    if (!rule) return null;
    
    // Defensive parsing to handle potentially stringified numbers from older data in JSONB.
    const type = rule.type;
    const userId = rule.userId ? parseInt(String(rule.userId), 10) : null;
    const roleId = rule.roleId ? parseInt(String(rule.roleId), 10) : null;
    const unitId = rule.unitId ? parseInt(String(rule.unitId), 10) : null;

    if ((rule.userId && isNaN(userId)) || (rule.roleId && isNaN(roleId)) || (rule.unitId && isNaN(unitId))) {
        console.error('Invalid (NaN) ID found in workflow assignee rule:', rule);
        return null; // Prevent query with NaN
    }
    
    switch (type) {
        case 'USER':
            return userId || null;
        case 'UNIT_MANAGER': {
            if (!requesterUnitId) return null;
            const managerRoleRes = await dbClient.query(`SELECT id FROM "roles" WHERE name = 'مدیر واحد' LIMIT 1`);
            if (managerRoleRes.rows.length === 0) return null;
            const managerRoleId = managerRoleRes.rows[0].id;

            const managerRes = await dbClient.query(
                'SELECT id FROM "persons" WHERE "unitId" = $1 AND $2 = ANY("roleIds") LIMIT 1',
                [requesterUnitId, managerRoleId]
            );
            return managerRes.rows.length > 0 ? managerRes.rows[0].id : null;
        }
        case 'ROLE': {
            if (!roleId) return null;
            const userRes = await dbClient.query('SELECT id FROM "persons" WHERE $1 = ANY("roleIds") LIMIT 1', [roleId]);
            return userRes.rows.length > 0 ? userRes.rows[0].id : null;
        }
        case 'UNIT_AND_ROLE': {
            if (!unitId || !roleId) return null;
            const userRes = await dbClient.query(
                'SELECT id FROM "persons" WHERE "unitId" = $1 AND $2 = ANY("roleIds") LIMIT 1',
                [unitId, roleId]
            );
            return userRes.rows.length > 0 ? userRes.rows[0].id : null;
        }
        default:
            return null;
    }
};


const setupCollectionEndpoints = (dbCollectionName, apiCollectionName) => {
    const apiPath = apiCollectionName || dbCollectionName;

     // GET all (with pagination and search)
    app.get(`/api/${apiPath}`, async (req, res) => {
        try {
            const page = parseInt(req.query.page) || 1;
            const itemsPerPage = 20;
            const offset = (page - 1) * itemsPerPage;
            const q = req.query.q || '';
            
            let whereClauses = [];
            let queryParams = [];
            let paramIndex = 1;
            
            let fromClause = `FROM "${dbCollectionName}" p`;
            let selectFields = 'p.*';

            if (dbCollectionName === 'persons') {
                fromClause = `FROM "persons" p LEFT JOIN "units" u ON p."unitId" = u.id`;
                selectFields = 'p.*, u.name as "unitName"';
            } else if (dbCollectionName === 'contracts') {
                fromClause = `FROM "contracts" p LEFT JOIN "persons" party ON p."partyId" = party.id`;
                selectFields = 'p.*, party."fullName" as "partyName"';
            }

            if (q) {
                let searchFields;
                switch (dbCollectionName) {
                    case 'persons': searchFields = ['p."fullName"', 'p."nationalId"', 'p."personnelCode"']; break;
                    case 'contracts': searchFields = ['p."contractNumber"', 'p."contractTitle"']; break;
                    case 'requestCategories': searchFields = ['p."label"']; break;
                    case 'debitCards': searchFields = ['p."holderName"', 'p."cardNumber"']; break;
                    case 'projects': case 'roles': case 'workflows': case 'internalWorkflows': case 'units': searchFields = ['p."name"']; break;
                    case 'audit-log': searchFields = ['p."personName"', 'p."action"', 'p."resourceType"', 'p."resourceId"']; break;
                    default: searchFields = []; 
                }
                
                if (searchFields.length > 0) {
                    whereClauses.push(`(${searchFields.map(f => `${f} ILIKE $${paramIndex}`).join(' OR ')})`);
                    queryParams.push(`%${q}%`);
                    paramIndex++;
                }
            }
            
            Object.entries(req.query).forEach(([key, value]) => {
                if (key !== 'page' && key !== 'q' && key !== '_nopagination' && value && key !== 'actingUserId') {
                    if (dbCollectionName === 'contracts' && key === 'unitId') {
                        whereClauses.push(`(p."unitIds" IS NULL OR p."unitIds" = '{}' OR $${paramIndex++} = ANY(p."unitIds"))`);
                        queryParams.push(parseInt(String(value), 10));
                    } else if (key === 'isSystemUser' || key === 'isBeneficiary' || key === 'hasUnit') {
                        if (key === 'hasUnit') {
                           whereClauses.push(`p."unitId" IS NOT NULL`);
                        } else {
                           whereClauses.push(`p."${key}" = $${paramIndex++}`);
                           queryParams.push(value === 'true');
                        }
                    } else if (key === 'isPettyCashHolder') {
                        whereClauses.push(`p."roleIds" @> ARRAY[$${paramIndex++}::integer]`);
                        queryParams.push(15);
                    } else if (dbCollectionName === 'audit-log' && (key === 'dateFrom' || key === 'dateTo')) {
                        const operator = key === 'dateFrom' ? '>=' : '<=';
                        whereClauses.push(`p."timestamp" ${operator} $${paramIndex++}`);
                        queryParams.push(value);
                    }
                    else {
                        whereClauses.push(`p."${key}" = $${paramIndex++}`);
                        queryParams.push(value);
                    }
                }
            });

            const whereString = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';
            
            const totalQuery = `SELECT COUNT(*) FROM "${dbCollectionName}" p ${whereString}`;
            const totalResult = await pool.query(totalQuery, queryParams);
            const total = parseInt(totalResult.rows[0].count, 10);

            if (req.query._nopagination === 'true') {
                const dataQuery = `SELECT ${selectFields} ${fromClause} ${whereString} ORDER BY p.id DESC`;
                const dataResult = await pool.query(dataQuery, queryParams);
                res.json({ data: dataResult.rows, total });
            } else {
                const dataQuery = `SELECT ${selectFields} ${fromClause} ${whereString} ORDER BY p.id DESC LIMIT $${paramIndex++} OFFSET $${paramIndex++}`;
                const dataResult = await pool.query(dataQuery, [...queryParams, itemsPerPage, offset]);
                res.json({ data: dataResult.rows, total });
            }
        } catch (err) {
            handleApiError(err, res, `getting ${dbCollectionName}`);
        }
    });

    // POST create new
    app.post(`/api/${apiPath}`, async (req, res) => {
        try {
            let data = req.body;
            const actingUserId = data.actingUserId;
            delete data.actingUserId;
            
            if (dbCollectionName === 'persons') {
                if (data.password) data.password = hashPassword(data.password);
                const allowedFields = [
                    'fullName', 'firstName', 'lastName', 'nationalId','personnelCode',
                    'username','password','unitId','roleIds','isSystemUser','isBeneficiary',
                    'accountNumber', 'cardNumber', 'iban', 'pettyCashLimit', 
                    'status', 'forcePasswordChange', 'passwordNoExpiration', 'personType', 'phone', 'address'
                ];
                data = Object.fromEntries(Object.entries(data).filter(([k]) => allowedFields.includes(k)));
            }
            
            const jsonFields = ['steps', 'permissions', 'paymentTerms', 'items', 'subtypes', 'images', 'attachments'];
            for (const field of jsonFields) {
                if (data.hasOwnProperty(field) && typeof data[field] === 'object') {
                    data[field] = JSON.stringify(data[field]);
                }
            }

            if (Object.keys(data).length === 0) {
                return res.status(400).json({ message: "No valid fields provided for creation." });
            }

            const columns = Object.keys(data).map(k => `"${k}"`).join(', ');
            const values = Object.values(data);
            const valuePlaceholders = Object.keys(data).map((_, i) => `$${i + 1}`).join(', ');

            const query = `INSERT INTO "${dbCollectionName}" (${columns}) VALUES (${valuePlaceholders}) RETURNING *`;
            const result = await pool.query(query, values);
            
            logAction(actingUserId, 'CREATE', dbCollectionName.toUpperCase(), result.rows[0].id, { newData: result.rows[0] });

            res.status(201).json(result.rows[0]);
        } catch (err) {
            handleApiError(err, res, `creating ${dbCollectionName}`);
        }
    });

    // PUT update existing
    app.put(`/api/${apiPath}/:id`, async (req, res) => {
        try {
            const { id } = req.params;
            let data = req.body;
            const actingUserId = data.actingUserId;
            delete data.actingUserId;
            
            if (dbCollectionName === 'persons') {
                if (data.password) data.password = hashPassword(data.password);
                const allowedFields = [
                    'fullName', 'firstName', 'lastName', 'nationalId','personnelCode',
                    'username','password','unitId','roleIds','isSystemUser','isBeneficiary',
                    'accountNumber', 'cardNumber', 'iban', 'pettyCashLimit', 'pettyCashBalance',
                    'status', 'forcePasswordChange', 'passwordNoExpiration', 'personType', 'phone', 'address'
                ];
                data = Object.fromEntries(Object.entries(data).filter(([k]) => allowedFields.includes(k)));
            }

            const jsonFields = ['steps', 'permissions', 'paymentTerms', 'items', 'subtypes', 'images', 'attachments'];
            for (const field of jsonFields) {
                if (data.hasOwnProperty(field) && typeof data[field] === 'object') {
                    data[field] = JSON.stringify(data[field]);
                }
            }

            if (Object.keys(data).length === 0) {
                const { rows } = await pool.query(`SELECT * FROM "${dbCollectionName}" WHERE id = $1`, [id]);
                return res.json(rows[0] || null);
            }
            
            const { rows: oldData } = await pool.query(`SELECT * FROM "${dbCollectionName}" WHERE id = $1`, [id]);

            const setClauses = Object.keys(data).map((key, i) => `"${key}" = $${i + 1}`).join(', ');
            const values = Object.values(data);
            
            values.push(id);
            const query = `UPDATE "${dbCollectionName}" SET ${setClauses} WHERE id = $${values.length} RETURNING *`;
            const result = await pool.query(query, values);

            logAction(actingUserId, 'UPDATE', dbCollectionName.toUpperCase(), id, { oldData: oldData[0], newData: result.rows[0] });

            res.json(result.rows[0]);
        } catch (err) {
            handleApiError(err, res, `updating ${dbCollectionName} with ID ${req.params.id}`);
        }
    });

    // DELETE
    app.delete(`/api/${apiPath}/:id`, async (req, res) => {
        try {
            const { id } = req.params;
            const actingUserId = req.body.actingUserId || req.query.actingUserId;

            const { rows: oldData } = await pool.query(`SELECT * FROM "${dbCollectionName}" WHERE id = $1`, [id]);

            await pool.query(`DELETE FROM "${dbCollectionName}" WHERE id = $1`, [id]);
            
            logAction(actingUserId, 'DELETE', dbCollectionName.toUpperCase(), id, { deletedData: oldData[0] });

            res.status(204).send();
        } catch (err) {
            handleApiError(err, res, `deleting ${dbCollectionName} with ID ${req.params.id}`);
        }
    });
}


// --- API Endpoints ---
const collections = [
    'roles', 'persons', 'units', 'projects', 'requestCategories',
    'workflows', 'internalWorkflows', 'expenseReports', 'contracts', 'debitCards'
];

// Special handling for audit-log to prevent logging its own reads.
setupCollectionEndpoints('audit-log', 'audit-log');

collections.forEach(collectionInfo => {
    const isString = typeof collectionInfo === 'string';
    const apiName = isString ? collectionInfo : collectionInfo.apiName;
    const dbName = isString ? collectionInfo : (collectionInfo.dbName || collectionInfo.apiName);
    setupCollectionEndpoints(dbName, apiName);
});


// --- Special Endpoints ---
app.delete('/api/requests/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const actingUserId = req.body.actingUserId || req.query.actingUserId;
        const { rows: oldData } = await pool.query('SELECT * FROM "supplyRequests" WHERE id = $1', [id]);

        const result = await pool.query('DELETE FROM "supplyRequests" WHERE id = $1', [id]);
        if (result.rowCount === 0) {
            return res.status(404).json({ message: 'Request not found.' });
        }
        
        logAction(actingUserId, 'DELETE_REQUEST', 'SUPPLY_REQUESTS', id, { deletedData: oldData[0] });

        res.status(204).send();
    } catch (err) {
        handleApiError(err, res, `deleting request with ID ${req.params.id}`);
    }
});

app.get('/api/requests/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query('SELECT * FROM "supplyRequests" WHERE id = $1', [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'درخواست مورد نظر یافت نشد.' });
        }

        const request = result.rows[0];
        
        // --- PERFORMANCE: Enrich the request object with all necessary names and objects ---
        const personIds = new Set();
        const unitIds = new Set();
        const workflowIds = new Set();
        const internalWorkflowIds = new Set();
        const requestCategoryIds = new Set();

        personIds.add(request.requesterId);
        if (request.imprestHolderId) personIds.add(request.imprestHolderId);
        unitIds.add(request.requestingUnitId);
        workflowIds.add(request.workflowId);
        requestCategoryIds.add(request.requestTypeId);
        if (request.invoices) request.invoices.forEach(inv => personIds.add(inv.beneficiaryId));
        if (request._history) request._history.forEach(h => personIds.add(h.personId));
        if (request._activeSteps) request._activeSteps.forEach(s => personIds.add(s.assigneeId));
        if (request._internalReview) {
            personIds.add(request._internalReview.mainAssigneeId);
            personIds.add(request._internalReview.activeInternalAssigneeId);
            if (request._internalReview.history) {
                request._internalReview.history.forEach(h => personIds.add(h.personId));
            }
            internalWorkflowIds.add(request._internalReview.internalWorkflowId);
        }
        
        const [personsRes, unitsRes, workflowsRes, internalWorkflowsRes, categoriesRes] = await Promise.all([
            pool.query('SELECT id, "fullName", "accountNumber", "cardNumber", "iban", "unitId", "roleIds" FROM "persons" WHERE id = ANY($1)', [Array.from(personIds)]),
            pool.query('SELECT id, name FROM "units" WHERE id = ANY($1)', [Array.from(unitIds)]),
            pool.query('SELECT * FROM "workflows" WHERE id = ANY($1)', [Array.from(workflowIds)]),
            pool.query('SELECT * FROM "internalWorkflows" WHERE id = ANY($1)', [Array.from(internalWorkflowIds)]),
            pool.query('SELECT id, label FROM "requestCategories" WHERE id = ANY($1)', [Array.from(requestCategoryIds)]),
        ]);

        const personsMap = new Map(personsRes.rows.map(p => [p.id, p]));
        const unitsMap = new Map(unitsRes.rows.map(u => [u.id, u.name]));
        
        request.requesterName = personsMap.get(request.requesterId)?.fullName;
        request.imprestHolderName = request.imprestHolderId ? personsMap.get(request.imprestHolderId)?.fullName : undefined;
        request.requestingUnitName = unitsMap.get(request.requestingUnitId);
        request.requestCategoryLabel = categoriesRes.rows.find(c => c.id === request.requestTypeId)?.label;
        request.workflow = workflowsRes.rows.find(w => w.id === request.workflowId);

        if (request._history) request._history.forEach(h => h.personName = personsMap.get(h.personId)?.fullName);
        if (request._activeSteps) request._activeSteps.forEach(s => s.assigneeName = personsMap.get(s.assigneeId)?.fullName);
        if (request.invoices) {
            request.invoices.forEach(inv => {
                const beneficiary = personsMap.get(inv.beneficiaryId);
                if (beneficiary) {
                    inv.beneficiaryName = beneficiary.fullName;
                    inv.beneficiaryAccountNumber = beneficiary.accountNumber;
                    inv.beneficiaryCardNumber = beneficiary.cardNumber;
                    inv.beneficiaryIban = beneficiary.iban;
                }
            });
        }
        if (request._internalReview) {
            request.internalWorkflow = internalWorkflowsRes.rows.find(iwf => iwf.id === request._internalReview.internalWorkflowId);
            if (request.internalWorkflow?.steps) {
                 request.internalWorkflow.steps.forEach(s => s.assigneeName = personsMap.get(s.assigneeId)?.fullName);
            }
            if (request._internalReview.history) {
                 request._internalReview.history.forEach(h => h.personName = personsMap.get(h.personId)?.fullName);
            }
        }
        
        // Check if current user can start an internal review
        const loggedInUser = personsMap.get(request._activeSteps?.[0]?.assigneeId);
        const managerRoleRes = await pool.query(`SELECT id FROM "roles" WHERE name = 'مدیر واحد' LIMIT 1`);
        if (loggedInUser && managerRoleRes.rows.length > 0) {
            const managerRoleId = managerRoleRes.rows[0].id;
            request.canReferInternally = loggedInUser.roleIds?.includes(managerRoleId);
            const { rows: availableIWs } = await pool.query('SELECT * FROM "internalWorkflows" WHERE "unitId" = $1', [loggedInUser.unitId]);
            request.availableInternalWorkflows = availableIWs;
        }

        res.json(request);

    } catch (err) {
        handleApiError(err, res, `getting request with ID ${req.params.id}`);
    }
});

app.post('/api/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        const hashedPassword = hashPassword(password);
        const userQuery = `
            SELECT p.*, u.name as "unitName"
            FROM "persons" p
            LEFT JOIN "units" u ON p."unitId" = u.id
            WHERE p.username = $1 AND p.password = $2
        `;
        const { rows } = await pool.query(userQuery, [username, hashedPassword]);

        if (rows.length > 0) {
            const user = rows[0];
            user.position = user.unitName || 'بدون سمت';
            
            if (user.roleIds && user.roleIds.length > 0) {
                const rolesQuery = await pool.query('SELECT permissions FROM "roles" WHERE id = ANY($1)', [user.roleIds]);
                const permissions = new Set();
                rolesQuery.rows.forEach(role => {
                    (role.permissions || []).forEach(p => permissions.add(p));
                });
                user.permissions = Array.from(permissions);
            }
            
            logAction(user.id, 'LOGIN_SUCCESS', 'SYSTEM', user.id, { username: user.username });
            
            res.json(user);
        } else {
            res.status(401).json({ message: 'نام کاربری یا رمز عبور اشتباه است.' });
        }
    } catch (err) {
        handleApiError(err, res, 'logging in');
    }
});

app.post('/api/requests/submit', async (req, res) => {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const requestData = req.body;
        const { requestTypeId } = requestData;

        const workflowResult = await client.query('SELECT * FROM "workflows" WHERE "requestCategoryId" = $1', [requestTypeId]);
        if (workflowResult.rows.length === 0) return res.status(400).json({ message: `هیچ گردش کاری برای این نوع درخواست یافت نشد.` });
        
        const workflow = workflowResult.rows[0];
        if (!workflow.steps || workflow.steps.length === 0) return res.status(400).json({ message: `گردش کار ${workflow.id} هیچ مرحله‌ای ندارد.` });
        
        const firstStep = workflow.steps[0];
        if (!firstStep || !firstStep.assigneeRule) return res.status(400).json({ message: `گردش کار "${workflow.name}" دارای مرحله اول نامعتبر است.` });
        
        const firstAssigneeId = await findNextAssignee(firstStep.assigneeRule, requestData.requestingUnitId, client);

        if (!firstAssigneeId) return res.status(400).json({ message: `مسئول مرحله اول گردش کار (${workflow.name}) یافت نشد.` });

        const newRequestId = `SR-${Date.now()}`;
        const newRequest = {
            ...requestData,
            id: newRequestId,
            workflowId: workflow.id,
            status: 'IN_REVIEW',
            attachments: JSON.stringify(requestData.attachments || {}),
            invoices: JSON.stringify(requestData.invoices || []),
            _history: JSON.stringify([]),
            _activeSteps: JSON.stringify([{ stepId: firstStep.id, assigneeId: firstAssigneeId, startTimestamp: new Date().toISOString() }]),
        };

        const columns = Object.keys(newRequest).map(k => `"${k}"`).join(', ');
        const values = Object.values(newRequest);
        const valuePlaceholders = values.map((_, i) => `$${i + 1}`).join(', ');
        const query = `INSERT INTO "supplyRequests" (${columns}) VALUES (${valuePlaceholders}) RETURNING *`;
        const result = await client.query(query, values);
        
        const { rows: categories } = await client.query('SELECT label FROM "requestCategories" WHERE id = $1', [requestTypeId]);
        const categoryLabel = categories[0]?.label || 'جدید';
        const message = `درخواست ${categoryLabel} جدید برای شما ارسال شده است.`;
        await createNotification(client, firstAssigneeId, message, newRequestId);
        
        logAction(requestData.requesterId, 'SUBMIT_REQUEST', 'SUPPLY_REQUESTS', newRequestId, { amount: requestData.amount, requestType: categoryLabel });

        await client.query('COMMIT');
        res.status(201).json(result.rows[0]);
    } catch (err) {
        await client.query('ROLLBACK');
        handleApiError(err, res, 'submitting new request');
    } finally {
        client.release();
    }
});

app.post('/api/requests/:id/approve', async (req, res) => {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const { id } = req.params;
        const { personId, comment } = req.body;

        const requestRes = await client.query('SELECT * FROM "supplyRequests" WHERE id = $1 FOR UPDATE', [id]);
        if (requestRes.rows.length === 0) throw new Error('Request not found.');
        
        const request = requestRes.rows[0];
        if (request.status !== 'IN_REVIEW') throw new Error('Request is not in review status.');
        
        const activeStep = request._activeSteps[0];
        if (!activeStep || activeStep.assigneeId !== personId) throw new Error('User is not the current assignee.');

        const workflowRes = await client.query('SELECT * FROM "workflows" WHERE id = $1', [request.workflowId]);
        const workflow = workflowRes.rows[0];
        const currentStepIndex = workflow.steps.findIndex(s => s.id === activeStep.stepId);
        const { rows: persons } = await client.query('SELECT "fullName" FROM "persons" WHERE id = $1', [personId]);
        const approverName = persons[0]?.fullName || `کاربر ${personId}`;

        const newHistoryEntry = {
            ...activeStep,
            personId,
            action: 'APPROVE',
            comment,
            endTimestamp: new Date().toISOString(),
        };

        const newHistory = [...request._history, newHistoryEntry];
        let newActiveSteps = [];
        let newStatus = 'IN_REVIEW';

        const nextStep = workflow.steps[currentStepIndex + 1];
        if (nextStep) {
            const nextAssigneeId = await findNextAssignee(nextStep.assigneeRule, request.requestingUnitId, client);
            if (!nextAssigneeId) throw new Error(`Assignee for the next step "${nextStep.name}" could not be found.`);
            newActiveSteps = [{ stepId: nextStep.id, assigneeId: nextAssigneeId, startTimestamp: new Date().toISOString() }];
            const message = `درخواست شماره ${id} توسط ${approverName} تایید و برای شما ارسال شد.`;
            await createNotification(client, nextAssigneeId, message, id);
        } else {
            newStatus = 'APPROVED';
            const message = `درخواست شما به شماره ${id} تایید نهایی شد.`;
            await createNotification(client, request.requesterId, message, id);
        }
        
        const updateQuery = `
            UPDATE "supplyRequests"
            SET status = $1, "_activeSteps" = $2, _history = $3
            WHERE id = $4
            RETURNING *`;
        const updatedRequestRes = await client.query(updateQuery, [newStatus, JSON.stringify(newActiveSteps), JSON.stringify(newHistory), id]);
        
        logAction(personId, 'APPROVE_STEP', 'SUPPLY_REQUESTS', id, { stepName: workflow.steps[currentStepIndex].name, comment });

        await client.query('COMMIT');
        res.json(updatedRequestRes.rows[0]);

    } catch (err) {
        await client.query('ROLLBACK');
        handleApiError(err, res, `approving request ${req.params.id}`);
    } finally {
        client.release();
    }
});

app.post('/api/requests/:id/reject', async (req, res) => {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const { id } = req.params;
        const { personId, comment } = req.body;

        const requestRes = await client.query('SELECT * FROM "supplyRequests" WHERE id = $1 FOR UPDATE', [id]);
        if (requestRes.rows.length === 0) throw new Error('Request not found.');

        const request = requestRes.rows[0];
        if (request.status !== 'IN_REVIEW') throw new Error('Request is not in review status.');

        const activeStep = request._activeSteps[0];
        if (!activeStep || activeStep.assigneeId !== personId) throw new Error('User is not the current assignee.');

        const newHistoryEntry = {
            ...activeStep,
            personId,
            action: 'REJECT',
            comment,
            endTimestamp: new Date().toISOString(),
        };

        const newHistory = [...request._history, newHistoryEntry];
        const newStatus = 'REJECTED';
        
        const updateQuery = `
            UPDATE "supplyRequests"
            SET status = $1, "_activeSteps" = '[]'::jsonb, _history = $2
            WHERE id = $3
            RETURNING *`;
        const updatedRequestRes = await client.query(updateQuery, [newStatus, JSON.stringify(newHistory), id]);
        
        const { rows: persons } = await client.query('SELECT "fullName" FROM "persons" WHERE id = $1', [personId]);
        const rejecterName = persons[0]?.fullName || `کاربر ${personId}`;
        const message = `درخواست شما به شماره ${id} توسط ${rejecterName} رد شد.`;
        await createNotification(client, request.requesterId, message, id);
        
        const workflowRes = await client.query('SELECT steps FROM "workflows" WHERE id = $1', [request.workflowId]);
        const stepName = workflowRes.rows[0]?.steps.find(s => s.id === activeStep.stepId)?.name || 'Unknown Step';
        logAction(personId, 'REJECT_STEP', 'SUPPLY_REQUESTS', id, { stepName, comment });

        await client.query('COMMIT');
        res.json(updatedRequestRes.rows[0]);
    } catch (err) {
        await client.query('ROLLBACK');
        handleApiError(err, res, `rejecting request ${req.params.id}`);
    } finally {
        client.release();
    }
});

app.post('/api/requests/:id/resubmit', async (req, res) => {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const { id } = req.params;
        const updatedData = req.body;

        const requestRes = await client.query('SELECT * FROM "supplyRequests" WHERE id = $1 FOR UPDATE', [id]);
        if (requestRes.rows.length === 0) throw new Error('Request not found.');
        
        const request = requestRes.rows[0];
        if (request.status !== 'REJECTED') throw new Error('Only rejected requests can be resubmitted.');
        
        const workflowRes = await client.query('SELECT * FROM "workflows" WHERE id = $1', [request.workflowId]);
        const workflow = workflowRes.rows[0];
        const firstStep = workflow.steps[0];
        const firstAssigneeId = await findNextAssignee(firstStep.assigneeRule, request.requestingUnitId, client);

        if (!firstAssigneeId) throw new Error('Could not find assignee for the first step.');

        const newHistory = [...request._history, {
            stepId: null,
            personId: request.requesterId,
            action: 'RESUBMIT',
            startTimestamp: new Date().toISOString(),
            endTimestamp: new Date().toISOString()
        }];

        // Update fields from the form
        request.amount = updatedData.amount;
        request.currency = updatedData.currency;
        request.fundingSource = updatedData.fundingSource;
        request.attachments = updatedData.attachments;
        request.invoices = updatedData.invoices;
        request.itemDescription = updatedData.itemDescription;
        request.expenseType = updatedData.expenseType;
        request.imprestHolderId = updatedData.imprestHolderId;
        request.contractId = updatedData.contractId;
        request.paymentTermDescription = updatedData.paymentTermDescription;

        const updateQuery = `
            UPDATE "supplyRequests"
            SET
                status = 'IN_REVIEW',
                _activeSteps = $1,
                _history = $2,
                amount = $3, currency = $4, "fundingSource" = $5, attachments = $6, invoices = $7,
                "itemDescription" = $8, "expenseType" = $9, "imprestHolderId" = $10,
                "contractId" = $11, "paymentTermDescription" = $12
            WHERE id = $13
            RETURNING *`;
            
        const values = [
            JSON.stringify([{ stepId: firstStep.id, assigneeId: firstAssigneeId, startTimestamp: new Date().toISOString() }]),
            JSON.stringify(newHistory),
            request.amount, request.currency, request.fundingSource, JSON.stringify(request.attachments), JSON.stringify(request.invoices),
            request.itemDescription, request.expenseType, request.imprestHolderId,
            request.contractId, request.paymentTermDescription,
            id
        ];

        const updatedRequestRes = await client.query(updateQuery, values);

        const { rows: persons } = await client.query('SELECT "fullName" FROM "persons" WHERE id = $1', [request.requesterId]);
        const resubmitterName = persons[0]?.fullName || `کاربر ${request.requesterId}`;
        const message = `درخواست رد شده شماره ${id} توسط ${resubmitterName} اصلاح و برای شما ارسال شد.`;
        await createNotification(client, firstAssigneeId, message, id);
        
        logAction(request.requesterId, 'RESUBMIT_REQUEST', 'SUPPLY_REQUESTS', id, { updatedAmount: request.amount });

        await client.query('COMMIT');
        res.json(updatedRequestRes.rows[0]);

    } catch(err) {
        await client.query('ROLLBACK');
        handleApiError(err, res, `resubmitting request ${req.params.id}`);
    } finally {
        client.release();
    }
});

app.post('/api/requests/:id/internal-review/start', async (req, res) => {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const { id } = req.params;
        const { mainStepId, mainAssigneeId, internalWorkflowId, comment } = req.body;

        const requestRes = await client.query('SELECT * FROM "supplyRequests" WHERE id = $1 FOR UPDATE', [id]);
        if (requestRes.rows.length === 0) throw new Error('Request not found.');
        
        const request = requestRes.rows[0];
        if (request.status !== 'IN_REVIEW') throw new Error('Request is not in review status.');
        if (request._internalReview) throw new Error('Request is already under internal review.');
        
        const activeStep = request._activeSteps[0];
        if (!activeStep || activeStep.assigneeId !== mainAssigneeId || activeStep.stepId !== mainStepId) {
            throw new Error('User is not the current assignee for this step.');
        }

        const internalWorkflowRes = await client.query('SELECT * FROM "internalWorkflows" WHERE id = $1', [internalWorkflowId]);
        if (internalWorkflowRes.rows.length === 0) throw new Error('Internal workflow not found.');
        
        const internalWorkflow = internalWorkflowRes.rows[0];
        if (!internalWorkflow.steps || internalWorkflow.steps.length === 0) throw new Error('Internal workflow has no steps.');
        
        const firstStep = internalWorkflow.steps[0];
        
        const internalReviewObject = {
            mainStepId,
            mainAssigneeId,
            internalWorkflowId,
            history: [],
            activeInternalStepId: firstStep.id,
            activeInternalAssigneeId: firstStep.assigneeId,
            initiatorComment: comment,
        };
        
        const newHistoryEntry = {
            stepId: mainStepId,
            personId: mainAssigneeId,
            action: 'INTERNAL_REVIEW_START',
            comment,
            startTimestamp: new Date().toISOString(),
            endTimestamp: new Date().toISOString(), // Start and end are the same for an instantaneous action
        };

        const newHistory = [...request._history, newHistoryEntry];
        
        const updateQuery = `
            UPDATE "supplyRequests"
            SET "_internalReview" = $1, _history = $2
            WHERE id = $3
            RETURNING *`;
        const updatedRequestRes = await client.query(updateQuery, [JSON.stringify(internalReviewObject), JSON.stringify(newHistory), id]);
        
        logAction(mainAssigneeId, 'START_INTERNAL_REVIEW', 'SUPPLY_REQUESTS', id, { internalWorkflow: internalWorkflow.name, comment });
        
        await client.query('COMMIT');
        res.json(updatedRequestRes.rows[0]);

    } catch (err) {
        await client.query('ROLLBACK');
        handleApiError(err, res, `starting internal review for request ${req.params.id}`);
    } finally {
        client.release();
    }
});

app.post('/api/requests/:id/internal-review/advance', async (req, res) => {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const { id } = req.params;
        const { currentInternalStepId, personId, action, comment } = req.body;

        const requestRes = await client.query('SELECT * FROM "supplyRequests" WHERE id = $1 FOR UPDATE', [id]);
        if (requestRes.rows.length === 0) throw new Error('Request not found.');

        const request = requestRes.rows[0];
        const internalReview = request._internalReview;
        if (!internalReview) throw new Error('Request is not under internal review.');
        if (internalReview.activeInternalAssigneeId !== personId) throw new Error('User is not the current internal assignee.');
        if (internalReview.activeInternalStepId !== currentInternalStepId) throw new Error('Action is being taken on a stale step.');

        const internalWorkflowRes = await client.query('SELECT * FROM "internalWorkflows" WHERE id = $1', [internalReview.internalWorkflowId]);
        const internalWorkflow = internalWorkflowRes.rows[0];
        const currentStepIndex = internalWorkflow.steps.findIndex(s => s.id === internalReview.activeInternalStepId);

        const newHistoryEntry = {
            stepId: internalReview.activeInternalStepId,
            personId,
            action,
            comment,
            timestamp: new Date().toISOString(),
        };
        internalReview.history.push(newHistoryEntry);
        
        let finalInternalReviewDetails = null;
        let newInternalReviewState = internalReview;

        if (action === 'RETURN_TO_MANAGER') {
            finalInternalReviewDetails = { ...internalReview, finalAction: 'RETURN_TO_MANAGER', completionTimestamp: new Date().toISOString() };
            newInternalReviewState = null;
        } else { // 'FORWARD'
            const nextStep = internalWorkflow.steps[currentStepIndex + 1];
            if (nextStep) {
                newInternalReviewState.activeInternalStepId = nextStep.id;
                newInternalReviewState.activeInternalAssigneeId = nextStep.assigneeId;
            } else {
                // Last step, review is complete
                finalInternalReviewDetails = { ...internalReview, finalAction: 'FORWARDED_COMPLETE', completionTimestamp: new Date().toISOString() };
                newInternalReviewState = null;
            }
        }
        
        let newHistory = request._history;
        if (finalInternalReviewDetails) {
            newHistory.push({
                stepId: internalReview.mainStepId,
                personId: internalReview.mainAssigneeId,
                action: 'INTERNAL_REVIEW_END',
                comment: `Internal review process completed.`,
                startTimestamp: finalInternalReviewDetails.history[0]?.timestamp || new Date().toISOString(),
                endTimestamp: new Date().toISOString(),
                internalReviewDetails: finalInternalReviewDetails
            });
        }
        
        const updateQuery = `
            UPDATE "supplyRequests"
            SET "_internalReview" = $1, "_history" = $2
            WHERE id = $3
            RETURNING *`;
        const updatedRequestRes = await client.query(updateQuery, [
            newInternalReviewState ? JSON.stringify(newInternalReviewState) : null, 
            JSON.stringify(newHistory), 
            id
        ]);
        
        logAction(personId, 'ADVANCE_INTERNAL_REVIEW', 'SUPPLY_REQUESTS', id, { internalStep: internalWorkflow.steps[currentStepIndex].name, comment, action });
        
        await client.query('COMMIT');
        res.json(updatedRequestRes.rows[0]);

    } catch (err) {
        await client.query('ROLLBACK');
        handleApiError(err, res, `advancing internal review for request ${req.params.id}`);
    } finally {
        client.release();
    }
});


app.get('/api/dashboard/summary', async (req, res) => {
    try {
        const { userId } = req.query;
        if (!userId) return res.status(400).json({ message: 'userId is required' });

        const myPendingTasksQuery = `SELECT COUNT(*) FROM "supplyRequests" WHERE status = 'IN_REVIEW' AND "_activeSteps" @> $1::jsonb`;
        const myRecentSubmissionsQuery = `SELECT COUNT(*) FROM "supplyRequests" WHERE "requesterId" = $1 AND "submissionDateForSort"::timestamptz >= NOW() - INTERVAL '30 days'`;
        const totalPendingQuery = `SELECT COUNT(*) FROM "supplyRequests" WHERE status = 'IN_REVIEW'`;
        const totalApprovedThisMonthQuery = `SELECT SUM(amount) FROM "supplyRequests" WHERE status = 'APPROVED' AND "submissionDateForSort"::timestamptz >= date_trunc('month', NOW())`;

        const jsonbParam = JSON.stringify([{ assigneeId: parseInt(String(userId), 10) }]);
        const [pResult, sResult, tpResult, aResult] = await Promise.all([
            pool.query(myPendingTasksQuery, [jsonbParam]),
            pool.query(myRecentSubmissionsQuery, [userId]),
            pool.query(totalPendingQuery),
            pool.query(totalApprovedThisMonthQuery)
        ]);
        res.json({
            myPendingTasks: parseInt(pResult.rows[0].count, 10),
            myRecentSubmissions: parseInt(sResult.rows[0].count, 10),
            totalPending: parseInt(tpResult.rows[0].count, 10),
            totalApprovedThisMonth: parseFloat(aResult.rows[0].sum) || 0,
        });
    } catch (err) {
        handleApiError(err, res, 'getting dashboard summary');
    }
});

app.post('/api/dashboard/requests', async (req, res) => {
    try {
        const userId = parseInt(String(req.body.userId), 10);
        const page = parseInt(String(req.query.page)) || 1;
        const itemsPerPage = 10;
        const offset = (page - 1) * itemsPerPage;
        if (!userId || isNaN(userId)) return res.status(400).json({ message: 'A valid userId is required' });

        const whereClause = `s."requesterId" = $1 OR (s.status = 'IN_REVIEW' AND s."_activeSteps" @> $2::jsonb)`;
        const queryParams = [userId, JSON.stringify([{ assigneeId: userId }])];
        
        const totalQuery = `SELECT COUNT(*) FROM "supplyRequests" s WHERE ${whereClause}`;
        const totalResult = await pool.query(totalQuery, queryParams);
        const total = parseInt(totalResult.rows[0].count, 10);
        
        // PERFORMANCE: Join workflow data directly in the query to avoid N+1 fetches on the client
        const dataQuery = `
            SELECT s.*, 
                   p."fullName" as "requesterName", 
                   rc.label as "requestCategoryLabel",
                   to_jsonb(w) as workflow
            FROM "supplyRequests" s
            LEFT JOIN "persons" p ON s."requesterId" = p.id
            LEFT JOIN "requestCategories" rc ON s."requestTypeId" = rc.id
            LEFT JOIN "workflows" w ON s."workflowId" = w.id
            WHERE ${whereClause} ORDER BY s."submissionDateForSort" DESC LIMIT $3 OFFSET $4`;
        const dataResult = await pool.query(dataQuery, [...queryParams, itemsPerPage, offset]);
        res.json({ data: dataResult.rows, total });
    } catch (err) {
        handleApiError(err, res, 'getting dashboard requests');
    }
});

app.post('/api/reports/invoice-items', async (req, res) => {
    try {
        const filters = req.body;
        const page = parseInt(String(req.query.page)) || 1;
        const itemsPerPage = 20;
        const offset = (page - 1) * itemsPerPage;
        let whereClauses = [];
        let queryParams = [];
        let paramIndex = 1;

        const { q, beneficiaryId, requestingUnitId, dateFrom, dateTo, priceFrom, priceTo, fundingSource, expenseType } = filters;

        if (q) { whereClauses.push(`item.description ILIKE $${paramIndex++}`); queryParams.push(`%${q}%`); }
        if (beneficiaryId) { whereClauses.push(`inv."beneficiaryId" = $${paramIndex++}`); queryParams.push(parseInt(beneficiaryId)); }
        if (requestingUnitId) { whereClauses.push(`req."requestingUnitId" = $${paramIndex++}`); queryParams.push(parseInt(requestingUnitId)); }
        if (dateFrom) { whereClauses.push(`req."submissionDateForSort" >= $${paramIndex++}`); queryParams.push(dateFrom); }
        if (dateTo) { whereClauses.push(`req."submissionDateForSort" <= $${paramIndex++}`); queryParams.push(dateTo); }
        if (priceFrom) { whereClauses.push(`item."unitPrice" >= $${paramIndex++}`); queryParams.push(parseFloat(priceFrom)); }
        if (priceTo) { whereClauses.push(`item."unitPrice" <= $${paramIndex++}`); queryParams.push(parseFloat(priceTo)); }
        if (fundingSource) { whereClauses.push(`req."fundingSource" = $${paramIndex++}`); queryParams.push(fundingSource); }
        if (expenseType) { whereClauses.push(`req."expenseType" = $${paramIndex++}`); queryParams.push(expenseType); }


        const whereString = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';

        const baseQuery = `
            FROM "supplyRequests" req
            JOIN LATERAL jsonb_to_recordset(req.invoices) AS inv(id int, "invoiceNumber" text, "beneficiaryId" int, "attachmentName" text, "attachmentUrl" text, items jsonb) ON true
            JOIN LATERAL jsonb_to_recordset(inv.items) AS item(description text, quantity numeric, "unitPrice" numeric) ON true
            LEFT JOIN "persons" AS beneficiary ON inv."beneficiaryId" = beneficiary.id
            LEFT JOIN "units" AS unit ON req."requestingUnitId" = unit.id
            ${whereString}
        `;

        const totalQuery = `SELECT COUNT(*) ${baseQuery}`;
        const totalResult = await pool.query(totalQuery, queryParams);
        const total = parseInt(totalResult.rows[0].count, 10);

        const dataQuery = `
            SELECT
                row_number() over (ORDER BY req."submissionDateForSort" DESC) as id,
                item.description,
                item.quantity,
                item."unitPrice",
                req.id as "requestId",
                req."submissionDate",
                req.currency,
                beneficiary."fullName" as "beneficiaryName",
                unit.name as "requestingUnitName"
            ${baseQuery}
            ORDER BY req."submissionDateForSort" DESC
            LIMIT $${paramIndex++} OFFSET $${paramIndex++}
        `;
        const dataResult = await pool.query(dataQuery, [...queryParams, itemsPerPage, offset]);

        res.json({ data: dataResult.rows, total });
    } catch (err) {
        handleApiError(err, res, 'searching invoice items');
    }
});


app.post('/api/reports/search', async (req, res) => {
    try {
        const filters = req.body;
        const page = parseInt(String(req.query.page)) || 1;
        const itemsPerPage = 20;
        const offset = (page - 1) * itemsPerPage;
        let whereClauses = [];
        let queryParams = [];
        let paramIndex = 1;

        const { status, requestTypeId, workflowId, requesterId, requestingUnitId, dateFrom, dateTo, amountFrom, amountTo, imprestHolderId, assigneeId } = filters;
        
        if (status) { whereClauses.push(`s.status = $${paramIndex++}`); queryParams.push(status); }
        if (requestTypeId) { whereClauses.push(`s."requestTypeId" = $${paramIndex++}`); queryParams.push(parseInt(String(requestTypeId), 10)); }
        if (workflowId) { whereClauses.push(`s."workflowId" = $${paramIndex++}`); queryParams.push(parseInt(String(workflowId), 10)); }
        if (requesterId) { whereClauses.push(`s."requesterId" = $${paramIndex++}`); queryParams.push(parseInt(String(requesterId), 10)); }
        if (requestingUnitId) { whereClauses.push(`s."requestingUnitId" = $${paramIndex++}`); queryParams.push(parseInt(String(requestingUnitId), 10)); }
        if (imprestHolderId) { whereClauses.push(`s."imprestHolderId" = $${paramIndex++}`); queryParams.push(parseInt(String(imprestHolderId), 10)); }
        if (dateFrom) { whereClauses.push(`s."submissionDateForSort" >= $${paramIndex++}`); queryParams.push(dateFrom); }
        if (dateTo) { whereClauses.push(`s."submissionDateForSort" <= $${paramIndex++}`); queryParams.push(dateTo); }
        if (amountFrom || amountFrom === 0) { whereClauses.push(`s.amount >= $${paramIndex++}`); queryParams.push(parseFloat(String(amountFrom))); }
        if (amountTo || amountTo === 0) { whereClauses.push(`s.amount <= $${paramIndex++}`); queryParams.push(parseFloat(String(amountTo))); }
        if (assigneeId) {
            whereClauses.push(`s."_activeSteps" @> $${paramIndex++}::jsonb`);
            queryParams.push(JSON.stringify([{ assigneeId: parseInt(String(assigneeId), 10) }]));
        }
        
        const whereString = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';
        
        const totalQuery = `SELECT COUNT(*) FROM "supplyRequests" s ${whereString}`;
        const totalResult = await pool.query(totalQuery, queryParams);
        const total = parseInt(totalResult.rows[0].count, 10);
        
        const dataQuery = `
            SELECT s.*, p."fullName" as "requesterName", rc.label as "requestCategoryLabel",
                   to_jsonb(w) as workflow
            FROM "supplyRequests" s
            LEFT JOIN "persons" p ON s."requesterId" = p.id
            LEFT JOIN "requestCategories" rc ON s."requestTypeId" = rc.id
            LEFT JOIN "workflows" w ON s."workflowId" = w.id
            ${whereString} ORDER BY s."submissionDateForSort" DESC LIMIT $${paramIndex++} OFFSET $${paramIndex++}`;
        const dataResult = await pool.query(dataQuery, [...queryParams, itemsPerPage, offset]);
        res.json({ data: dataResult.rows, total });
    } catch (err) {
        handleApiError(err, res, 'searching reports');
    }
});

app.post('/api/reports/summary', async (req, res) => {
    try {
        const filters = req.body;
        let whereClauses = [];
        let queryParams = [];
        let paramIndex = 1;

        const { status, requestTypeId, workflowId, requesterId, requestingUnitId, dateFrom, dateTo, amountFrom, amountTo, imprestHolderId, assigneeId } = filters;

        if (status) { whereClauses.push(`status = $${paramIndex++}`); queryParams.push(status); }
        if (requestTypeId) { whereClauses.push(`"requestTypeId" = $${paramIndex++}`); queryParams.push(parseInt(String(requestTypeId), 10)); }
        if (workflowId) { whereClauses.push(`"workflowId" = $${paramIndex++}`); queryParams.push(parseInt(String(workflowId), 10)); }
        if (requesterId) { whereClauses.push(`"requesterId" = $${paramIndex++}`); queryParams.push(parseInt(String(requesterId), 10)); }
        if (requestingUnitId) { whereClauses.push(`"requestingUnitId" = $${paramIndex++}`); queryParams.push(parseInt(String(requestingUnitId), 10)); }
        if (imprestHolderId) { whereClauses.push(`"imprestHolderId" = $${paramIndex++}`); queryParams.push(parseInt(String(imprestHolderId), 10)); }
        if (dateFrom) { whereClauses.push(`"submissionDateForSort" >= $${paramIndex++}`); queryParams.push(dateFrom); }
        if (dateTo) { whereClauses.push(`"submissionDateForSort" <= $${paramIndex++}`); queryParams.push(dateTo); }
        if (amountFrom || amountFrom === 0) { whereClauses.push(`amount >= $${paramIndex++}`); queryParams.push(parseFloat(String(amountFrom))); }
        if (amountTo || amountTo === 0) { whereClauses.push(`amount <= $${paramIndex++}`); queryParams.push(parseFloat(String(amountTo))); }
        if (assigneeId) {
            whereClauses.push(`"_activeSteps" @> $${paramIndex++}::jsonb`);
            queryParams.push(JSON.stringify([{ assigneeId: parseInt(String(assigneeId), 10) }]));
        }

        const whereString = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';

        const approvedParams = [...queryParams];
        let approvedWhereClauses = [...whereClauses];
        approvedWhereClauses.push(`status = $${approvedParams.length + 1}`);
        approvedParams.push('APPROVED');
        const approvedWhereString = `WHERE ${approvedWhereClauses.join(' AND ')}`;
        
        const [
            totalReqResult,
            totalApprovedAmountResult,
            statusCountsResult,
            topUnitsResult
        ] = await Promise.all([
            pool.query(`SELECT COUNT(*) FROM "supplyRequests" ${whereString}`, queryParams),
            pool.query(`SELECT SUM(amount) FROM "supplyRequests" ${approvedWhereString}`, approvedParams),
            pool.query(`SELECT status, COUNT(*) FROM "supplyRequests" ${whereString} GROUP BY status`, queryParams),
            pool.query(`
                SELECT "requestingUnitId", SUM(amount) AS "totalAmount"
                FROM "supplyRequests"
                ${approvedWhereString}
                GROUP BY "requestingUnitId"
                ORDER BY "totalAmount" DESC
                LIMIT 5
            `, approvedParams)
        ]);
        
        const requestsByStatus = { IN_REVIEW: 0, APPROVED: 0, REJECTED: 0 };
        statusCountsResult.rows.forEach(row => {
            if (requestsByStatus.hasOwnProperty(row.status)) {
                requestsByStatus[row.status] = parseInt(row.count, 10);
            }
        });

        res.json({
            totalRequests: parseInt(totalReqResult.rows[0].count, 10),
            totalApprovedAmount: parseFloat(totalApprovedAmountResult.rows[0].sum) || 0,
            requestsByStatus,
            topRequestingUnits: topUnitsResult.rows.map(r => ({ requestingUnitId: r.requestingunitid, totalAmount: parseFloat(r.totalamount) }))
        });
    } catch (err) {
        handleApiError(err, res, 'getting reports summary');
    }
});

app.get('/api/units/tree', async (req, res) => {
    try {
        const { rows: units } = await pool.query('SELECT * FROM "units"');
        const { rows: persons } = await pool.query('SELECT id, "fullName", "unitId" FROM "persons" WHERE "unitId" IS NOT NULL');
        
        const unitMap = new Map(units.map(u => [u.id, { ...u, children: [], persons: [] }]));
        const tree = [];

        persons.forEach(p => {
            if (p.unitId && unitMap.has(p.unitId)) {
                unitMap.get(p.unitId).persons.push(p);
            }
        });

        units.forEach(u => {
            if (u.parentId && unitMap.has(u.parentId)) {
                unitMap.get(u.parentId).children.push(unitMap.get(u.id));
            } else {
                tree.push(unitMap.get(u.id));
            }
        });
        
        res.json(tree);
    } catch (err) {
        handleApiError(err, res, 'getting units tree');
    }
});

app.post('/api/units/:id/persons', async (req, res) => {
    try {
        const { id: unitId } = req.params;
        const { personId, actingUserId } = req.body;

        await pool.query('BEGIN');
        await pool.query('UPDATE "persons" SET "unitId" = NULL WHERE id = $1', [personId]);
        await pool.query('UPDATE "persons" SET "unitId" = $1 WHERE id = $2', [unitId, personId]);
        await pool.query('COMMIT');

        logAction(actingUserId, 'ASSIGN_PERSON_TO_UNIT', 'UNITS', unitId, { personId });
        
        res.json({ success: true });
    } catch (err) {
        await pool.query('ROLLBACK');
        handleApiError(err, res, `assigning person to unit`);
    }
});

app.delete('/api/units/:unitId/persons/:personId', async (req, res) => {
    try {
        const { unitId, personId } = req.params;
        const { actingUserId } = req.body;
        await pool.query('UPDATE "persons" SET "unitId" = NULL WHERE id = $1', [personId]);
        logAction(actingUserId, 'UNASSIGN_PERSON_FROM_UNIT', 'UNITS', unitId, { personId });
        res.json({ success: true });
    } catch (err) {
        handleApiError(err, res, `unassigning person from unit`);
    }
});


app.put('/api/persons/:id/reset-password', async (req, res) => {
    try {
        const { id } = req.params;
        const { newPassword, actingUserId } = req.body;
        if (!newPassword) return res.status(400).json({ message: "New password is required." });
        const hashedPassword = hashPassword(newPassword);
        await pool.query('UPDATE "persons" SET password = $1, "forcePasswordChange" = true WHERE id = $2', [hashedPassword, id]);
        logAction(actingUserId, 'RESET_PASSWORD', 'PERSONS', id);
        res.json({ success: true });
    } catch (err) {
        handleApiError(err, res, `resetting password for user ${req.params.id}`);
    }
});


app.post('/api/persons/:id/revoke-access', async (req, res) => {
    try {
        const { id } = req.params;
        const { actingUserId } = req.body;
        await pool.query(`UPDATE "persons" SET username = NULL, password = NULL, "isSystemUser" = false, "roleIds" = '{}' WHERE id = $1`, [id]);
        logAction(actingUserId, 'REVOKE_ACCESS', 'PERSONS', id);
        res.json({ success: true });
    } catch (err) {
        handleApiError(err, res, `revoking access for user ${req.params.id}`);
    }
});

app.put('/api/persons/:id/change-password', async (req, res) => {
    try {
        const { id } = req.params;
        const { currentPassword, newPassword } = req.body;
        const hashedCurrent = hashPassword(currentPassword);

        const { rows } = await pool.query('SELECT password FROM "persons" WHERE id = $1', [id]);
        if (rows.length === 0) return res.status(404).json({ message: 'User not found.' });
        if (rows[0].password !== hashedCurrent) return res.status(403).json({ message: 'گذرواژه فعلی صحیح نمی‌باشد.' });

        const hashedNew = hashPassword(newPassword);
        await pool.query('UPDATE "persons" SET password = $1, "forcePasswordChange" = false WHERE id = $2', [hashedNew, id]);
        logAction(id, 'CHANGE_PASSWORD', 'PERSONS', id);
        res.json({ success: true });
    } catch (err) {
        handleApiError(err, res, `changing password for user ${req.params.id}`);
    }
});

app.post('/api/persons/:id/verify-password', async (req, res) => {
    try {
        const { id } = req.params;
        const { password } = req.body;
        const hashedPassword = hashPassword(password);
        const { rows } = await pool.query('SELECT 1 FROM "persons" WHERE id = $1 AND password = $2', [id, hashedPassword]);
        res.json({ success: rows.length > 0 });
    } catch (err) {
        handleApiError(err, res, `verifying password for user ${req.params.id}`);
    }
});

app.get('/api/persons/:id/petty-cash-status', async (req, res) => {
    const { id } = req.params;
    const client = await pool.connect();
    try {
        const personRes = await client.query('SELECT "pettyCashLimit" FROM "persons" WHERE id = $1', [id]);
        if (personRes.rows.length === 0) {
            return res.status(404).json({ message: 'Person not found.' });
        }
        const limit = personRes.rows[0].pettyCashLimit || 0;

        const categoryRes = await client.query("SELECT id FROM \"requestCategories\" WHERE key = 'PETTY_CASH'");
        if (categoryRes.rows.length === 0) {
            return res.json({ limit, outstandingAmount: 0, availableBalance: limit });
        }
        const pettyCashTypeId = categoryRes.rows[0].id;
        
        const outstandingRes = await client.query(
            'SELECT SUM(amount) as total FROM "supplyRequests" WHERE "requesterId" = $1 AND "requestTypeId" = $2 AND status IN ($3, $4)',
            [id, pettyCashTypeId, 'IN_REVIEW', 'APPROVED']
        );
        
        const outstandingAmount = parseFloat(outstandingRes.rows[0].total) || 0;
        const availableBalance = limit - outstandingAmount;

        res.json({ limit, outstandingAmount, availableBalance });

    } catch (err) {
        handleApiError(err, res, `getting petty cash status for person ${id}`);
    } finally {
        client.release();
    }
});


// --- Notification Endpoints ---
app.get('/api/notifications', async (req, res) => {
    try {
        // This endpoint needs to know the user. In a real app, this would come from a session/token.
        // For this context, we'll assume the client sends the userId.
        const { userId } = req.query;
        if (!userId) return res.status(401).json({ message: "User not identified." });

        const notificationsQuery = `
            SELECT * FROM "notifications"
            WHERE "personId" = $1
            ORDER BY "createdAt" DESC
            LIMIT 20
        `;
        const unreadCountQuery = `
            SELECT COUNT(*) FROM "notifications"
            WHERE "personId" = $1 AND "isRead" = false
        `;

        const [notificationsResult, unreadCountResult] = await Promise.all([
            pool.query(notificationsQuery, [userId]),
            pool.query(unreadCountQuery, [userId])
        ]);

        res.json({
            notifications: notificationsResult.rows,
            unreadCount: parseInt(unreadCountResult.rows[0].count, 10),
        });

    } catch(err) {
        // FIX: Add a check for PostgreSQL's "undefined table" error code (42P01).
        // If the "notifications" table does not exist, gracefully return an empty
        // response instead of a 500 error. This makes the feature optional
        // if the database schema hasn't been updated yet.
        if (err.code === '42P01') { 
            console.warn('[SERVER_WARNING] "notifications" table does not exist. Returning empty notifications. Please update your database schema.');
            res.json({
                notifications: [],
                unreadCount: 0,
            });
        } else {
            handleApiError(err, res, 'getting notifications');
        }
    }
});

app.post('/api/notifications/mark-read', async (req, res) => {
    try {
        const { userId, notificationIds } = req.body;
         if (!userId) return res.status(401).json({ message: "User not identified." });
         
        if (Array.isArray(notificationIds) && notificationIds.length > 0) {
            await pool.query('UPDATE "notifications" SET "isRead" = true WHERE "personId" = $1 AND id = ANY($2::int[])', [userId, notificationIds]);
        } else {
            // If no specific IDs, mark all as read for the user
            await pool.query('UPDATE "notifications" SET "isRead" = true WHERE "personId" = $1', [userId]);
        }
        res.status(204).send();
    } catch(err) {
        // FIX: Gracefully handle cases where the notifications table might not exist.
        if (err.code === '42P01') { 
            console.warn('[SERVER_WARNING] "notifications" table does not exist. Ignoring mark-read request.');
            res.status(204).send();
        } else {
            handleApiError(err, res, 'marking notifications as read');
        }
    }
});


// --- Appearance Settings Endpoints ---
const APPEARANCE_SETTINGS_PATH = path.join(__dirname, 'appearanceSettings.json');
const DEFAULT_APPEARANCE_SETTINGS = {
    mode: 'default',
    staticImageId: null,
    images: [],
};

app.get('/api/appearanceSettings', async (req, res) => {
    try {
        if (fs.existsSync(APPEARANCE_SETTINGS_PATH)) {
            const fileContent = await fs.promises.readFile(APPEARANCE_SETTINGS_PATH, 'utf8');
            if (fileContent.trim() === '') {
                res.json(DEFAULT_APPEARANCE_SETTINGS);
            } else {
                res.json(JSON.parse(fileContent));
            }
        } else {
            res.json(DEFAULT_APPEARANCE_SETTINGS);
        }
    } catch (err) {
        if (err instanceof SyntaxError) {
            console.error(`[SERVER_WARNING] Malformed ${APPEARANCE_SETTINGS_PATH}. Serving default settings.`);
            res.json(DEFAULT_APPEARANCE_SETTINGS);
        } else {
            handleApiError(err, res, 'getting appearance settings');
        }
    }
});

app.post('/api/appearanceSettings', async (req, res) => {
    try {
        const { settings, actingUserId } = req.body;
        if (!settings || !['default', 'static', 'slideshow'].includes(settings.mode)) {
            return res.status(400).json({ message: 'Invalid settings format.' });
        }
        await fs.promises.writeFile(APPEARANCE_SETTINGS_PATH, JSON.stringify(settings, null, 2), 'utf8');
        logAction(actingUserId, 'UPDATE', 'APPEARANCE_SETTINGS', '1', { newMode: settings.mode });
        res.json(settings);
    } catch (err) {
        handleApiError(err, res, 'updating appearance settings');
    }
});

// --- Tip Management Endpoints ---
const TIPS_SETTINGS_PATH = path.join(__dirname, 'tipsSettings.json');
const DEFAULT_TIPS_SETTINGS = {
    tips: ["برای شروع، از این صفحه نکته‌های خود را اضافه کنید."],
    avatar: "",
};

app.get('/api/tips-settings', async (req, res) => {
    try {
        if (fs.existsSync(TIPS_SETTINGS_PATH)) {
            const fileContent = await fs.promises.readFile(TIPS_SETTINGS_PATH, 'utf8');
            res.json(JSON.parse(fileContent));
        } else {
            res.json(DEFAULT_TIPS_SETTINGS);
        }
    } catch (err) {
        console.error(`[SERVER_WARNING] Could not read ${TIPS_SETTINGS_PATH}. Serving default tips.`);
        res.json(DEFAULT_TIPS_SETTINGS);
    }
});

app.post('/api/tips-settings', async (req, res) => {
    try {
        const { settings, actingUserId } = req.body;
        if (!settings || !Array.isArray(settings.tips)) {
            return res.status(400).json({ message: 'Invalid tips format.' });
        }
        await fs.promises.writeFile(TIPS_SETTINGS_PATH, JSON.stringify(settings, null, 2), 'utf8');
        logAction(actingUserId, 'UPDATE', 'TIPS_SETTINGS', '1', { tipCount: settings.tips.length });
        res.json(settings);
    } catch (err) {
        handleApiError(err, res, 'updating tips settings');
    }
});


// --- Security Endpoints ---
app.get('/api/security/summary', async (req, res) => {
    try {
        const totalUsersQuery = `SELECT COUNT(*) FROM "persons" WHERE "isSystemUser" = true`;
        const adminUsersQuery = `SELECT COUNT(*) FROM "persons" WHERE "isSystemUser" = true AND 1 = ANY("roleIds")`;
        const forceChangeQuery = `SELECT COUNT(*) FROM "persons" WHERE "isSystemUser" = true AND "forcePasswordChange" = true`;
        const noExpiryQuery = `SELECT COUNT(*) FROM "persons" WHERE "isSystemUser" = true AND "passwordNoExpiration" = true`;

        const [
            totalUsersResult,
            adminUsersResult,
            forceChangeResult,
            noExpiryResult
        ] = await Promise.all([
            pool.query(totalUsersQuery),
            pool.query(adminUsersQuery),
            pool.query(forceChangeQuery),
            pool.query(noExpiryQuery)
        ]);
        
        res.json({
            totalUsers: parseInt(totalUsersResult.rows[0].count, 10),
            adminUsers: parseInt(adminUsersResult.rows[0].count, 10),
            forceChangeUsers: parseInt(forceChangeResult.rows[0].count, 10),
            noExpiryUsers: parseInt(noExpiryResult.rows[0].count, 10),
        });

    } catch (err) {
        handleApiError(err, res, 'getting security summary');
    }
});


// --- Health Check ---
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok' });
});

app.get('/api/init-check', async (req, res) => {
    try {
        const client = await pool.connect();
        try {
            const result = await client.query("SELECT to_regclass('public.persons')");
            const initialized = result.rows[0].to_regclass !== null;
            res.json({ initialized });
        } finally {
            client.release();
        }
    } catch (err) {
        const message = err.message || 'Database connection failed. Check connection details in .env file.';
         res.status(500).json({ initialized: false, message });
    }
});


app.get('/api/backup/create', async (req, res) => {
    try {
        const client = await pool.connect();
        let sqlContent = '';
        try {
            const tablesResult = await client.query(`
                SELECT tablename FROM pg_tables
                WHERE schemaname = 'public'
                ORDER BY tablename;
            `);
            const tables = tablesResult.rows.map(row => row.tablename);

            for (const table of tables) {
                sqlContent += `-- Data for table: ${table}\n`;
                const { rows } = await client.query(`SELECT * FROM "${table}"`);
                if (rows.length > 0) {
                    const columns = Object.keys(rows[0]).map(c => `"${c}"`).join(', ');
                    for (const row of rows) {
                        const values = Object.values(row).map(val => {
                            if (val === null) return 'NULL';
                            if (typeof val === 'number') return val;
                            if (typeof val === 'boolean') return val;
                            if (Array.isArray(val) || (typeof val === 'object' && val !== null)) {
                                return `'${JSON.stringify(val).replace(/'/g, "''")}'`;
                            }
                            return `'${String(val).replace(/'/g, "''")}'`;
                        }).join(', ');
                        sqlContent += `INSERT INTO "${table}" (${columns}) VALUES (${values});\n`;
                    }
                }
                sqlContent += '\n';
            }
            res.header('Content-Type', 'application/sql');
            res.send(sqlContent);
        } finally {
            client.release();
        }
    } catch (err) {
        handleApiError(err, res, 'creating database backup');
    }
});

// All other GET requests not handled before will return the React app
app.get('*', (req, res) => {
  res.sendFile(path.join(buildPath, 'index.html'));
});

// --- Permission Migration and Server Start ---

const ALL_RESOURCES = [
    'DASHBOARD', 'REPORTS', 'UNITS', 'PROJECTS', 'PERSONS', 'BENEFICIARIES',
    'ROLES', 'WORKFLOW', 'CONTRACTS', 'INTERNAL_WORKFLOWS', 'DEBIT',
    'REQUEST_TYPES', 'PROFILE', 'SECURITY', 'APPEARANCE'
];
const CRUD_ACTIONS = ['read', 'create', 'update', 'delete'];
const generateAllPermissions = () => {
    const permissions = new Set();
    for (const resource of ALL_RESOURCES) {
        for (const action of CRUD_ACTIONS) {
            permissions.add(`${resource}:${action}`);
        }
    }
    // FIX: Explicitly add SECURITY:read for ROLES and AUDIT_LOG to ensure sidebar visibility.
    permissions.add('ROLES:read');
    permissions.add('AUDIT_LOG:read');
    
    permissions.add('BACKUP:read');
    permissions.add('BACKUP:create');
    permissions.add('INVOICE_EXPLORER:read');
    permissions.add('PETTY_CASH_MANAGEMENT:read_own_unit');
    permissions.add('PETTY_CASH_MANAGEMENT:read_all');
    permissions.add('PETTY_CASH_MANAGEMENT:update');
    return Array.from(permissions);
};

const migratePermissions = async () => {
    const client = await pool.connect();
    try {
        console.log('[MIGRATION] Ensuring System Admin role has all permissions...');
        
        const allPermissions = generateAllPermissions();
        const allPermissionsJson = JSON.stringify(allPermissions);
        const adminRoleName = 'مدیر سیستم';
        
        const { rowCount } = await client.query(
            `UPDATE "roles" SET permissions = $1 WHERE name = $2`,
            [allPermissionsJson, adminRoleName]
        );

        if (rowCount > 0) {
            console.log(`[MIGRATION] Successfully updated permissions for '${adminRoleName}'.`);
        } else {
            console.log(`[MIGRATION_WARNING] '${adminRoleName}' role not found. Could not grant full permissions.`);
        }
        
    } catch (err) {
        console.error('[MIGRATION_ERROR] Could not update admin permissions:', err);
    } finally {
        client.release();
    }
};

migratePermissions().then(() => {
    app.listen(PORT, '0.0.0.0', () => {
        console.log(`\n\x1b[32m[SERVER_INFO] Backend server is running on http://localhost:${PORT}\x1b[0m`);
    });
});