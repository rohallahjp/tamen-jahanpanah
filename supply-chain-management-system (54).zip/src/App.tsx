import React, { useState, createContext, useContext, useMemo, lazy, Suspense } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';

import Header from './components/Header.tsx';
import Sidebar from './components/Sidebar.tsx';
import PageLoader from './components/PageLoader.tsx';
import ProtectedRoute from './components/ProtectedRoute.tsx';
import { useAuth } from './hooks/useAuth.ts';
import { unitsApi, rolesApi } from './services/api.ts';
import { Unit, Role } from './types.ts';

// Lazy load page components for code splitting
const WelcomePage = lazy(() => import('./components/WelcomePage.tsx'));
const DashboardPage = lazy(() => import('./features/Dashboard/DashboardPage.tsx'));
const ReportsPage = lazy(() => import('./features/Reports/ReportsPage.tsx'));
const UnitsPage = lazy(() => import('./features/Units/UnitsPage.tsx'));
const PersonsPage = lazy(() => import('./features/Persons/PersonsPage.tsx'));
const ProjectsPage = lazy(() => import('./features/Projects/ProjectsPage.tsx'));
// PositionsPage is no longer needed
// const PositionsPage = lazy(() => import('./features/Positions/PositionsPage.tsx'));
const RequestTypesPage = lazy(() => import('./features/RequestTypes/RequestTypesPage.tsx'));
const ChangePasswordPage = lazy(() => import('./features/Profile/ChangePasswordPage.tsx'));
const WorkflowPage = lazy(() => import('./features/Workflow/WorkflowPage.tsx'));
const InternalWorkflowPage = lazy(() => import('./features/InternalWorkflow/InternalWorkflowPage.tsx'));
const DebitPage = lazy(() => import('./features/Debit/DebitPage.tsx'));
const RolesPage = lazy(() => import('./features/Roles/RolesPage.tsx'));
const SecurityPage = lazy(() => import('./features/Security/SecurityPage.tsx'));
const AppearancePage = lazy(() => import('./features/Appearance/AppearancePage.tsx'));
const PettyCashPage = lazy(() => import('./features/PettyCash/PettyCashPage.tsx'));
const PettyCashManagementPage = lazy(() => import('./features/PettyCash/PettyCashManagementPage.tsx'));
const ContractsPage = lazy(() => import('./features/Contracts/ContractsPage.tsx'));
const LoginPage = lazy(() => import('./pages/LoginPage.tsx'));


export interface MainLayoutContextType {
  units: Unit[];
  roles: Role[];
  isLoading: boolean;
}

const MainLayoutContext = createContext<MainLayoutContextType | null>(null);

export const useMainLayoutContext = () => {
  const context = useContext(MainLayoutContext);
  if (!context) {
    throw new Error('useMainLayoutContext must be used inside a MainLayout component.');
  }
  return context;
};

const MainLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();
  const [isSidebarVisible, setIsSidebarVisible] = useState(true);

  // Fetch only small, globally used lookup data.
  // Large datasets are now fetched by their respective pages.
  const { data: units, isLoading: unitsLoading } = useQuery<Unit[]>({
    queryKey: ['units_all'],
    queryFn: () => unitsApi.getAllUnpaginated(),
  });
  const { data: roles, isLoading: rolesLoading } = useQuery<Role[]>({
    queryKey: ['roles_all'],
    queryFn: () => rolesApi.getAllUnpaginated(),
  });

  const isLoading = unitsLoading || rolesLoading;
  
  // Memoize the context value to prevent unnecessary re-renders of consuming components.
  const contextValue = useMemo<MainLayoutContextType>(() => ({
    units: units || [],
    roles: roles || [],
    isLoading,
  }), [units, roles, isLoading]);

  return (
    <MainLayoutContext.Provider value={contextValue}>
      <div className="flex h-screen overflow-hidden bg-gray-100 border-t-4 border-fuchsia-700">
        <Sidebar
          isSidebarVisible={isSidebarVisible}
          onHide={() => setIsSidebarVisible(false)}
        />
        <div
          className="flex-1 flex flex-col overflow-hidden transition-margin duration-300 ease-in-out"
          style={{ marginRight: isSidebarVisible ? '256px' : '0' }}
        >
          <Header
            onShowSidebar={() => setIsSidebarVisible(!isSidebarVisible)}
            userFullName={currentUser?.fullName}
            userPosition={currentUser?.position}
          />
          <main className="flex-grow p-4 sm:p-6 lg:p-8 overflow-y-auto">
            <Suspense fallback={<PageLoader />}>
                {children}
            </Suspense>
          </main>
        </div>
      </div>
    </MainLayoutContext.Provider>
  );
};

const App: React.FC = () => {
  const { isAuthenticated } = useAuth();

  return (
    <Suspense fallback={<PageLoader />}>
      <Routes>
        <Route path="/login" element={isAuthenticated ? <Navigate to="/dashboard" /> : <LoginPage />} />
        <Route path="/*" element={
          <ProtectedRoute>
            <MainLayout>
              <Routes>
                  <Route path="/" element={<Navigate to="/dashboard" />} />
                  <Route path="/welcome" element={<WelcomePage />} />
                  <Route path="/dashboard" element={<DashboardPage />} />
                  <Route path="/reports" element={<ReportsPage />} />
                  <Route path="/my-petty-cash" element={<PettyCashPage />} />
                  <Route path="/contracts" element={<ContractsPage />} />
                  <Route path="/units" element={<UnitsPage />} />
                  <Route path="/persons/:personType?" element={<PersonsPage />} />
                  <Route path="/projects" element={<ProjectsPage />} />
                  {/* Positions route is removed */}
                  {/* <Route path="/positions" element={<PositionsPage />} /> */}
                  <Route path="/request-types" element={<RequestTypesPage />} />
                  <Route path="/profile" element={<ChangePasswordPage />} />
                  <Route path="/workflow" element={<WorkflowPage />} />
                  <Route
                    path="/internal-workflows"
                    element={<InternalWorkflowPage />}
                  />
                  <Route path="/debit" element={<DebitPage />} />
                  <Route path="/roles" element={<RolesPage />} />
                  <Route path="/security" element={<SecurityPage />} />
                  <Route path="/appearance" element={<AppearancePage />} />
                  <Route path="/petty-cash-management" element={<PettyCashManagementPage />} />
                  <Route path="*" element={<Navigate to="/dashboard" />} />
                </Routes>
            </MainLayout>
          </ProtectedRoute>
        } />
      </Routes>
    </Suspense>
  );
};

export default App;