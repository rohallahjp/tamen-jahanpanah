
import React from 'react';

type ItemWithId = {
    id: number | string;
    [key: string]: any;
};

export type ColumnDef<T extends ItemWithId> = {
    accessorKey: keyof T | 'actions';
    header: string;
    width?: string;
    cell?: (item: T) => React.ReactNode;
};

type DataTableProps<T extends ItemWithId> = {
    columns: ColumnDef<T>[];
    data: T[];
    pagination: {
        page: number;
        total: number;
        itemsPerPage: number;
    };
    onPageChange: (newPage: number) => void;
};

const DataTableComponent = <T extends ItemWithId>({ columns, data, pagination, onPageChange }: DataTableProps<T>) => {
    const totalPages = Math.ceil(pagination.total / pagination.itemsPerPage);

    return (
        <div className="rounded-lg border border-gray-200 bg-white shadow-sm overflow-hidden flex flex-col">
            <div className="overflow-y-auto overflow-x-auto max-h-[65vh] relative flex-grow">
                <table className="w-full text-sm">
                    <thead className="bg-gray-50 text-gray-600 sticky top-0 z-10">
                        <tr className="text-right">
                            {columns.map((col) => (
                                <th key={String(col.accessorKey)} className="p-3 font-semibold" style={{ width: col.width }}>
                                    {col.header}
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {data.length === 0 ? (
                            <tr>
                                <td colSpan={columns.length} className="text-center p-8 text-gray-500">
                                    داده‌ای برای نمایش وجود ندارد.
                                </td>
                            </tr>
                        ) : (
                            data.map((item) => (
                                <tr key={item.id} className="hover:bg-gray-50 transition-colors">
                                    {columns.map((col) => (
                                        <td key={String(col.accessorKey)} className="p-3 align-top">
                                            {col.cell ? col.cell(item) : (item[col.accessorKey] ?? '---')}
                                        </td>
                                    ))}
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
             {totalPages > 1 && (
                <div className="flex justify-between items-center p-3 border-t border-gray-200 text-sm flex-shrink-0">
                    <span className="text-gray-600">
                        مجموع: <span className="font-semibold">{pagination.total.toLocaleString('fa-IR')}</span> مورد
                    </span>
                    <div className="flex items-center gap-2">
                        <button
                            onClick={() => onPageChange(pagination.page - 1)}
                            disabled={pagination.page === 1}
                            className="px-3 py-1 border rounded-md bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            قبلی
                        </button>
                        <span className="text-gray-700 font-mono">
                           {pagination.page.toLocaleString('fa-IR')} / {totalPages.toLocaleString('fa-IR')}
                        </span>
                        <button
                            onClick={() => onPageChange(pagination.page + 1)}
                            disabled={pagination.page >= totalPages}
                            className="px-3 py-1 border rounded-md bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            بعدی
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

export const DataTable = React.memo(DataTableComponent) as typeof DataTableComponent;
