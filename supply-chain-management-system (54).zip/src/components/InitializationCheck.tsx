
import React, { useState, useEffect } from 'react';

const API_BASE_URL = `http://${window.location.hostname}:4000`;

const InitializationCheck: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [isInitialized, setIsInitialized] = useState<boolean | null>(null);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const checkDbStatus = async () => {
            try {
                const response = await fetch(`${API_BASE_URL}/api/init-check`);
                if (!response.ok) {
                     const errBody = await response.json().catch(() => ({ message: `سرور با وضعیت ${response.status} پاسخ داد` }));
                    throw new Error(errBody.message);
                }
                const data = await response.json();
                setIsInitialized(data.initialized);
            } catch (err) {
                console.error("Failed to check DB initialization status:", err);
                setError("ارتباط با سرور پشتیبان برقرار نشد. لطفا مطمئن شوید سرور در حال اجراست.");
            }
        };

        checkDbStatus();
    }, []);

    if (isInitialized === null && !error) {
        // Loading state
        return (
            <div className="flex flex-col justify-center items-center h-screen bg-gray-100 text-center">
                <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div>
                <p className="mt-4 text-gray-700 font-semibold">در حال بررسی وضعیت پایگاه داده...</p>
            </div>
        );
    }

    if (error) {
        return (
            <div className="flex flex-col justify-center items-center h-screen bg-red-50 text-red-800 p-8 text-center" dir="rtl">
                <h1 className="text-2xl font-bold mb-4">خطا در اتصال به سرور</h1>
                <p>{error}</p>
                <p className="mt-4 text-sm">لطفا از کنسول (ترمینال) خود وضعیت اجرای سرور پشتیبان را بررسی کنید.</p>
            </div>
        );
    }

    if (isInitialized === false) {
        return (
            <div className="flex flex-col justify-center items-center h-screen bg-yellow-50 text-yellow-800 p-8 text-center" dir="rtl">
                <h1 className="text-2xl font-bold mb-4">پایگاه داده راه‌اندازی نشده است</h1>
                <p className="max-w-md">
                    به نظر می‌رسد جداول مورد نیاز در پایگاه داده شما ایجاد نشده‌اند. برای راه‌اندازی اولیه و ساخت جداول، لطفا دستور زیر را در ترمینال پروژه اجرا کرده و سپس صفحه را مجددا بارگذاری نمایید.
                </p>
                <pre className="bg-gray-800 text-white p-4 rounded-md mt-6 font-mono text-lg select-all" dir="ltr">
                    npm run init-db
                </pre>
            </div>
        );
    }

    return <>{children}</>;
};

export default InitializationCheck;
