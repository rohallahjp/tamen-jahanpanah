
import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth.ts';
import { Link, useNavigate } from 'react-router-dom';

interface HeaderProps {
  onShowSidebar: () => void;
  userFullName?: string;
  userPosition?: string;
}

const Header: React.FC<HeaderProps> = ({ onShowSidebar, userFullName, userPosition }) => {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [menuRef]);

  return (
    <header className="bg-white shadow-sm p-4 flex justify-between items-center sticky top-0 z-40 no-print">
      <div className="flex items-center gap-4">
        <button onClick={onShowSidebar} className="text-gray-600 hover:text-blue-600">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
        <h1 className="text-xl font-bold text-gray-800 hidden sm:block">سامانه مدیریت زنجیره تامین</h1>
      </div>
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-3 relative" ref={menuRef}>
            <div className="text-left">
              <p className="font-semibold text-gray-800">{userFullName || 'کاربر مهمان'}</p>
              <p className="text-xs text-gray-500">{userPosition || 'بدون سمت'}</p>
            </div>
            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="cursor-pointer">
                <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-500 ring-1 ring-gray-300">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                </div>
            </button>
            {isMenuOpen && (
                <div className="absolute top-full left-0 mt-2 w-48 bg-white rounded-md shadow-lg border z-50">
                    <Link to="/profile" onClick={() => setIsMenuOpen(false)} className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                        پروفایل من
                    </Link>
                    <button onClick={handleLogout} className="w-full text-right block px-4 py-2 text-sm text-red-600 hover:bg-gray-100">
                        خروج
                    </button>
                </div>
            )}
        </div>
      </div>
    </header>
  );
};

export default Header;
