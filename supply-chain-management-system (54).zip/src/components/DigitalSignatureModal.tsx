
import React, { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import Modal from './Modal';
import { personsApi } from '../services/api';
import { useAuth } from '../hooks/useAuth';

interface DigitalSignatureModalProps {
  onConfirm: () => void;
  onClose: () => void;
  actionText: string;
}

const DigitalSignatureModal: React.FC<DigitalSignatureModalProps> = ({ onConfirm, onClose, actionText }) => {
  const { currentUser } = useAuth();
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const verifyMutation = useMutation({
    mutationFn: (passwordToVerify: string) => {
      if (!currentUser) throw new Error("کاربر شناسایی نشد.");
      return personsApi.verifyPassword(currentUser.id, passwordToVerify);
    },
    onSuccess: (data: { success: boolean }) => {
      if (data.success) {
        onConfirm();
      } else {
        setError("رمز عبور وارد شده صحیح نمی‌باشد.");
      }
    },
    onError: (err: Error) => {
      setError(`خطا در تایید هویت: ${err.message}`);
    }
  });

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (!password) {
      setError("لطفا رمز عبور خود را وارد کنید.");
      return;
    }
    setError('');
    verifyMutation.mutate(password);
  };

  return (
    <Modal title="امضای دیجیتال (تایید هویت)" onClose={onClose} size="sm">
      <form onSubmit={handleVerify}>
        <div className="p-6 space-y-4">
          <p className="text-sm text-gray-700">
            برای انجام عملیات <span className="font-bold">{actionText}</span>، لطفا جهت تایید هویت، رمز عبور خود را مجددا وارد نمایید.
          </p>
          <div>
            <label htmlFor="signature-password" className="block text-sm font-medium text-gray-700 mb-1">رمز عبور</label>
            <input
              id="signature-password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full border p-2 rounded-md"
              autoFocus
            />
            {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
          </div>
        </div>
        <div className="flex justify-end gap-2 p-4 bg-gray-50 border-t">
            <button type="button" onClick={onClose} className="bg-gray-200 text-gray-800 px-4 py-2 rounded font-semibold">لغو</button>
            <button type="submit" disabled={verifyMutation.isPending} className="bg-green-600 text-white px-4 py-2 rounded disabled:bg-gray-400 font-semibold">
                {verifyMutation.isPending ? 'در حال بررسی...' : 'تایید'}
            </button>
        </div>
      </form>
    </Modal>
  );
};

export default DigitalSignatureModal;
