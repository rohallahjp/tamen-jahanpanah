
import React from 'react';
import { Link } from 'react-router-dom';

const WelcomePage: React.FC = () => {

  return (
    <div className="flex flex-col items-center justify-between h-full text-center bg-gray-50 p-8 rounded-lg shadow-sm">
      <div className="flex flex-col items-center justify-center flex-grow">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">
          به سامانه مدیریت زنجیره تامین خوش آمدید
        </h1>
        <p className="text-lg text-gray-600 mb-8 max-w-2xl">
          این سامانه برای بهینه‌سازی و شفاف‌سازی فرآیندهای درخواست، تایید و پرداخت در سازمان طراحی شده است.
        </p>
        <Link 
          to="/dashboard" 
          className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold text-lg hover:bg-blue-700 shadow-lg transition-transform transform hover:scale-105"
        >
          ورود به داشبورد
        </Link>
      </div>
      <footer className="w-full max-w-2xl pt-6 mt-8 border-t border-gray-200">
        <p className="text-sm font-medium text-gray-600">
          طراح و برنامه نویس: جهان پناه
        </p>
        <p className="text-xs text-gray-500 mt-1">
          نسخه اول - تهیه شده در شهریور ۱۴۰۴
        </p>
      </footer>
    </div>
  );
};

export default WelcomePage;
