
import React, { useState, useEffect } from 'react';
import { useForm, SubmitHandler } from 'react-hook-form';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { authApi, appearanceApi } from '../services/api';
import { useMutation, useQuery } from '@tanstack/react-query';
import { AppearanceSettings, Person, AppearanceImage } from '../types';

type LoginFormValues = {
  username: string;
  password: string;
};

const LoginPage: React.FC = () => {
  const { register, handleSubmit, setError, formState: { errors } } = useForm<LoginFormValues>();
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = (location.state as any)?.from?.pathname || '/dashboard';
  
  const [backgroundStyle, setBackgroundStyle] = useState({});

  const { data: settings } = useQuery<AppearanceSettings>({
      queryKey: ['appearanceSettings'],
      queryFn: appearanceApi.get,
  });

  useEffect(() => {
    if (!settings) return;

    // FIX: Add a default for images to prevent crashes if the API response is incomplete.
    const images = settings.images || [];

    const defaultStyle = {
      backgroundImage: `
        url('data:image/svg+xml,<svg width="80" height="80" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><g fill="none" stroke="%23FFFFFF" stroke-opacity="0.08" stroke-width="2"><circle cx="50" cy="50" r="10"/><ellipse cx="50" cy="50" rx="40" ry="15" transform="rotate(45 50 50)"/><ellipse cx="50" cy="50" rx="40" ry="15" transform="rotate(-45 50 50)"/><ellipse cx="50" cy="50" rx="40" ry="15" transform="rotate(90 50 50)"/></g></svg>'),
        linear-gradient(to top, #1e3c72 0%, #2a5298 100%)
      `
    };

    if (settings.mode === 'static' && settings.staticImageId) {
      const image = images.find((img: AppearanceImage) => img.id === settings.staticImageId);
      if (image) {
        setBackgroundStyle({ backgroundImage: `url(${image.url})` });
      } else {
        setBackgroundStyle(defaultStyle);
      }
    } else if (settings.mode === 'slideshow' && images.length > 0) {
      let currentIndex = 0;
      const updateBackground = () => {
        setBackgroundStyle({ 
          backgroundImage: `url(${images[currentIndex].url})`,
          transition: 'background-image 1s ease-in-out'
        });
        currentIndex = (currentIndex + 1) % images.length;
      };
      updateBackground();
      const intervalId = setInterval(updateBackground, 5000);
      return () => clearInterval(intervalId);
    } else {
      setBackgroundStyle(defaultStyle);
    }

  }, [settings]);

  const mutation = useMutation({
    mutationFn: (data: LoginFormValues) => authApi.login(data.username, data.password),
    onSuccess: (userWithPermissions: Person) => {
        login(userWithPermissions);
        navigate(from, { replace: true });
    },
    onError: (error: Error) => {
        setError("root.serverError", {
            type: "manual",
            message: error.message || 'نام کاربری یا رمز عبور اشتباه است.'
        });
    }
  });

  const onSubmit: SubmitHandler<LoginFormValues> = (data) => mutation.mutate(data);

  return (
    <div
      className="relative flex items-center justify-center min-h-screen p-4 overflow-hidden bg-cover bg-center transition-all duration-1000"
      style={backgroundStyle}
    >
      <div className="absolute inset-0 bg-black/30" />
      <div className="relative z-10 w-full max-w-md p-8 space-y-8 bg-white/20 backdrop-blur-lg rounded-xl shadow-2xl ring-1 ring-black/5">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-white">
            ورود به سامانه
          </h2>
          <p className="mt-2 text-sm text-gray-200">
            سامانه مدیریت زنجیره تامین
          </p>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleSubmit(onSubmit)}>
           {errors.root?.serverError && <p className="text-sm text-red-300 bg-red-900/50 p-3 rounded-md text-center">{errors.root.serverError.message}</p>}
          <div className="rounded-md shadow-sm -space-y-px">
            <div>
              <label htmlFor="username" className="sr-only">نام کاربری</label>
              <input
                id="username"
                type="text"
                autoComplete="off"
                {...register('username', { required: 'نام کاربری الزامی است' })}
                className="relative block w-full px-3 py-2 text-gray-900 placeholder-gray-500 bg-white/80 border border-gray-300 rounded-none appearance-none rounded-t-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 focus:z-10 sm:text-sm"
                placeholder="نام کاربری"
              />
              {errors.username && <p className="text-xs text-red-300 mt-1 px-1">{errors.username.message}</p>}
            </div>
            <div>
              <label htmlFor="password-input" className="sr-only">رمز عبور</label>
              <input
                id="password-input"
                type="password"
                autoComplete="off"
                 {...register('password', { required: 'رمز عبور الزامی است' })}
                className="relative block w-full px-3 py-2 text-gray-900 placeholder-gray-500 bg-white/80 border border-gray-300 rounded-none appearance-none rounded-b-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 focus:z-10 sm:text-sm"
                placeholder="رمز عبور"
              />
               {errors.password && <p className="text-xs text-red-300 mt-1 px-1">{errors.password.message}</p>}
            </div>
          </div>
          <div>
            <button
              type="submit"
              disabled={mutation.isPending}
              className="relative flex justify-center w-full px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md group hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-blue-400 disabled:cursor-not-allowed"
            >
              {mutation.isPending ? 'در حال ورود...' : 'ورود'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LoginPage;
