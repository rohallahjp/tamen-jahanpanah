import React, { useState, useEffect } from 'react';
import { useForm, useFieldArray, SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { Workflow, WorkflowSchema, WorkflowData, PaginatedResponse, Person, Role, Unit, RequestCategory } from '../../types';
import { workflowsApi, personsApi, rolesApi, unitsApi, requestCategoriesApi } from '../../services/api';
import Modal from '../../components/Modal';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import WorkflowCard from './WorkflowCard';
import { useToast } from '../../hooks/useToast';

type WorkflowFormData = z.infer<typeof WorkflowSchema>;

const WorkflowPage: React.FC = () => {
  const { read: canRead, create: canCreate } = usePermissions('WORKFLOW');
  const queryClient = useQueryClient();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedWorkflow, setSelectedWorkflow] = useState<Workflow | null>(null);
  const toast = useToast();
  const [page] = useState(1);

  const { data: workflowsResponse, isLoading: isWorkflowsLoading } = useQuery<PaginatedResponse<Workflow>>({
      queryKey: ['workflows', page],
      queryFn: () => workflowsApi.getAll(page),
  });

  // FIX: Wrapped queryFn calls in arrow functions to resolve overload errors.
  const { data: persons, isLoading: isPersonsLoading } = useQuery<Person[]>({ queryKey: ['persons_all'], queryFn: () => personsApi.getAllUnpaginated() });
  const { data: roles, isLoading: isRolesLoading } = useQuery<Role[]>({ queryKey: ['roles_all'], queryFn: () => rolesApi.getAllUnpaginated() });
  const { data: units, isLoading: isUnitsLoading } = useQuery<Unit[]>({ queryKey: ['units_all'], queryFn: () => unitsApi.getAllUnpaginated() });
  const { data: requestCategories, isLoading: isCategoriesLoading } = useQuery<RequestCategory[]>({ queryKey: ['requestCategories_all'], queryFn: () => requestCategoriesApi.getAllUnpaginated() });
  
  const { register, control, handleSubmit, reset, watch, setValue, formState: { errors } } = useForm<WorkflowFormData>({ resolver: zodResolver(WorkflowSchema), defaultValues: { name: '', requestCategoryId: '', steps: [{ name: '', assigneeRule: { type: 'UNIT_MANAGER' } }] } });
  const { fields, append, remove } = useFieldArray({ control, name: "steps" });
  const watchedSteps = watch("steps");

  useEffect(() => {
    if (isModalOpen) {
        if (selectedWorkflow) {
            reset({ name: selectedWorkflow.name, requestCategoryId: String(selectedWorkflow.requestCategoryId), steps: selectedWorkflow.steps.map(s => ({ name: s.name, assigneeRule: { type: s.assigneeRule.type, userId: s.assigneeRule.userId?.toString(), roleId: s.assigneeRule.roleId?.toString(), unitId: s.assigneeRule.unitId?.toString() } })) });
        } else {
            reset({ name: '', requestCategoryId: '', steps: [{ name: '', assigneeRule: { type: 'UNIT_MANAGER' } }] });
        }
    }
  }, [selectedWorkflow, isModalOpen, reset]);

  const mutation = useMutation({
    mutationFn: (data: { formData: WorkflowFormData, id?: number }) => {
        const finalData: WorkflowData = { name: data.formData.name, requestCategoryId: Number(data.formData.requestCategoryId), steps: data.formData.steps.map((step, index) => ({ id: selectedWorkflow?.steps[index]?.id || Date.now() + index, name: step.name, assigneeRule: { type: step.assigneeRule.type, userId: step.assigneeRule.userId ? Number(step.assigneeRule.userId) : undefined, roleId: step.assigneeRule.roleId ? Number(step.assigneeRule.roleId) : undefined, unitId: step.assigneeRule.unitId ? Number(step.assigneeRule.unitId) : undefined } })) };
        return data.id ? workflowsApi.update(data.id, finalData) : workflowsApi.create(finalData);
    },
    onSuccess: () => { 
      queryClient.invalidateQueries({ queryKey: ['workflows'] }); 
      setIsModalOpen(false);
      toast.success('فرآیند با موفقیت ذخیره شد.');
    },
    onError: (err: Error) => toast.error(`خطا در ذخیره سازی: ${err.message}`)
  });

  const deleteMutation = useMutation({ 
    mutationFn: (id: number) => workflowsApi.delete(id), 
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workflows'] });
      toast.success('فرآیند با موفقیت حذف شد.');
    }, 
    onError: (err: Error) => toast.error(`خطا در حذف: ${err.message}`) 
  });

  const onSubmit: SubmitHandler<WorkflowFormData> = (data) => mutation.mutate({ formData: data, id: selectedWorkflow?.id });
  const handleDelete = (id: number) => { if (window.confirm('آیا از حذف این فرآیند مطمئن هستید؟')) deleteMutation.mutate(id); };
  const openModal = (wf: Workflow | null = null) => { setSelectedWorkflow(wf); setIsModalOpen(true); };

  if (!canRead) return <AccessDenied />;

  const isLoading = isWorkflowsLoading || isPersonsLoading || isRolesLoading || isUnitsLoading || isCategoriesLoading;

  return (
    <section className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800">مدیریت خطوط فرآیند</h2>
        <button onClick={() => openModal()} disabled={!canCreate} className="bg-blue-600 text-white px-5 py-2 rounded-lg font-semibold flex items-center gap-2 disabled:bg-gray-400">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110 2h3V6a1 1 0 011-1z" /></svg>
          افزودن فرآیند جدید
        </button>
      </div>
      
      {isLoading ? (
        <p>در حال بارگذاری...</p>
      ) : workflowsResponse?.data && workflowsResponse.data.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {workflowsResponse.data.map(wf => (
            <WorkflowCard 
              key={wf.id} 
              workflow={wf}
              persons={persons || []}
              roles={roles || []}
              units={units || []}
              requestCategories={requestCategories || []}
              onEdit={openModal} 
              onDelete={handleDelete}
            />
          ))}
        </div>
      ) : (
        <div className="text-center p-12 bg-gray-50 rounded-lg border">
          <p className="text-gray-600">هیچ فرآیندی تعریف نشده است.</p>
        </div>
      )}

      {isModalOpen && (
        <Modal title={selectedWorkflow ? "ویرایش فرآیند" : "ایجاد فرآیند جدید"} onClose={() => setIsModalOpen(false)} size="3xl">
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 max-h-[70vh] overflow-y-auto p-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div><label className="block text-sm font-medium text-gray-700 mb-1">نام فرآیند</label><input {...register("name")} className="w-full border p-2 rounded" />{errors.name && <p className="text-red-500 text-xs mt-1">{errors.name.message as string}</p>}</div>
              <div><label className="block text-sm font-medium text-gray-700 mb-1">برای نوع درخواست</label><select {...register("requestCategoryId")} className="w-full border p-2 rounded bg-white"><option value="">...</option>{(requestCategories || []).map(rc => <option key={rc.id} value={rc.id}>{rc.label}</option>)}</select>{errors.requestCategoryId && <p className="text-red-500 text-xs mt-1">{errors.requestCategoryId.message as string}</p>}</div>
            </div>
            <div className="pt-4 border-t"><h3 className="font-semibold mb-2">گام‌های فرآیند (به ترتیب اجرا)</h3><div className="space-y-3">
                {fields.map((field, index) => {
                    const assigneeTypeRegister = register(`steps.${index}.assigneeRule.type`);
                    const stepErrors = errors.steps?.[index];
                    return (
                      <div key={field.id} className="p-3 border rounded bg-gray-50/50 space-y-2">
                        <div className="flex justify-between items-center"><h4 className="font-semibold text-gray-600">گام {index + 1}</h4>{fields.length > 1 && <button type="button" onClick={() => remove(index)} className="text-red-500 font-bold text-lg leading-none hover:text-red-700">&times;</button>}</div>
                        <div>
                            <input {...register(`steps.${index}.name`)} placeholder="نام گام" className="border p-1.5 rounded w-full mb-1" />
                            {stepErrors?.name && <p className="text-red-500 text-xs">{stepErrors.name.message as string}</p>}
                        </div>
                        <div className="grid grid-cols-[auto_1fr] gap-x-2 gap-y-2 items-start">
                            <label className="text-xs font-semibold pt-2">مسئول:</label>
                            <select
                                {...assigneeTypeRegister}
                                onChange={(e) => {
                                    assigneeTypeRegister.onChange(e); 
                                    setValue(`steps.${index}.assigneeRule.userId`, "");
                                    setValue(`steps.${index}.assigneeRule.roleId`, "");
                                    setValue(`steps.${index}.assigneeRule.unitId`, "");
                                }}
                                className="border p-1.5 rounded bg-white text-sm"
                            >
                                <option value="USER">کاربر خاص</option>
                                <option value="UNIT_MANAGER">مدیر واحد</option>
                                <option value="ROLE">نقش خاص</option>
                                <option value="UNIT_AND_ROLE">نقش در واحد خاص</option>
                            </select>
                             <div/>
                             <div className="space-y-1">
                                {watchedSteps[index]?.assigneeRule.type === 'USER' && (
                                    <>
                                        <select {...register(`steps.${index}.assigneeRule.userId`)} className="border p-1.5 rounded bg-white text-sm w-full"><option value="">...</option>{(persons || []).filter(p => p.isSystemUser).map(p => <option key={p.id} value={p.id}>{p.fullName}</option>)}</select>
                                        {stepErrors?.assigneeRule?.userId && <p className="text-red-500 text-xs">{stepErrors.assigneeRule.userId.message as string}</p>}
                                    </>
                                )}
                                {watchedSteps[index]?.assigneeRule.type === 'ROLE' && (
                                    <>
                                        <select {...register(`steps.${index}.assigneeRule.roleId`)} className="border p-1.5 rounded bg-white text-sm w-full"><option value="">...</option>{(roles || []).map(r => <option key={r.id} value={r.id}>{r.name}</option>)}</select>
                                        {stepErrors?.assigneeRule?.roleId && <p className="text-red-500 text-xs">{stepErrors.assigneeRule.roleId.message as string}</p>}
                                    </>
                                )}
                                {watchedSteps[index]?.assigneeRule.type === 'UNIT_AND_ROLE' && (
                                    <>
                                    <div className="flex gap-2">
                                        <select {...register(`steps.${index}.assigneeRule.unitId`)} className="border p-1.5 rounded bg-white text-sm w-1/2"><option value="">انتخاب واحد...</option>{(units || []).map(u => <option key={u.id} value={u.id}>{u.name}</option>)}</select>
                                        <select {...register(`steps.${index}.assigneeRule.roleId`)} className="border p-1.5 rounded bg-white text-sm w-1/2"><option value="">انتخاب نقش...</option>{(roles || []).map(r => <option key={r.id} value={r.id}>{r.name}</option>)}</select>
                                    </div>
                                    {stepErrors?.assigneeRule?.unitId && <p className="text-red-500 text-xs">{stepErrors.assigneeRule.unitId.message as string}</p>}
                                    {stepErrors?.assigneeRule?.roleId && !stepErrors?.assigneeRule?.unitId && <p className="text-red-500 text-xs">{stepErrors.assigneeRule.roleId.message as string}</p>}
                                    </>
                                )}
                                {watchedSteps[index]?.assigneeRule.type === 'UNIT_MANAGER' && <div className="text-xs text-gray-500 p-1.5">از واحد درخواست‌کننده</div>}
                             </div>
                        </div>
                      </div>
                    );
                })}
            </div><button type="button" onClick={() => append({ name: '', assigneeRule: { type: 'UNIT_MANAGER' } })} className="text-sm text-blue-600 mt-2 font-semibold hover:underline">+ افزودن گام</button>{errors.steps && <p className="text-red-500 text-xs mt-1">{(errors.steps.message || (errors.steps as any).root?.message) as string}</p>}</div>
            <div className="flex justify-end gap-2 pt-4 border-t mt-2"><button type="button" onClick={() => setIsModalOpen(false)} className="bg-gray-200 px-4 py-2 rounded font-semibold">لغو</button><button type="submit" disabled={mutation.isPending} className="bg-green-500 text-white px-4 py-2 rounded disabled:bg-gray-400 font-semibold">{mutation.isPending ? '...' : 'ذخیره'}</button></div>
          </form>
        </Modal>
      )}
    </section>
  );
};

export default WorkflowPage;