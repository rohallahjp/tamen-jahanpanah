import React, { useState, useCallback } from 'react';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { Unit, Person, UnitData, PaginatedResponse } from '../../types';
import { unitsApi, personsApi } from '../../services/api';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import UnitFormModal from './UnitFormModal';
import OrgChart from './OrgChart.tsx';
import Modal from '../../components/Modal';
import { useToast } from '../../hooks/useToast';
import { useDebounce } from '../../hooks/useDebounce';

export type UnitNode = Unit & {
    children: UnitNode[];
    persons: Person[];
};

const AssignPersonModal: React.FC<{
    unit: UnitNode;
    onClose: () => void;
}> = ({ unit, onClose }) => {
    const queryClient = useQueryClient();
    const toast = useToast();
    const [searchQuery, setSearchQuery] = useState('');
    const debouncedSearch = useDebounce(searchQuery, 300);

    const { data: personsResponse, isLoading } = useQuery<PaginatedResponse<Person>>({
        queryKey: ['persons_unassigned_search', debouncedSearch],
        queryFn: () => personsApi.getAll(1, debouncedSearch, { hasUnit: false }),
        enabled: !!debouncedSearch,
    });
    
    const assignMutation = useMutation({
        mutationFn: (personId: number) => unitsApi.assignPerson(unit.id, personId),
        onSuccess: () => {
            toast.success('شخص با موفقیت به این سمت منصوب شد.');
            queryClient.invalidateQueries({ queryKey: ['units_tree'] });
            queryClient.invalidateQueries({ queryKey: ['persons'] });
            onClose();
        },
        onError: (error: Error) => toast.error(`خطا: ${error.message}`),
    });

    return (
        <Modal title={`انتصاب شخص به ${unit.name}`} onClose={onClose}>
            <div className="p-4">
                 <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="جستجو بر اساس نام یا کد ملی شخص..."
                    className="w-full p-2 border rounded-md"
                    autoFocus
                />
                <div className="mt-4 max-h-80 overflow-y-auto">
                    {isLoading && <p>در حال جستجو...</p>}
                    {personsResponse && personsResponse.data.map(person => (
                        <div key={person.id} className="flex justify-between items-center p-2 hover:bg-gray-100 rounded">
                            <span>{person.fullName} - {person.nationalId}</span>
                            <button onClick={() => assignMutation.mutate(person.id)} className="bg-blue-500 text-white px-3 py-1 text-sm rounded hover:bg-blue-600">انتخاب</button>
                        </div>
                    ))}
                    {debouncedSearch && !isLoading && personsResponse?.data.length === 0 && <p className="text-center text-gray-500">شخصی یافت نشد یا قبلا منصوب شده است.</p>}
                </div>
            </div>
        </Modal>
    );
};


const UnitsPage: React.FC = () => {
    const { read: canReadUnits, create: canCreateUnit, delete: canDeleteUnit } = usePermissions('UNITS');
    const queryClient = useQueryClient();
    const toast = useToast();
    
    const [modalState, setModalState] = useState<{
        unitForm: { isOpen: boolean; unit: Unit | null; parentId: number | null };
        assignPerson: { isOpen: boolean; unit: UnitNode | null };
    }>({
        unitForm: { isOpen: false, unit: null, parentId: null },
        assignPerson: { isOpen: false, unit: null }
    });

    const { data: treeData, isLoading } = useQuery<UnitNode[]>({ 
        queryKey: ['units_tree'], 
        queryFn: unitsApi.getTree 
    });

    const unitMutation = useMutation({
        mutationFn: (data: { unitData: UnitData, id?: number }) => data.id ? unitsApi.update(data.id, data.unitData) : unitsApi.create(data.unitData),
        onSuccess: () => { 
            queryClient.invalidateQueries({ queryKey: ['units_tree'] }); 
            closeUnitForm();
            toast.success('واحد/سمت با موفقیت ذخیره شد.');
        },
        onError: (err: Error) => toast.error(`خطا در ذخیره: ${err.message}`),
    });

    const deleteUnitMutation = useMutation({
        mutationFn: (id: number) => unitsApi.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['units_tree'] });
            toast.success('واحد/سمت با موفقیت حذف شد.');
        },
        onError: (err: Error) => toast.error(`خطا در حذف: ${err.message}`),
    });
    
    const unassignPersonMutation = useMutation({
        mutationFn: ({ unitId, personId }: { unitId: number, personId: number }) => unitsApi.unassignPerson(unitId, personId),
        onSuccess: () => {
             queryClient.invalidateQueries({ queryKey: ['units_tree'] });
             toast.success('شخص از این سمت برکنار شد.');
        },
        onError: (err: Error) => toast.error(`خطا: ${err.message}`),
    });

    const handleSaveUnit = (unitData: UnitData, id?: number) => {
        unitMutation.mutate({ unitData, id });
    };

    const handleDeleteUnit = useCallback((unitId: number) => {
        if (window.confirm('آیا از حذف این واحد/سمت و تمام زیرمجموعه‌های آن مطمئن هستید؟')) {
            deleteUnitMutation.mutate(unitId);
        }
    }, [deleteUnitMutation]);
    
    const handleUnassignPerson = useCallback((unitId: number, personId: number) => {
        if (window.confirm('آیا از حذف انتصاب این شخص مطمئن هستید؟')) {
            unassignPersonMutation.mutate({ unitId, personId });
        }
    }, [unassignPersonMutation]);

    const openUnitForm = useCallback((unit: Unit | null, parentId: number | null = null) => {
        setModalState(prev => ({ ...prev, unitForm: { isOpen: true, unit, parentId } }));
    }, []);
    
    const closeUnitForm = () => setModalState(prev => ({ ...prev, unitForm: { ...prev.unitForm, isOpen: false }}));

    const openAssignPersonModal = useCallback((unit: UnitNode) => {
         setModalState(prev => ({ ...prev, assignPerson: { isOpen: true, unit } }));
    }, []);
    
    const closeAssignPersonModal = () => setModalState(prev => ({ ...prev, assignPerson: { ...prev.assignPerson, isOpen: false }}));

    if (!canReadUnits) return <AccessDenied />;

    return (
        <section className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-800">نمودار ساختار سازمانی</h2>
                <button 
                    onClick={() => openUnitForm(null)} 
                    disabled={!canCreateUnit}
                    className="bg-blue-600 text-white px-5 py-2 rounded-lg font-semibold hover:bg-blue-700 shadow-md flex items-center gap-2 disabled:bg-gray-400"
                >
                    افزودن واحد ریشه
                </button>
            </div>
            <div className="bg-white rounded-lg shadow-sm border p-6 overflow-x-auto">
                {isLoading ? (
                     <div className="flex justify-center items-center h-64">
                        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
                    </div>
                ) : treeData && treeData.length > 0 ? (
                    <div className="flex justify-center">
                         <ul className="inline-block">
                            {treeData.map(node => (
                                <OrgChart 
                                    key={node.id} 
                                    node={node} 
                                    onOpenUnitModal={openUnitForm}
                                    onDeleteUnit={handleDeleteUnit}
                                    onAssignPerson={openAssignPersonModal}
                                    onUnassignPerson={handleUnassignPerson}
                                />
                            ))}
                        </ul>
                    </div>
                ) : (
                    <div className="text-center p-12 text-gray-500">
                        <p>هیچ واحدی تعریف نشده است.</p>
                        <p className="text-sm mt-2">برای شروع، یک واحد ریشه ایجاد کنید.</p>
                    </div>
                )}
            </div>

            {modalState.unitForm.isOpen && (
                <UnitFormModal
                    unit={modalState.unitForm.unit}
                    parentId={modalState.unitForm.parentId}
                    onClose={closeUnitForm}
                    onSave={handleSaveUnit}
                    isPending={unitMutation.isPending}
                />
            )}
            
            {modalState.assignPerson.isOpen && (
                <AssignPersonModal
                    unit={modalState.assignPerson.unit!}
                    onClose={closeAssignPersonModal}
                />
            )}
        </section>
    );
};

export default UnitsPage;