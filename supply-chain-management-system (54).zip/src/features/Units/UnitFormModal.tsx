import React, { useEffect } from 'react';
import { useForm, SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Unit, UnitData, UnitSchema } from '../../types';
import Modal from '../../components/Modal';

type UnitFormData = z.infer<typeof UnitSchema>;

interface UnitFormModalProps {
    unit: Unit | null;
    parentId: number | null;
    onClose: () => void;
    onSave: (data: UnitData, id?: number) => void;
    isPending: boolean;
}

const UnitFormModal: React.FC<UnitFormModalProps> = ({ unit, parentId, onClose, onSave, isPending }) => {
    const { register, handleSubmit, reset, formState: { errors } } = useForm<UnitFormData>({
        resolver: zodResolver(UnitSchema),
    });

    useEffect(() => {
        if (unit) {
            reset({ ...unit, parentId: unit.parentId?.toString() });
        } else {
            reset({ name: '', code: '', credit: 0, parentId: parentId?.toString() });
        }
    }, [unit, parentId, reset]);

    const onSubmit: SubmitHandler<UnitFormData> = (data) => {
        const finalData: UnitData = {
            ...data,
            code: data.code || '',
            parentId: data.parentId ? Number(data.parentId) : undefined,
        };
        onSave(finalData, unit?.id);
    };

    const getModalTitle = () => {
        if (unit) return `ویرایش: ${unit.name}`;
        if (parentId) return 'افزودن سمت / زیرمجموعه';
        return 'افزودن واحد ریشه';
    };

    return (
        <Modal title={getModalTitle()} onClose={onClose}>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 p-6">
                <input type="hidden" {...register('parentId')} />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                     <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1">نام واحد / سمت</label>
                        <input {...register("name")} className="w-full border p-2 rounded" />
                        {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name.message as string}</p>}
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">اعتبار (ریال)</label>
                        <input type="number" {...register("credit", { valueAsNumber: true })} className="w-full border p-2 rounded" />
                        {errors.credit && <p className="text-red-500 text-xs mt-1">{errors.credit.message as string}</p>}
                    </div>
                </div>
                <div className="flex justify-end gap-2 pt-4 border-t mt-2">
                    <button type="button" onClick={onClose} className="bg-gray-200 text-gray-800 px-4 py-2 rounded font-semibold">لغو</button>
                    <button type="submit" disabled={isPending} className="bg-green-500 text-white px-4 py-2 rounded disabled:bg-gray-400 font-semibold">
                        {isPending ? 'در حال ذخیره...' : 'ذخیره'}
                    </button>
                </div>
            </form>
        </Modal>
    );
};

export default UnitFormModal;