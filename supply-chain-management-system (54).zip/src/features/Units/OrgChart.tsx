import React from 'react';
import { UnitNode } from './UnitsPage';
import { Unit, Person } from '../../types';
import { usePermissions } from '../../hooks/usePermissions';

interface OrgChartProps {
    node: UnitNode;
    onOpenUnitModal: (unit: Unit | null, parentId: number | null) => void;
    onDeleteUnit: (unitId: number) => void;
    onAssignPerson: (unit: UnitNode) => void;
    onUnassignPerson: (unitId: number, personId: number) => void;
}

const UnitCardComponent: React.FC<OrgChartProps> = ({ node, onOpenUnitModal, onDeleteUnit, onAssignPerson, onUnassignPerson }) => {
    const { create: canCreateUnit, update: canUpdateUnit, delete: canDeleteUnit } = usePermissions('UNITS');
    const isPosition = !!node.parentId; // It's a position if it has a parent

    return (
        <div className="p-4 bg-white border-2 border-gray-200 rounded-lg shadow-md min-w-[280px] hover:border-blue-400 hover:shadow-lg transition-all">
            <div className="text-center">
                <h3 className="text-lg font-bold text-gray-800">{node.name}</h3>
                <p className="text-xs text-gray-500 font-mono bg-gray-100 inline-block px-2 py-0.5 rounded-full my-1">
                    {isPosition ? 'سمت' : 'واحد'}
                </p>
            </div>
            <div className="mt-3 pt-3 border-t flex justify-center items-center gap-2 text-xs">
                <button onClick={() => onOpenUnitModal(null, node.id)} disabled={!canCreateUnit} className="text-green-600 font-semibold hover:underline disabled:text-gray-400">افزودن {isPosition ? 'زیرمجموعه' : 'سمت'}</button>
                 <span className="text-gray-300">|</span>
                <button onClick={() => onOpenUnitModal(node, null)} disabled={!canUpdateUnit} className="text-blue-600 font-semibold hover:underline disabled:text-gray-400">ویرایش</button>
                <span className="text-gray-300">|</span>
                <button onClick={() => onDeleteUnit(node.id)} disabled={!canDeleteUnit} className="text-red-600 font-semibold hover:underline disabled:text-gray-400">حذف</button>
            </div>
            
            {isPosition && (
                 <div className="mt-3 pt-3 border-t">
                     <div className="flex justify-between items-center mb-2">
                        <h4 className="text-xs font-bold text-gray-500 text-center">اشخاص منتسب</h4>
                        <button onClick={() => onAssignPerson(node)} className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full hover:bg-blue-200">+ انتصاب</button>
                     </div>
                     <div className="space-y-1.5 max-h-24 overflow-y-auto pr-2">
                        {node.persons.length > 0 ? node.persons.map(person => (
                            <div key={person.id} className="text-xs flex justify-between items-center group">
                                <span>{person.fullName}</span>
                                <button onClick={() => onUnassignPerson(node.id, person.id)} className="text-red-500 opacity-0 group-hover:opacity-100 transition-opacity text-xs pr-2">حذف انتصاب</button>
                            </div>
                        )) : <p className="text-xs text-center text-gray-400 py-2">هیچ شخصی منتسب نشده</p>}
                     </div>
                 </div>
            )}
        </div>
    );
};

const UnitCard = React.memo(UnitCardComponent);


const OrgChartComponent: React.FC<OrgChartProps> = ({ node, ...props }) => {
    return (
        <li className="relative text-center px-4">
             <div className="inline-block relative before:absolute before:top-0 before:left-1/2 before:-translate-x-1/2 before:h-6 before:w-0.5 before:bg-gray-300 first:before:content-none">
                 <UnitCard node={node} {...props} />
             </div>
            {node.children && node.children.length > 0 && (
                <ul className="flex justify-center pt-6 relative before:absolute before:top-0 before:left-0 before:w-full before:h-0.5 before:bg-gray-300">
                    {node.children.map(childNode => (
                        <OrgChart key={childNode.id} node={childNode} {...props} />
                    ))}
                </ul>
            )}
        </li>
    );
};

const OrgChart = React.memo(OrgChartComponent);

export default OrgChart;