import React, { useState, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useForm, SubmitHandler } from 'react-hook-form';
import { useLocation, useNavigate } from 'react-router-dom';
import { PaginatedResponse, SupplyRequest, Person, RequestCategory, Workflow, InternalWorkflow } from '../../types';
import { DataTable, ColumnDef } from '../../components/DataTable';
import RequestDetailsModal from '../Dashboard/RequestDetailsModal';
import { formatCurrency } from '../../utils/formatters';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import { useMainLayoutContext } from '../../App';
import { reportsApi, personsApi, requestCategoriesApi, workflowsApi, internalWorkflowsApi } from '../../services/api';
import ReportSummary from './ReportSummary';
import { useAuth } from '../../hooks/useAuth.ts';

type SearchFormData = {
  status: string;
  requestTypeId: string;
  requesterId: string;
  requestingUnitId: string;
  dateFrom: string; 
  dateTo: string;
  amountFrom: number | '';
  amountTo: number | '';
  imprestHolderId: string;
  assigneeId?: string;
};

const ReportsPage: React.FC = () => {
    const { read: canRead } = usePermissions('REPORTS');
    const { currentUser } = useAuth();
    const queryClient = useQueryClient();
    const location = useLocation();
    const navigate = useNavigate();

    const {
        units,
        roles,
        isLoading: isContextLoading,
    } = useMainLayoutContext();

    const { data: persons, isLoading: isPersonsLoading } = useQuery<Person[]>({ queryKey: ['persons_all'], queryFn: () => personsApi.getAllUnpaginated() });
    const { data: categories, isLoading: isCategoriesLoading } = useQuery<RequestCategory[]>({ queryKey: ['requestCategories_all'], queryFn: () => requestCategoriesApi.getAllUnpaginated() });
    const { data: workflows, isLoading: isWorkflowsLoading } = useQuery<Workflow[]>({ queryKey: ['workflows_all'], queryFn: () => workflowsApi.getAllUnpaginated() });
    const { data: internalWorkflows, isLoading: isInternalWorkflowsLoading } = useQuery<InternalWorkflow[]>({ queryKey: ['internalWorkflows_all'], queryFn: () => internalWorkflowsApi.getAllUnpaginated() });

    const [searchFilters, setSearchFilters] = useState<Partial<SearchFormData> | null>(null);
    const [viewingRequest, setViewingRequest] = useState<SupplyRequest | null>(null);
    const [page, setPage] = useState(1);

    const { register, handleSubmit, reset } = useForm<SearchFormData>();

    useEffect(() => {
        const prefilledFilters = location.state?.filters as Partial<SearchFormData> | undefined;
        if (prefilledFilters) {
            // FIX: Explicitly type `defaultFilters` to guide TypeScript's type inference.
            // This prevents the `amountFrom` and `amountTo` properties from being incorrectly
            // inferred as a general `string`, which caused a type conflict with `number | ''`.
            const defaultFilters: Partial<SearchFormData> = {
                status: '', requestTypeId: '', requesterId: '', requestingUnitId: '',
                dateFrom: '', dateTo: '', amountFrom: '', amountTo: '', imprestHolderId: '',
                assigneeId: '',
            };
            const allFilters = {
                ...defaultFilters,
                ...prefilledFilters
            };
            setPage(1);
            setSearchFilters(allFilters);
            reset(allFilters);
            navigate(location.pathname, { replace: true, state: null });
        }
    }, [location, navigate, reset]);

    const { data: summaryData, isLoading: isSummaryLoading } = useQuery({
        queryKey: ['reportSummary', searchFilters, currentUser?.id],
        queryFn: () => reportsApi.getSummary({ ...searchFilters, userId: currentUser!.id }),
        enabled: !!searchFilters && !!currentUser,
    });

    const { data: searchResponse, isLoading: isSearchLoading } = useQuery<PaginatedResponse<SupplyRequest>>({
        queryKey: ['reportList', searchFilters, page, currentUser?.id],
        queryFn: () => reportsApi.search({ ...searchFilters, userId: currentUser!.id }, page),
        enabled: !!searchFilters && !!currentUser,
    });

    const onSubmit: SubmitHandler<SearchFormData> = (data) => {
        const cleanedData = Object.fromEntries(
            Object.entries(data).filter(([, value]) => value !== '' && value !== null && value !== undefined)
        ) as Partial<SearchFormData>;
        setPage(1);
        setSearchFilters(cleanedData);
    };

    const clearSearch = () => {
        const emptyFilters: SearchFormData = { status: '', requestTypeId: '', requesterId: '', requestingUnitId: '', dateFrom: '', dateTo: '', amountFrom: '', amountTo: '', imprestHolderId: '', assigneeId: '' };
        reset(emptyFilters);
        setSearchFilters(null);
        setPage(1);
    };
    
    const columns: ColumnDef<SupplyRequest>[] = [
        { accessorKey: 'id', header: 'شماره', width: '150px' },
        { accessorKey: 'requestCategoryLabel', header: 'عنوان' },
        { accessorKey: 'requesterName', header: 'درخواست‌کننده' },
        { accessorKey: 'amount', header: 'مبلغ', cell: (req) => formatCurrency(req.amount, req.currency) },
        { accessorKey: 'submissionDate', header: 'تاریخ', width: '120px' },
        { accessorKey: 'status', header: 'وضعیت', cell: (req) => req.status === 'APPROVED' ? 'تایید نهایی' : req.status === 'REJECTED' ? 'رد شده' : 'در حال بررسی' },
        { accessorKey: 'actions', header: 'عملیات', width: '120px', cell: (req) => <button onClick={() => setViewingRequest(req)} className="text-blue-600 hover:underline font-semibold">مشاهده جزئیات</button> }
    ];

    if (!canRead) return <AccessDenied />;
    
    const isLoading = isContextLoading || isPersonsLoading || isCategoriesLoading || isWorkflowsLoading || isInternalWorkflowsLoading;
    if (isLoading) return <div className="flex justify-center items-center h-full"><div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div></div>;
    
    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-800">گزارش‌ها و جستجوی پیشرفته</h2>
            
            <form onSubmit={handleSubmit(onSubmit)} className="p-4 bg-white rounded-lg border shadow-sm space-y-4">
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div><label className="text-sm block mb-1">وضعیت</label><select {...register('status')} className="w-full border p-2 rounded text-sm bg-white"><option value="">همه</option><option value="IN_REVIEW">در حال بررسی</option><option value="APPROVED">تایید نهایی</option><option value="REJECTED">رد شده</option></select></div>
                    <div><label className="text-sm block mb-1">نوع درخواست</label><select {...register('requestTypeId')} className="w-full border p-2 rounded text-sm bg-white"><option value="">همه</option>{(categories || []).map(c => <option key={c.id} value={c.id}>{c.label}</option>)}</select></div>
                    <div><label className="text-sm block mb-1">درخواست‌کننده</label><select {...register('requesterId')} className="w-full border p-2 rounded text-sm bg-white"><option value="">همه</option>{(persons || []).filter(p=>p.isSystemUser).map(p => <option key={p.id} value={p.id}>{p.fullName}</option>)}</select></div>
                    <div><label className="text-sm block mb-1">واحد درخواست‌کننده</label><select {...register('requestingUnitId')} className="w-full border p-2 rounded text-sm bg-white"><option value="">همه</option>{units.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}</select></div>
                    <div><label className="text-sm block mb-1">تاریخ ثبت (از)</label><input type="date" {...register('dateFrom')} className="w-full border p-2 rounded text-sm"/></div>
                    <div><label className="text-sm block mb-1">تاریخ ثبت (تا)</label><input type="date" {...register('dateTo')} className="w-full border p-2 rounded text-sm"/></div>
                    <div><label className="text-sm block mb-1">مبلغ (از)</label><input type="number" {...register('amountFrom')} className="w-full border p-2 rounded text-sm"/></div>
                    <div><label className="text-sm block mb-1">مبلغ (تا)</label><input type="number" {...register('amountTo')} className="w-full border p-2 rounded text-sm"/></div>
                 </div>
                <div className="flex justify-end items-center gap-2 pt-4 border-t">
                    <button type="button" onClick={clearSearch} className="bg-gray-200 text-gray-800 px-4 py-2 rounded-md font-semibold">پاک کردن</button>
                    <button type="submit" className="bg-blue-600 text-white px-6 py-2 rounded-md font-semibold">جستجو</button>
                </div>
            </form>
            
            {searchFilters && <ReportSummary summary={summaryData!} units={units} isLoading={isSummaryLoading} />}

            {searchFilters && (
                <div className="mt-6">
                    <h3 className="text-xl font-bold text-gray-800 mb-4">
                        نتایج جستجو {isSearchLoading ? '' : `(${searchResponse?.total || 0} مورد یافت شد)`}
                    </h3>
                    {isSearchLoading ? <p>در حال بارگذاری نتایج...</p> : 
                        <DataTable 
                            columns={columns} 
                            data={searchResponse?.data || []} 
                            pagination={{ page, total: searchResponse?.total || 0, itemsPerPage: 20 }}
                            onPageChange={setPage}
                        />
                    }
                </div>
            )}
            
            {viewingRequest && persons && categories && workflows && (
                <RequestDetailsModal 
                    request={{
                        ...viewingRequest,
                        workflow: (workflows || []).find(w => w.id === viewingRequest.workflowId),
                        internalWorkflow: (internalWorkflows || []).find(iw => iw.id === viewingRequest._internalReview?.internalWorkflowId)
                    }} 
                    persons={persons} 
                    requestCategories={categories} 
                    units={units} 
                    roles={roles} 
                    internalWorkflows={internalWorkflows || []} 
                    onClose={() => setViewingRequest(null)} 
                    onActionComplete={() => { 
                        setViewingRequest(null);
                        if (searchFilters) {
                            queryClient.invalidateQueries({ queryKey: ['reportList', searchFilters, page] });
                        }
                    }} 
                    loggedInUserId={currentUser!.id} 
                />
            )}
        </div>
    );
};

export default ReportsPage;