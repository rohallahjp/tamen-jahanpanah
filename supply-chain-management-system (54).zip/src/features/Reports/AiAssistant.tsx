import React, { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { parseQueryToFilters } from '../../services/aiCommandParser';
import { Unit, Person, RequestCategory } from '../../types';
import { useToast } from '../../hooks/useToast';

interface AiAssistantProps {
  units: Unit[];
  persons: Person[];
  categories: RequestCategory[];
  onFiltersParsed: (filters: any, summary: string) => void;
  onClear: () => void;
}

const AiAssistant: React.FC<AiAssistantProps> = ({ units, persons, categories, onFiltersParsed, onClear }) => {
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(true);
  const [serviceUnavailable, setServiceUnavailable] = useState(false);
  const [appliedFilters, setAppliedFilters] = useState<any>(null);
  const toast = useToast();

  const mutation = useMutation({
    mutationFn: (userQuery: string) => parseQueryToFilters(userQuery, units, persons, categories),
    onSuccess: (data) => {
      const summary = `متوجه شدم. نتایج را بر اساس درخواست شما فیلتر کردم.`;
      setAppliedFilters(data);
      onFiltersParsed(data, summary);
      setQuery('');
    },
    onError: (error: Error) => {
      if (error.message && error.message.includes("پیکربندی نشده")) {
        setServiceUnavailable(true);
      }
      toast.error(error.message || "خطایی در ارتباط با دستیار هوشمند رخ داد.");
    }
  });

  const handleQuerySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      mutation.mutate(query);
    }
  };
  
  const handleClear = () => {
      onClear();
      setQuery('');
      setAppliedFilters(null);
  }

  const renderFilterPills = () => {
      if (!appliedFilters) return null;
      
      const statusMap: { [key: string]: string } = { 'APPROVED': 'تایید شده', 'REJECTED': 'رد شده', 'IN_REVIEW': 'در حال بررسی' };
      const findName = (id: string, list: any[], key: string = 'id') => list.find(item => String(item[key]) === String(id))?.name || id;
      const findLabel = (id: string, list: any[]) => list.find(item => String(item.id) === String(id))?.label || id;

      const pills = Object.entries(appliedFilters).map(([key, value]) => {
          if (!value) return null;
          let label = '';
          switch (key) {
              case 'status': label = `وضعیت: ${statusMap[value as string] || value}`; break;
              case 'requestTypeId': label = `نوع: ${findLabel(value as string, categories)}`; break;
              case 'requesterId': label = `درخواست‌کننده: ${findName(value as string, persons, 'id')}`; break;
              case 'requestingUnitId': label = `واحد: ${findName(value as string, units, 'id')}`; break;
              case 'imprestHolderId': label = `تنخواه: ${findName(value as string, persons, 'id')}`; break;
              case 'dateFrom': label = `از تاریخ: ${new Date(value as string).toLocaleDateString('fa-IR')}`; break;
              case 'dateTo': label = `تا تاریخ: ${new Date(value as string).toLocaleDateString('fa-IR')}`; break;
              case 'amountFrom': label = `مبلغ از: ${(value as number).toLocaleString('fa-IR')}`; break;
              case 'amountTo': label = `مبلغ تا: ${(value as number).toLocaleString('fa-IR')}`; break;
              default: return null;
          }
          return <span key={key} className="bg-gray-200 text-gray-700 px-2.5 py-1 rounded-full text-xs font-semibold">{label}</span>;
      }).filter(Boolean);

      return pills.length > 0 ? <div className="mt-3 flex flex-wrap gap-2 items-center"><span className="text-xs font-bold text-gray-500">فیلترهای اعمال شده:</span>{pills}</div> : null;
  };
  
  if (serviceUnavailable) {
      return (
        <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-300">
            <div className="flex justify-between items-center text-lg font-bold text-gray-800">
                <span>دستیار هوشمند گزارش‌گیری</span>
            </div>
             <div className="mt-4 pt-4 border-t text-center">
                <p className="text-sm text-yellow-800">
                    سرویس دستیار هوشمند در حال حاضر در دسترس نیست. لطفا از پیکربندی صحیح کلید API در سرور اطمینان حاصل کنید.
                </p>
            </div>
        </div>
      );
  }

  return (
    <div className="bg-white p-4 rounded-lg border shadow-sm">
      <button onClick={() => setIsOpen(!isOpen)} className="w-full flex justify-between items-center text-lg font-bold text-gray-800">
        <span>دستیار هوشمند گزارش‌گیری</span>
        <svg xmlns="http://www.w3.org/2000/svg" className={`h-6 w-6 transition-transform ${isOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
      </button>

      {isOpen && (
        <div className="mt-4 pt-4 border-t">
          <p className="text-sm text-gray-600 mb-2">
            درخواست خود را به زبان فارسی وارد کنید. برای مثال: «درخواست‌های تایید شده ماه گذشته» یا «درخواست‌های واحد مالی با مبلغ بیش از ۱ میلیون ریال»
          </p>
          <form onSubmit={handleQuerySubmit} className="flex gap-2">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="درخواست شما..."
              className="flex-grow border p-2 rounded text-sm"
              disabled={mutation.isPending}
            />
            <button
              type="submit"
              disabled={mutation.isPending || !query.trim()}
              className="bg-blue-600 text-white px-6 py-2 rounded-md font-semibold disabled:bg-gray-400"
            >
              {mutation.isPending ? '...' : 'اجرا'}
            </button>
            <button
              type="button"
              onClick={handleClear}
              disabled={mutation.isPending}
              className="bg-gray-200 text-gray-800 px-4 py-2 rounded-md font-semibold"
            >
              پاک کردن
            </button>
          </form>
          {renderFilterPills()}
        </div>
      )}
    </div>
  );
};

export default AiAssistant;