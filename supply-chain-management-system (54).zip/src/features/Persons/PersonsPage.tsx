import React, { useState, useEffect, useMemo } from 'react';
import { useForm, SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { useParams, useNavigate } from 'react-router-dom';
import { z } from 'zod';

import { Person, PersonData, PersonSchema, PaginatedResponse } from '../../types';
import { personsApi } from '../../services/api';
import Modal from '../../components/Modal';
import { DataTable, ColumnDef } from '../../components/DataTable';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import { useToast } from '../../hooks/useToast';
import { useDebounce } from '../../hooks/useDebounce';
import { useAuth } from '../../hooks/useAuth.ts';

const TABS = [
    { id: 'all', label: 'همه اشخاص' },
    { id: 'beneficiaries', label: 'ذی‌نفعان' },
];

type FormData = z.infer<typeof PersonSchema>;

const PersonsPage: React.FC = () => {
    const { personType = 'all' } = useParams<{ personType: string }>();
    const navigate = useNavigate();
    const queryClient = useQueryClient();
    const { read: canRead, create: canCreate, update: canUpdate, delete: canDelete } = usePermissions('PERSONS');
    const toast = useToast();
    const { currentUser } = useAuth();
    const [page, setPage] = useState(1);
    const [searchQuery, setSearchQuery] = useState('');
    const debouncedSearch = useDebounce(searchQuery, 300);

    const apiFilters = useMemo(() => {
        const filters: Record<string, boolean> = {};
        if (personType === 'beneficiaries') {
            filters.isBeneficiary = true;
        }
        return filters;
    }, [personType]);

    const { data: personsResponse, isLoading: isPersonsLoading } = useQuery<PaginatedResponse<Person>>({
        queryKey: ['persons', page, debouncedSearch, personType],
        queryFn: () => personsApi.getAll(page, debouncedSearch, apiFilters),
        placeholderData: (previousData) => previousData,
    });

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingPerson, setEditingPerson] = useState<Person | null>(null);

    const { register, handleSubmit, reset, formState: { errors } } = useForm<FormData>({
        resolver: zodResolver(PersonSchema as any)
    });
    
    useEffect(() => {
        setPage(1);
    }, [debouncedSearch, personType]);
    
    useEffect(() => {
        if (isModalOpen) {
            if (editingPerson) {
                reset({
                    ...editingPerson,
                });
            } else {
                reset({
                    fullName: '',
                    nationalId: '',
                    isBeneficiary: false,
                    email: '',
                    accountNumber: '',
                    cardNumber: '',
                    iban: '',
                    address: '',
                    phone: '',
                });
            }
        }
    }, [editingPerson, isModalOpen, reset]);
    
    const mutation = useMutation({
        mutationFn: (data: { formData: PersonData, id?: number }) => {
            const finalData: PersonData & { actingUserId?: number } = { ...data.formData };
            if (finalData.pettyCashLimit !== undefined) {
                (finalData as any).pettyCashBalance = finalData.pettyCashLimit;
                if (currentUser) {
                    finalData.actingUserId = currentUser.id;
                }
            }
            return data.id ? personsApi.update(data.id, finalData) : personsApi.create(finalData);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['persons'] });
            queryClient.invalidateQueries({ queryKey: ['units_tree'] });
            setIsModalOpen(false);
            toast.success('شخص با موفقیت ذخیره شد.');
        },
        onError: (err: Error) => toast.error(`خطا: ${err.message}`),
    });

    const deleteMutation = useMutation({
        mutationFn: (id: number) => personsApi.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['persons'] });
            toast.success('شخص با موفقیت حذف شد.');
        },
        onError: (err: Error) => toast.error(`خطا در حذف: ${err.message}`),
    });
    
    const onSubmit: SubmitHandler<FormData> = (data) => {
        const finalData: PersonData = {
            ...data,
            isSystemUser: editingPerson?.isSystemUser ?? false, 
            roleIds: editingPerson?.roleIds ?? [],
            pettyCashLimit: editingPerson?.pettyCashLimit ?? undefined,
            pettyCashBalance: editingPerson?.pettyCashBalance ?? undefined,
        };
        mutation.mutate({ formData: finalData, id: editingPerson?.id });
    };

    const handleDelete = (id: number) => {
        if (window.confirm('آیا از حذف این شخص مطمئن هستید؟ این عمل غیرقابل بازگشت است.')) {
            deleteMutation.mutate(id);
        }
    };
    
    const openModal = (person: Person | null = null) => {
        setEditingPerson(person);
        setIsModalOpen(true);
    };

    const handleTabChange = (type: string) => navigate(`/persons/${type}`);

    const columns: ColumnDef<Person>[] = [
        { accessorKey: 'fullName', header: 'نام کامل' },
        { accessorKey: 'nationalId', header: 'کد ملی' },
        { accessorKey: 'unitName', header: 'واحد / سمت' },
        { accessorKey: 'isSystemUser', header: 'ویژگی‌ها', cell: (p) => {
            const isPettyCashHolder = p.roleNames?.includes('تنخواه گردان');
            return (
                <div className="flex flex-col gap-1.5 text-xs">
                    {p.isSystemUser && <span className="bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full w-fit">کاربر سامانه</span>}
                    {p.isBeneficiary && <span className="bg-green-100 text-green-800 px-2 py-0.5 rounded-full w-fit">ذی‌نفع</span>}
                    {isPettyCashHolder && <span className="bg-yellow-100 text-yellow-800 px-2 py-0.5 rounded-full w-fit">تنخواه بگیر</span>}
                </div>
            )
        }},
        { accessorKey: 'actions', header: 'عملیات', width: '120px', cell: (person) => (
            <div className="flex justify-center gap-4">
                <button onClick={() => openModal(person)} disabled={!canUpdate} className="text-blue-600 hover:underline font-semibold disabled:text-gray-400 disabled:no-underline">ویرایش</button>
                <button onClick={() => handleDelete(person.id)} disabled={!canDelete || person.isSystemUser} className="text-red-600 hover:underline font-semibold disabled:text-gray-400 disabled:no-underline" title={person.isSystemUser ? "امکان حذف کاربری که به سیستم دسترسی دارد وجود ندارد." : ""}>حذف</button>
            </div>
        )}
    ];

    if (!canRead) return <AccessDenied />;

    return (
        <section className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-800">مدیریت اشخاص</h2>
                <button onClick={() => openModal()} disabled={!canCreate} className="bg-blue-600 text-white px-5 py-2 rounded-lg font-semibold flex items-center gap-2 hover:bg-blue-700 disabled:bg-gray-400">افزودن شخص جدید</button>
            </div>

            <div className="border-b border-gray-200">
                <nav className="flex -mb-px gap-6">
                    {TABS.map(tab => (
                        <button key={tab.id} onClick={() => handleTabChange(tab.id)} className={`py-3 px-1 font-semibold text-sm ${personType === tab.id ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}>{tab.label}</button>
                    ))}
                </nav>
            </div>
            
            <div className="relative">
                <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="جستجو بر اساس نام، کد ملی و..."
                    className="w-full p-2 pl-10 border rounded-md"
                />
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
            </div>

            {isPersonsLoading ? <p>در حال بارگذاری...</p> : 
                <DataTable 
                    columns={columns} 
                    data={personsResponse?.data || []}
                    pagination={{ page, total: personsResponse?.total || 0, itemsPerPage: 20 }}
                    onPageChange={setPage}
                />
            }

            {isModalOpen && (
                <Modal title={editingPerson ? `ویرایش: ${editingPerson.fullName}` : 'افزودن شخص جدید'} onClose={() => setIsModalOpen(false)} size="3xl">
                    <form onSubmit={handleSubmit(onSubmit as SubmitHandler<FormData>)} className="space-y-4 p-6 max-h-[80vh] overflow-y-auto">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">نام کامل</label>
                            <input {...register('fullName')} className="w-full border p-2 rounded-md" />
                            {errors.fullName && <p className="text-red-500 text-xs mt-1">{String(errors.fullName.message)}</p>}
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">کد ملی</label>
                                <input {...register('nationalId')} className="w-full border p-2 rounded-md" />
                                {errors.nationalId && <p className="text-red-500 text-xs mt-1">{String(errors.nationalId.message)}</p>}
                            </div>
                             <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">شماره تماس (اختیاری)</label>
                                <input {...register('phone')} className="w-full border p-2 rounded-md" />
                            </div>
                        </div>

                        <div className="pt-4 border-t space-y-3">
                             <h3 className="text-md font-semibold text-gray-800">ویژگی‌ها</h3>
                             <div className="flex flex-wrap gap-4 items-start">
                                <label className="flex items-center gap-2 p-2 bg-gray-50 rounded-md border w-fit">
                                    <input type="checkbox" {...register('isBeneficiary')} /> ذی‌نفع
                                </label>
                             </div>
                        </div>

                         <div className="pt-4 border-t">
                            <h3 className="text-md font-semibold text-gray-800 mb-2">اطلاعات مالی (اختیاری)</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">شماره حساب</label>
                                    <input {...register('accountNumber')} className="w-full border p-2 rounded-md" />
                                    {errors.accountNumber && <p className="text-red-500 text-xs mt-1">{String(errors.accountNumber.message)}</p>}
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">شماره شبا (IBAN)</label>
                                    <input {...register('iban')} className="w-full border p-2 rounded-md" placeholder="IR..." />
                                    {errors.iban && <p className="text-red-500 text-xs mt-1">{String(errors.iban.message)}</p>}
                                </div>
                            </div>
                        </div>

                        <div className="flex justify-end gap-2 pt-4 border-t mt-4">
                            <button type="button" onClick={() => setIsModalOpen(false)} className="bg-gray-200 px-4 py-2 rounded font-semibold">لغو</button>
                            <button type="submit" disabled={mutation.isPending} className="bg-green-500 text-white px-4 py-2 rounded disabled:bg-gray-400 font-semibold">
                                {mutation.isPending ? 'در حال ذخیره...' : 'ذخیره'}
                            </button>
                        </div>
                    </form>
                </Modal>
            )}
        </section>
    );
};

export default PersonsPage;