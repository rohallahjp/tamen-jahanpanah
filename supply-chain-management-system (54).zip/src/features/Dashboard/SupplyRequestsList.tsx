import React, { useState } from 'react';
import { SupplyRequest } from '../../types';
import ProcessStepper from './ProcessStepper';
import { formatCurrency } from '../../utils/formatters';

interface SupplyRequestsListProps {
  supplyRequests: SupplyRequest[];
  onAddNew: () => void;
  onViewDetails: (request: SupplyRequest) => void;
  onEditRequest: (request: SupplyRequest) => void;
  loggedInUserId: number;
  canCreate: boolean;
  pagination: {
      page: number;
      totalItems: number;
      onPageChange: (newPage: number) => void;
  };
}

const ITEMS_PER_PAGE = 10;

const SupplyRequestsList: React.FC<SupplyRequestsListProps> = ({ 
  supplyRequests, 
  onAddNew, 
  onViewDetails, 
  onEditRequest, 
  loggedInUserId, 
  canCreate,
  pagination,
}) => {
  const [expandedRowId, setExpandedRowId] = useState<string | null>(null);

  const getStatusBadge = (status: SupplyRequest['status']) => {
    const statusMap = { 'IN_REVIEW': { text: 'در حال بررسی', dot: 'bg-blue-500', bg: 'bg-blue-100', border: 'border-blue-300' }, 'APPROVED': { text: 'تایید نهایی', dot: 'bg-green-500', bg: 'bg-green-100', border: 'border-green-300' }, 'REJECTED': { text: 'رد شده', dot: 'bg-red-500', bg: 'bg-red-100', border: 'border-red-300' } };
    return statusMap[status] || { text: status, dot: 'bg-gray-500', bg: 'bg-gray-100', border: 'border-gray-300' };
  };

  const totalPages = Math.ceil(pagination.totalItems / ITEMS_PER_PAGE);

  return (
    <section className="space-y-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-gray-800">کارتابل درخواست‌ها</h2>
        {canCreate && <button onClick={onAddNew} className="bg-green-600 text-white px-5 py-2 rounded-lg font-semibold flex items-center gap-2 hover:bg-green-700 shadow-md"><svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110 2h3V6a1 1 0 011-1z" /></svg>ثبت درخواست جدید</button>}
      </div>
      
      <div className="rounded-lg border border-gray-200 bg-white shadow-sm overflow-hidden">
        <div className="overflow-y-auto overflow-x-auto max-h-[70vh] relative">
          <table className="w-full text-sm">
              <thead className="bg-gray-50 text-gray-600 sticky top-0 z-10"><tr className="text-right"><th className="p-3 w-12 text-center"></th><th className="p-3">شماره</th><th className="p-3">موضوع</th><th className="p-3">درخواست‌کننده</th><th className="p-3">مبلغ</th><th className="p-3">تاریخ ثبت</th><th className="p-3">تاریخ سررسید</th><th className="p-3">وضعیت</th><th className="p-3 text-center">عملیات</th></tr></thead>
              <tbody className="divide-y divide-gray-200">{supplyRequests.length === 0 ? (<tr><td colSpan={9} className="text-center p-8 text-gray-500">موردی برای نمایش وجود ندارد. برای شروع، یک درخواست جدید ثبت کنید.</td></tr>) : (supplyRequests.map((req) => { const isExpanded = expandedRowId === req.id; const statusInfo = getStatusBadge(req.status); const isOwner = req.requesterId === loggedInUserId; const dueDate = req.dueDate ? new Date(req.dueDate).toLocaleDateString('fa-IR') : '---'; const isOverdue = req.status === 'IN_REVIEW' && req.dueDate && new Date(req.dueDate) < new Date(); 
              const amountAsNumber = Number(req.amount) || 0;
              const activeStepForUser = req._activeSteps.find(s => s.assigneeId === loggedInUserId);
              const wasInternallyReviewed = activeStepForUser && req._history.some(h => h.action === 'INTERNAL_REVIEW_END' && h.internalReviewDetails?.mainStepId === activeStepForUser.stepId && h.internalReviewDetails?.mainAssigneeId === loggedInUserId);
              return (<React.Fragment key={req.id}>
                  <tr className="hover:bg-gray-50 transition-colors">
                      <td className="p-3 text-center"><button onClick={() => setExpandedRowId(isExpanded ? null : req.id)} className="text-gray-500 font-bold text-lg hover:text-blue-600 w-6 h-6 flex items-center justify-center rounded">{isExpanded ? '−' : '+'}</button></td>
                      <td className="p-3 font-mono text-gray-500">{req.id}</td>
                      <td className="p-3 font-semibold text-gray-800">{req.requestCategoryLabel || '---'}</td>
                      <td className="p-3">{req.requesterName || '---'}</td>
                      <td className="p-3 font-mono">{formatCurrency(amountAsNumber > 0 ? amountAsNumber : undefined, req.currency)}</td><td className="p-3 text-gray-600">{req.submissionDate || '---'}</td>
                      <td className={`p-3 text-gray-600 ${isOverdue ? 'text-red-600 font-bold' : ''}`}>{dueDate}</td>
                      <td className="p-3"><div className="flex flex-col items-start gap-1">
                        <div className={`inline-flex items-center gap-2 px-2.5 py-1 rounded-full text-xs font-medium border ${statusInfo.bg} ${statusInfo.border}`}><span className={`h-2 w-2 rounded-full ${statusInfo.dot}`}></span><span className="text-gray-800">{statusInfo.text}</span></div>
                        {wasInternallyReviewed && <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full text-xs font-medium border bg-purple-100 border-purple-300"><span className="h-2 w-2 rounded-full bg-purple-500"></span><span className="text-gray-800">نظر کارشناس ثبت شد</span></div>}
                      </div></td>
                      <td className="p-3 text-center"><div className="flex justify-center items-center gap-4"><button onClick={() => onViewDetails(req)} className="text-blue-600 font-semibold hover:underline">مشاهده جزئیات</button>{req.status === 'REJECTED' && isOwner && <button onClick={() => onEditRequest(req)} className="text-green-600 font-semibold hover:underline">اصلاح و ارسال مجدد</button>}</div></td>
                  </tr>
                  {isExpanded && <tr className="bg-slate-50"><td colSpan={9} className="p-0"><div className="p-4"><h4 className="text-sm font-bold text-gray-700 mb-3">مسیر فرآیند</h4><ProcessStepper request={req} /></div></td></tr>}
              </React.Fragment>); }))}</tbody>
          </table>
        </div>
        {totalPages > 1 && (
            <div className="flex justify-between items-center p-3 border-t border-gray-200 text-sm">
                <span className="text-gray-600">
                    مجموع: <span className="font-semibold">{pagination.totalItems.toLocaleString('fa-IR')}</span> مورد
                </span>
                <div className="flex items-center gap-2">
                    <button
                        onClick={() => pagination.onPageChange(pagination.page - 1)}
                        disabled={pagination.page === 1}
                        className="px-3 py-1 border rounded-md bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        قبلی
                    </button>
                    <span className="text-gray-700 font-mono">
                       {pagination.page.toLocaleString('fa-IR')} / {totalPages.toLocaleString('fa-IR')}
                    </span>
                    <button
                        onClick={() => pagination.onPageChange(pagination.page + 1)}
                        disabled={pagination.page >= totalPages}
                        className="px-3 py-1 border rounded-md bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        بعدی
                    </button>
                </div>
            </div>
        )}
      </div>
    </section>
  );
};

export default SupplyRequestsList;