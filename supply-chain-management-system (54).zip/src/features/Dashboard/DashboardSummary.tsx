import React from 'react';
import { DashboardSummary as DashboardSummaryType } from '../../types';
import { formatCurrency, formatNumber } from '../../utils/formatters';

interface DashboardSummaryProps {
  summary: DashboardSummaryType | undefined;
  isLoading: boolean;
  onPendingClick: () => void;
  onSubmissionsClick: () => void;
}

const StatCard: React.FC<{ title: string; value: string | number; icon: React.ReactNode; footer?: string; onClick?: () => void; }> = ({ title, value, icon, footer, onClick }) => {
    const content = (
        <>
            <div className="flex items-start justify-between">
                <div className="bg-blue-100 text-blue-600 rounded-full p-3">{icon}</div>
                <div className="text-left">
                    <p className="text-3xl font-bold text-gray-800">{typeof value === 'number' ? formatNumber(value) : value}</p>
                    <p className="text-sm text-gray-500 font-semibold">{title}</p>
                </div>
            </div>
            {footer && <p className="text-xs text-gray-400 mt-3">{footer}</p>}
        </>
    );

    const baseClasses = "bg-white p-5 rounded-lg shadow-sm border flex flex-col justify-between";
    const clickableClasses = "text-right hover:border-blue-500 hover:ring-2 hover:ring-blue-200 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500";

    return onClick ? (
        <button type="button" onClick={onClick} className={`${baseClasses} ${clickableClasses}`}>
            {content}
        </button>
    ) : (
        <div className={baseClasses}>
            {content}
        </div>
    );
};


const SkeletonCard: React.FC = () => (
    <div className="bg-gray-200 p-5 rounded-lg shadow-sm h-32 animate-pulse" />
);


const DashboardSummary: React.FC<DashboardSummaryProps> = ({ summary, isLoading, onPendingClick, onSubmissionsClick }) => {
    if (isLoading || !summary) {
        return (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {[...Array(4)].map((_, i) => <SkeletonCard key={i} />)}
            </div>
        );
    }
    
    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatCard 
                title="کارهای منتظر اقدام شما" 
                value={summary.myPendingTasks} 
                onClick={onPendingClick}
                icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
                footer="درخواست‌هایی که نیازمند تایید یا رد شما هستند"
            />
            <StatCard 
                title="درخواست‌های ثبت شده من" 
                value={summary.myRecentSubmissions} 
                onClick={onSubmissionsClick}
                icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>}
                footer="تعداد درخواست‌هایی که در ۳۰ روز گذشته ثبت کرده‌اید"
            />
            <StatCard 
                title="کل درخواست‌های در جریان" 
                value={summary.totalPending} 
                icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h5M7 9l3 3h6l3-3" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 20v-5h-5M17 15l-3-3h-6l-3 3" /></svg>}
                footer="تعداد کل درخواست‌های در حال بررسی در سیستم"
            />
            <StatCard 
                title="مبالغ تایید شده این ماه" 
                value={formatCurrency(summary.totalApprovedThisMonth, 'RIAL')} 
                icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" /></svg>}
                footer="مجموع مبالغ تایید شده در ماه جاری"
            />
        </div>
    );
};

export default DashboardSummary;