import React, { useState, useMemo, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import {
  SupplyRequest,
  SupplyRequestData,
  CreateDraftData,
  PaginatedResponse,
  Person,
  RequestCategory,
  Workflow,
  InternalWorkflow,
} from '../../types';
import {
  workflowEngineApi,
  dashboardApi,
  personsApi,
  requestCategoriesApi,
  workflowsApi,
  internalWorkflowsApi,
} from '../../services/api';
import SupplyRequestForm from './SupplyRequestForm';
import SupplyRequestsList from './SupplyRequestsList';
import RequestDetailsModal from './RequestDetailsModal';
import DashboardSummary from './DashboardSummary';
import { useAuth } from '../../hooks/useAuth';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import { useMainLayoutContext } from '../../App';
import { useToast } from '../../hooks/useToast';

const DashboardPage: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { 
      isLoading: isContextLoading,
      units,
      roles,
  } = useMainLayoutContext();
  
  const [formInitialData, setFormInitialData] = useState<Partial<SupplyRequest> | null>(null);
  const [viewingRequest, setViewingRequest] = useState<SupplyRequest | null>(null);
  const [page, setPage] = useState(1);
  const queryClient = useQueryClient();
  const { currentUser } = useAuth();
  const { read: canRead, create: canCreate } = usePermissions('DASHBOARD');
  const toast = useToast();

  // FIX: Wrapped queryFn calls in arrow functions to resolve overload errors.
  const { data: workflows, isLoading: isWorkflowsLoading } = useQuery<Workflow[]>({ queryKey: ['workflows_all'], queryFn: () => workflowsApi.getAllUnpaginated() });
  const { data: persons, isLoading: isPersonsLoading } = useQuery<Person[]>({ queryKey: ['persons_all'], queryFn: () => personsApi.getAllUnpaginated() });
  const { data: categories, isLoading: isCategoriesLoading } = useQuery<RequestCategory[]>({ queryKey: ['requestCategories_all'], queryFn: () => requestCategoriesApi.getAllUnpaginated() });
  const { data: internalWorkflows, isLoading: isInternalWorkflowsLoading } = useQuery<InternalWorkflow[]>({ queryKey: ['internalWorkflows_all'], queryFn: () => internalWorkflowsApi.getAllUnpaginated() });
  
  const { data: summaryData, isLoading: isSummaryLoading } = useQuery({
      queryKey: ['dashboardSummary', currentUser?.id],
      queryFn: () => dashboardApi.getSummary({ userId: currentUser!.id }),
      enabled: !!currentUser,
  });

  const { data: requestsResponse, isLoading: isRequestsLoading } = useQuery<PaginatedResponse<SupplyRequest>>({
      queryKey: ['dashboardRequests', currentUser?.id, page],
      queryFn: () => dashboardApi.getRequests({ userId: currentUser!.id }, page),
      enabled: !!currentUser,
  });

  useEffect(() => {
    const prefilledData = location.state as CreateDraftData | undefined;
    if (prefilledData) {
      const initialFormData: Partial<SupplyRequest> = {
          requestTypeId: prefilledData.requestTypeId,
          imprestHolderId: prefilledData.imprestHolderId ? Number(prefilledData.imprestHolderId) : undefined,
          invoices: prefilledData.beneficiaryId ? [{ beneficiaryId: Number(prefilledData.beneficiaryId), items: [], invoiceNumber: '', attachmentName: '' }] : [],
      };
      setFormInitialData(initialFormData);
      navigate(location.pathname, { replace: true, state: null });
    }
  }, [location, navigate]);

  const createRequestMutation = useMutation({
    mutationFn: (newRequestData: SupplyRequestData) => workflowEngineApi.submitNewRequest(newRequestData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dashboardRequests'] });
      queryClient.invalidateQueries({ queryKey: ['dashboardSummary'] });
      setFormInitialData(null);
      toast.success('درخواست شما با موفقیت ثبت و فرآیند آن آغاز شد!');
    },
    onError: (error: Error) => {
      toast.error(`خطا در ثبت درخواست: ${error.message}`);
    }
  });
  
  const resubmitMutation = useMutation({
    mutationFn: (data: { requestId: string, updatedData: SupplyRequestData }) => 
        workflowEngineApi.resubmitRejectedRequest(data.requestId, data.updatedData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dashboardRequests'] });
      queryClient.invalidateQueries({ queryKey: ['dashboardSummary'] });
      setFormInitialData(null);
      toast.success('درخواست با موفقیت اصلاح و ارسال شد!');
    },
    onError: (error: Error) => {
      toast.error(`خطا در ارسال مجدد: ${error.message}`);
    }
  });

  const requestsWithWorkflow = useMemo(() => {
    if (!currentUser) return [];

    return (requestsResponse?.data || [])
      .map((req) => ({ 
          ...req, 
          workflow: (workflows || []).find((w) => w.id === req.workflowId),
          internalWorkflow: (internalWorkflows || []).find(iw => iw.id === req._internalReview?.internalWorkflowId)
      }))
      .sort((a, b) => new Date(b.submissionDateForSort).getTime() - new Date(a.submissionDateForSort).getTime());
  }, [requestsResponse, workflows, internalWorkflows, currentUser]);

  const handlePendingClick = () => {
    if (!currentUser) return;
    navigate('/reports', { 
        state: { 
            filters: { 
                assigneeId: String(currentUser.id),
                status: 'IN_REVIEW' 
            } 
        } 
    });
  };

  const handleSubmissionsClick = () => {
      if (!currentUser) return;
      navigate('/reports', { 
          state: { 
              filters: { 
                  requesterId: String(currentUser.id) 
              } 
          } 
      });
  };

  if (!canRead) {
    return <AccessDenied />;
  }
  
  const isLoadingPageData = isSummaryLoading || isRequestsLoading || isWorkflowsLoading || isPersonsLoading || isCategoriesLoading || isInternalWorkflowsLoading;

  if (isLoadingPageData) {
    return (
      <div className="flex justify-center items-center h-full p-10">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }
  
  if (!currentUser || !persons || !categories || !workflows) {
    return <p>خطا: داده های اصلی برنامه بارگذاری نشد.</p>
  }

  if (formInitialData) {
    if (isContextLoading) { 
      return (
        <div className="flex justify-center items-center h-full p-10">
          <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div>
          <p className="mr-4 text-gray-600">در حال آماده سازی فرم درخواست...</p>
        </div>
      );
    }
    return (
      <SupplyRequestForm
        initialData={formInitialData as SupplyRequest}
        persons={persons}
        requestCategories={categories}
        units={units}
        workflows={workflows}
        onSubmit={async (data) => {
            if (formInitialData && 'id' in formInitialData) { 
                resubmitMutation.mutate({ requestId: (formInitialData as SupplyRequest).id, updatedData: data });
            } else {
                createRequestMutation.mutate(data);
            }
        }}
        onCancel={() => {
            setFormInitialData(null);
        }}
        loggedInUserId={currentUser.id}
      />
    );
  }

  const handleAddNew = () => {
      setFormInitialData({}); 
  }
  
  const handleEditRequest = (request: SupplyRequest) => {
      setFormInitialData(request);
  }

  return (
    <div className="space-y-6">
      <DashboardSummary
        summary={summaryData}
        isLoading={isSummaryLoading}
        onPendingClick={handlePendingClick}
        onSubmissionsClick={handleSubmissionsClick}
      />
      <SupplyRequestsList
        supplyRequests={requestsWithWorkflow}
        onAddNew={handleAddNew}
        onViewDetails={(request) => setViewingRequest(request)}
        onEditRequest={handleEditRequest}
        loggedInUserId={currentUser.id}
        canCreate={canCreate}
        pagination={{
            page: page,
            totalItems: requestsResponse?.total || 0,
            onPageChange: setPage,
        }}
      />
      {viewingRequest && (
        <RequestDetailsModal
          request={viewingRequest}
          persons={persons}
          requestCategories={categories}
          units={units}
          roles={roles}
          internalWorkflows={internalWorkflows || []}
          onClose={() => setViewingRequest(null)}
          onActionComplete={() => {
            setViewingRequest(null);
            queryClient.invalidateQueries({ queryKey: ['dashboardRequests'] });
            queryClient.invalidateQueries({ queryKey: ['dashboardSummary'] });
          }}
          loggedInUserId={currentUser.id}
        />
      )}
    </div>
  );
};

export default DashboardPage;