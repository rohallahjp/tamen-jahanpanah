

import React from 'react';
import { SupplyRequest } from '../../types';

interface ProcessStepperProps {
  request: SupplyRequest;
}

const ProcessStepper: React.FC<ProcessStepperProps> = ({ request }) => {
  const { workflow, status, _history = [], _activeSteps = [], _internalReview } = request;

  if (!workflow?.steps) {
    return <p className="text-center text-gray-500 text-sm">اطلاعات فرآیند در دسترس نیست.</p>;
  }

  const currentStepId = _activeSteps[0]?.stepId;
  const currentStepIndex = workflow.steps.findIndex(s => s.id === currentStepId);

  return (
    <div className="flex items-start justify-between w-full p-4 overflow-x-auto">
      {workflow.steps.map((step, index) => {
        const historyForStep = _history.filter(h => h.stepId === step.id);
        const approvalEntry = historyForStep.find(h => h.action === 'APPROVE');
        const rejectionEntry = historyForStep.find(h => h.action === 'REJECT');

        const isUnderInternalReview = !!_internalReview && _internalReview.mainStepId === step.id;

        let isCompleted = false;
        if (status === 'APPROVED') {
          isCompleted = true;
        } else if (status === 'IN_REVIEW') {
          isCompleted = currentStepIndex > index;
        } else if (status === 'REJECTED') {
          isCompleted = !!approvalEntry;
        }
        
        if (isUnderInternalReview) isCompleted = true;

        const isActive = status === 'IN_REVIEW' && index === currentStepIndex && !isUnderInternalReview;
        const isRejectedHere = status === 'REJECTED' && !!rejectionEntry && !approvalEntry;

        let circleClasses = 'bg-gray-200 text-gray-500';
        let lineClasses = 'bg-gray-200';
        let textClasses = 'text-gray-600';
        
        const wasRejectedBeforeResubmit = _history.some(h => h.action === 'REJECT' && h.stepId > step.id);
        const isAfterRejectionPoint = status === 'REJECTED' && !isRejectedHere && !isCompleted && wasRejectedBeforeResubmit;

        if (isCompleted) {
          circleClasses = 'bg-green-500 text-white';
          lineClasses = 'bg-green-500';
        } else if (isActive) {
          circleClasses = 'bg-blue-600 text-white ring-4 ring-blue-200';
          textClasses = 'text-blue-600 font-bold';
          lineClasses = isCompleted ? 'bg-green-500' : 'bg-gray-200';
        } else if (isRejectedHere) {
          circleClasses = 'bg-red-500 text-white';
          textClasses = 'text-red-600 font-bold';
          lineClasses = 'bg-red-500';
        } else if(isAfterRejectionPoint) {
            lineClasses = 'bg-gray-200';
        }

        if (isUnderInternalReview) {
            circleClasses = 'bg-yellow-500 text-white ring-4 ring-yellow-200 animate-pulse';
            textClasses = 'text-yellow-700 font-bold';
        }

        const connectorLineClass = index > 0 && workflow.steps.length > 1 ?
            (isCompleted || isActive || isRejectedHere ? lineClasses : 'bg-gray-200')
            : 'bg-transparent';

        return (
          <React.Fragment key={step.id}>
            {index > 0 && <div className={`flex-1 h-1 mt-5 mx-2 rounded ${connectorLineClass}`} />}
            <div className="flex flex-col items-center text-center w-28 flex-shrink-0">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg transition-all duration-300 ${circleClasses}`}>
                {isCompleted && !isUnderInternalReview ? '✓' : isRejectedHere ? '✗' : isUnderInternalReview ? '…' : index + 1}
              </div>
              <p className={`mt-2 text-xs font-semibold ${textClasses}`}>{step.name}</p>
              {isUnderInternalReview && <p className="text-[10px] text-yellow-700 font-semibold">بررسی داخلی</p>}
            </div>
          </React.Fragment>
        );
      })}
    </div>
  );
};

export default ProcessStepper;