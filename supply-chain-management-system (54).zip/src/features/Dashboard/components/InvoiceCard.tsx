
import React, { useState } from 'react';
import { useFieldArray, Control, useWatch, UseFormRegister, UseFormSetValue, FieldErrors } from 'react-hook-form';
import { Person } from '../../../types';
import { formatCurrency } from '../../../utils/formatters';
import ImageLightbox from '../../../components/ImageLightbox';

const fileToBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
});

const InvoiceItemsArray: React.FC<{ invoiceIndex: number; control: Control<any>; register: UseFormRegister<any>; currency: 'RIAL' | 'USD'; }> = ({ invoiceIndex, control, register, currency }) => {
    const { fields, append, remove } = useFieldArray({
        control,
        name: `invoices.${invoiceIndex}.items`
    });

    const items = useWatch({
      control,
      name: `invoices.${invoiceIndex}.items`
    });

    return (
        <div className="pl-4 mt-3 pt-3 border-t border-gray-200 space-y-2">
            <div className="grid grid-cols-[1fr_80px_110px_110px_auto] gap-x-2 items-center mb-1 pr-1">
                <h4 className="text-xs font-bold text-gray-600">شرح</h4>
                <h4 className="text-xs font-bold text-gray-600 text-center">تعداد</h4>
                <h4 className="text-xs font-bold text-gray-600 text-center">قیمت واحد</h4>
                <h4 className="text-xs font-bold text-gray-600 text-center">قیمت کل</h4>
                <div />
            </div>
            {fields.map((item, k) => {
              const currentItem = items?.[k];
              const total = (Number(currentItem?.quantity) || 0) * (Number(currentItem?.unitPrice) || 0);

              return (
                <div key={item.id} className="grid grid-cols-[1fr_80px_110px_110px_auto] gap-x-2 items-center">
                    <input {...register(`invoices.${invoiceIndex}.items.${k}.description`)} placeholder="شرح کالا یا خدمات" className="w-full border p-1 rounded text-xs" />
                    <input type="number" {...register(`invoices.${invoiceIndex}.items.${k}.quantity`, { valueAsNumber: true })} placeholder="تعداد" className="w-full border p-1 rounded text-xs text-center" />
                    <input type="number" {...register(`invoices.${invoiceIndex}.items.${k}.unitPrice`, { valueAsNumber: true })} placeholder="قیمت واحد" className="w-full border p-1 rounded text-xs text-center" />
                    <div className="w-full text-center border p-1 rounded text-xs bg-gray-100 font-mono" dir="ltr">{formatCurrency(total, currency)}</div>
                    <button type="button" onClick={() => remove(k)} className="bg-red-100 text-red-700 h-6 w-6 flex items-center justify-center rounded-md hover:bg-red-200 font-bold text-sm" aria-label={`Remove item ${k + 1}`}>&times;</button>
                </div>
            )})}
             <button type="button" onClick={() => append({ description: '', quantity: 1, unitPrice: 0 })} className="text-xs text-green-600 font-semibold hover:underline">+ افزودن قلم</button>
        </div>
    );
};


interface InvoiceCardProps {
    index: number;
    control: Control<any>;
    register: UseFormRegister<any>;
    setValue: UseFormSetValue<any>;
    removeInvoice: (index: number) => void;
    beneficiaries: Person[];
    currency: 'RIAL' | 'USD';
    errors: FieldErrors<any>;
}

export const InvoiceCard: React.FC<InvoiceCardProps> = ({ index, control, register, setValue, removeInvoice, beneficiaries, currency, errors }) => {
    const [lightboxSrc, setLightboxSrc] = useState<string | null>(null);

    const watchedItems = useWatch({ control, name: `invoices.${index}.items` });
    const attachmentUrl = useWatch({ control, name: `invoices.${index}.attachmentUrl` });
    const invoiceTotal = watchedItems?.reduce((sum: number, item: any) => sum + (Number(item.quantity) || 0) * (Number(item.unitPrice) || 0), 0) || 0;
    const beneficiaryError = (errors.invoices as any)?.[index]?.beneficiaryId;

    const onFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const base64Url = await fileToBase64(file);
            setValue(`invoices.${index}.attachmentName`, file.name);
            setValue(`invoices.${index}.attachmentUrl`, base64Url, { shouldValidate: true });
        }
    };
    
    return (
        <>
            <div className="p-3 border rounded-lg bg-gray-50 relative overflow-hidden">
                <div className="grid grid-cols-1 md:grid-cols-[1fr_1fr_auto] gap-3 items-start">
                    <div>
                        <label htmlFor={`invoiceNumber-${index}`} className="text-xs font-medium text-gray-600 mb-1 block">شماره فاکتور</label>
                        <input id={`invoiceNumber-${index}`} {...register(`invoices.${index}.invoiceNumber`)} className="w-full border p-1.5 rounded" />
                    </div>
                    <div>
                        <label htmlFor={`beneficiaryId-${index}`} className="text-xs font-medium text-gray-600 mb-1 block">ذی‌نفع</label>
                        <select id={`beneficiaryId-${index}`} {...register(`invoices.${index}.beneficiaryId`)} className="w-full border p-1.5 rounded bg-white">
                            <option value="">...</option>
                            {beneficiaries.map(p => <option key={p.id} value={p.id}>{p.fullName}</option>)}
                        </select>
                        {beneficiaryError && <p className="text-red-500 text-xs mt-1">{String(beneficiaryError.message)}</p>}
                    </div>
                    <button type="button" onClick={() => removeInvoice(index)} className="bg-red-100 text-red-700 h-9 w-9 flex items-center justify-center rounded-md hover:bg-red-200 font-bold text-xl mt-auto mb-0" aria-label={`Remove invoice ${index + 1}`}>
                        &times;
                    </button>
                </div>
                <div className="mt-3 pt-3 border-t">
                    <div>
                        <label htmlFor={`attachment-${index}`} className="text-xs font-medium text-gray-600 mb-1 block">پیوست فاکتور (تصویر)</label>
                        <input id={`attachment-${index}`} type="file" onChange={onFileChange} accept="image/*" className="w-full text-xs text-gray-500 file:py-1 file:px-2 file:rounded-full file:border-0 file:font-semibold file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100" />
                         {attachmentUrl && (
                           <button type="button" onClick={() => setLightboxSrc(attachmentUrl)} className="text-xs text-blue-600 font-semibold hover:underline mt-1">مشاهده پیوست فعلی</button>
                        )}
                    </div>
                </div>
                {invoiceTotal > 0 && <div className="text-right text-sm font-bold text-green-700 mt-2 pr-4">جمع فاکتور: {formatCurrency(invoiceTotal, currency)}</div>}
                <InvoiceItemsArray invoiceIndex={index} control={control} register={register} currency={currency} />
            </div>
            {lightboxSrc && <ImageLightbox src={lightboxSrc} alt={`پیوست فاکتور ${index + 1}`} onClose={() => setLightboxSrc(null)} />}
        </>
    );
};