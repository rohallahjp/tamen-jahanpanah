import React, { useState, useMemo, useEffect } from 'react';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { useForm, SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Person, PaginatedResponse, createUserCreationSchema, createUserRolesEditSchema, UserPasswordResetSchema } from '../../types';
import { personsApi } from '../../services/api';
import { DataTable, ColumnDef } from '../../components/DataTable';
import Modal from '../../components/Modal';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import { z } from 'zod';
import { useMainLayoutContext } from '../../App';
import { useToast } from '../../hooks/useToast';
import { generateUsernameAndEmail } from '../../utils/formatters';
import { useDebounce } from '../../hooks/useDebounce';

const PETTY_CASH_ROLE_ID = 15;

const ViewUsers: React.FC<{
    onEditUser: (user: Person) => void;
    onEditPassword: (user: Person) => void;
    onDeleteUser: (user: Person) => void;
}> = ({ onEditUser, onEditPassword, onDeleteUser }) => {
    const { update: canUpdate, delete: canDelete } = usePermissions('SECURITY');
    const [page, setPage] = useState(1);
    const [searchQuery, setSearchQuery] = useState('');
    const debouncedSearch = useDebounce(searchQuery, 300);

     const { data: usersResponse, isLoading: isUsersLoading } = useQuery<PaginatedResponse<Person>>({
        queryKey: ['system_users', page, debouncedSearch],
        queryFn: () => personsApi.getAll(page, debouncedSearch, { isSystemUser: true }), 
        placeholderData: (previousData) => previousData,
    });

    useEffect(() => { setPage(1); }, [debouncedSearch]);

    const userColumns: ColumnDef<Person>[] = [
        { accessorKey: 'fullName', header: 'نام کامل' },
        { accessorKey: 'nationalId', header: 'کد ملی' },
        { accessorKey: 'username', header: 'نام کاربری' },
        { accessorKey: 'roleNames', header: 'نقش‌ها', cell: (p) => (p.roleNames || []).join('، ') },
        { accessorKey: 'actions', header: 'عملیات', width: '200px', cell: (user) => (
            <div className="flex justify-center gap-4">
                <button onClick={() => onEditUser(user)} disabled={!canUpdate} className="text-green-600 hover:underline font-semibold disabled:text-gray-400">ویرایش</button>
                <button onClick={() => onEditPassword(user)} disabled={!canUpdate} className="text-blue-600 hover:underline font-semibold disabled:text-gray-400">بازنشانی رمز</button>
                <button onClick={() => onDeleteUser(user)} disabled={!canDelete} className="text-red-600 hover:underline font-semibold disabled:text-gray-400">حذف کاربر</button>
            </div>
        )}
    ];

    return (
        <div className="space-y-4">
            <input
                type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="جستجو بر اساس نام، کد ملی یا نام کاربری..."
                className="w-full p-2 border rounded-md"
            />
            {isUsersLoading ? <p>در حال بارگذاری...</p> : 
                <DataTable 
                    columns={userColumns} 
                    data={usersResponse?.data || []}
                    pagination={{ page, total: usersResponse?.total || 0, itemsPerPage: 20 }}
                    onPageChange={setPage}
                />
            }
        </div>
    );
};

const CreateUser: React.FC = () => {
    const queryClient = useQueryClient();
    const toast = useToast();
    const { roles } = useMainLayoutContext();
    const [isPersonSelectModalOpen, setIsPersonSelectModalOpen] = useState(false);
    const [selectedPerson, setSelectedPerson] = useState<Person | null>(null);
    const UserCreationSchema = useMemo(() => createUserCreationSchema(roles), [roles]);
    type UserCreationFormData = z.infer<typeof UserCreationSchema>;

    const { data: eligiblePersons, isLoading: isEligibleLoading } = useQuery<Person[]>({
        queryKey: ['eligible_persons_for_user_creation'],
        queryFn: () => personsApi.getAllUnpaginated({ hasUnit: true, isSystemUser: false }),
        enabled: isPersonSelectModalOpen,
    });

    const { register, handleSubmit, reset, setValue, watch, formState: { errors } } = useForm<UserCreationFormData>({
        resolver: zodResolver(UserCreationSchema),
    });
    
    const watchedRoleIds = watch('roleIds', []);
    const showPettyCashFields = useMemo(() => Array.isArray(watchedRoleIds) && watchedRoleIds.includes(PETTY_CASH_ROLE_ID), [watchedRoleIds]);


    const userCreationMutation = useMutation({
        mutationFn: (data: { formData: Omit<UserCreationFormData, 'personId'>, person: Person }) => {
            const { person, formData } = data;
            const finalData = { ...person, ...formData, isSystemUser: true };
            return personsApi.update(person.id, finalData);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['system_users'] });
            queryClient.invalidateQueries({ queryKey: ['eligible_persons_for_user_creation'] });
            queryClient.invalidateQueries({ queryKey: ['persons'] });
            setSelectedPerson(null);
            reset();
            toast.success('کاربر با موفقیت ایجاد شد.');
        },
        onError: (err: Error) => toast.error(`خطا: ${err.message}`),
    });

    const handleSelectPerson = (person: Person) => {
        setSelectedPerson(person);
        setValue('personId', person.id, { shouldValidate: true });
        const { username } = generateUsernameAndEmail(person.fullName);
        setValue('username', username);
        setIsPersonSelectModalOpen(false);
    };

    const onSubmit: SubmitHandler<UserCreationFormData> = (data) => {
        if (selectedPerson) {
             userCreationMutation.mutate({ formData: data, person: selectedPerson });
        }
    };

    if (!selectedPerson) {
        return (
            <div className="text-center p-8 border-2 border-dashed rounded-lg">
                <button onClick={() => setIsPersonSelectModalOpen(true)} className="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700">
                    انتخاب شخص برای ایجاد کاربر
                </button>
                {isPersonSelectModalOpen && (
                    <Modal title="انتخاب شخص" onClose={() => setIsPersonSelectModalOpen(false)}>
                        <div className="p-4 max-h-96 overflow-y-auto">
                            {isEligibleLoading && <p>در حال بارگذاری...</p>}
                            {!isEligibleLoading && (!eligiblePersons || eligiblePersons.length === 0) && <p className="text-gray-500">شخص واجد شرایطی یافت نشد (باید دارای سمت باشد و کاربر سیستم نباشد).</p>}
                            <ul className="space-y-1">
                                {(eligiblePersons || []).sort((a,b) => b.id - a.id).map(p => (
                                    <li key={p.id}><button onClick={() => handleSelectPerson(p)} className="w-full text-right p-2 hover:bg-gray-100 rounded">{p.fullName} ({p.nationalId})</button></li>
                                ))}
                            </ul>
                        </div>
                    </Modal>
                )}
            </div>
        );
    }
    
    return (
        <form onSubmit={handleSubmit(onSubmit)} className="p-6 bg-gray-50 border rounded-lg space-y-4">
            <div className="flex justify-between items-start">
                <div>
                    <h3 className="text-lg font-bold">{selectedPerson.fullName}</h3>
                    <p className="text-sm text-gray-600">کد ملی: {selectedPerson.nationalId}</p>
                </div>
                <button type="button" onClick={() => { setSelectedPerson(null); reset(); }} className="text-sm text-red-600 hover:underline">لغو انتخاب</button>
            </div>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div><label className="block text-sm font-medium text-gray-700 mb-1">نام کاربری</label><input {...register('username')} className="w-full border p-2 rounded-md" />{errors.username && <p className="text-red-500 text-xs mt-1">{String(errors.username.message)}</p>}</div>
                <div><label className="block text-sm font-medium text-gray-700 mb-1">رمز عبور</label><input type="password" {...register('password')} className="w-full border p-2 rounded-md" />{errors.password && <p className="text-red-500 text-xs mt-1">{String(errors.password.message)}</p>}</div>
            </div>
             <div className="pt-2"><h3 className="text-md font-semibold text-gray-800 mb-2">نقش‌ها</h3><div className="grid grid-cols-2 md:grid-cols-3 gap-2">{roles.map(role => (<label key={role.id} className="flex items-center gap-2 p-2 bg-white rounded-md border"><input type="checkbox" value={role.id} {...register('roleIds')} />{role.name}</label>))}<br/>{errors.roleIds && <p className="text-red-500 text-xs mt-1 col-span-full">{String(errors.roleIds.message)}</p>}</div></div>
             
             {showPettyCashFields && (
                <div className="p-4 bg-yellow-50 border-l-4 border-yellow-400 space-y-4 rounded-md">
                    <h4 className="font-bold text-yellow-800">اطلاعات تنخواه گردان</h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                         <div><label className="block text-sm font-medium text-gray-700 mb-1">شماره حساب</label><input {...register('accountNumber')} className="w-full border p-2 rounded-md" />{errors.accountNumber && <p className="text-red-500 text-xs mt-1">{String(errors.accountNumber.message)}</p>}</div>
                         <div><label className="block text-sm font-medium text-gray-700 mb-1">شماره شبا (IBAN)</label><input {...register('iban')} className="w-full border p-2 rounded-md" />{errors.iban && <p className="text-red-500 text-xs mt-1">{String(errors.iban.message)}</p>}</div>
                         <div><label className="block text-sm font-medium text-gray-700 mb-1">سقف اعتبار تنخواه</label><input type="number" {...register('pettyCashLimit')} className="w-full border p-2 rounded-md" />{errors.pettyCashLimit && <p className="text-red-500 text-xs mt-1">{String(errors.pettyCashLimit.message)}</p>}</div>
                    </div>
                </div>
             )}

             <div className="flex justify-end gap-2 pt-4 border-t mt-4"><button type="submit" disabled={userCreationMutation.isPending} className="bg-green-500 text-white px-6 py-2 rounded font-semibold disabled:bg-gray-400">ایجاد کاربر</button></div>
        </form>
    );
};


const SecurityPage: React.FC = () => {
    const { read: canRead } = usePermissions('SECURITY');
    const queryClient = useQueryClient();
    const { roles } = useMainLayoutContext();
    const toast = useToast();
    const [activeTab, setActiveTab] = useState<'view' | 'create'>('view');
    const [modalState, setModalState] = useState<{ type: 'password' | 'delete' | 'edit' | null; user: Person | null }>({ type: null, user: null });
    
    const UserRolesEditSchema = useMemo(() => createUserRolesEditSchema(roles), [roles]);
    type UserRolesEditFormData = z.infer<typeof UserRolesEditSchema>;

    const { register: pwdRegister, handleSubmit: handlePwdSubmit, reset: pwdReset, formState: { errors: pwdErrors } } = useForm<z.infer<typeof UserPasswordResetSchema>>({ resolver: zodResolver(UserPasswordResetSchema) });
    const { register: editRegister, handleSubmit: handleEditSubmit, reset: editReset, watch: editWatch, formState: { errors: editErrors } } = useForm<UserRolesEditFormData>({ resolver: zodResolver(UserRolesEditSchema) });
    
    const editWatchedRoleIds = editWatch('roleIds', []);
    const showEditPettyCashFields = useMemo(() => Array.isArray(editWatchedRoleIds) && editWatchedRoleIds.includes(PETTY_CASH_ROLE_ID), [editWatchedRoleIds]);

    useEffect(() => {
        if (modalState.type === 'edit' && modalState.user) {
            editReset({
                roleIds: modalState.user.roleIds || [],
                accountNumber: modalState.user.accountNumber || '',
                iban: modalState.user.iban || '',
                pettyCashLimit: modalState.user.pettyCashLimit || 0,
            });
        }
    }, [modalState, editReset]);

    const editUserMutation = useMutation({
        mutationFn: (data: { formData: UserRolesEditFormData, id: number }) => personsApi.update(data.id, data.formData),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['system_users'] });
            queryClient.invalidateQueries({ queryKey: ['persons'] });
            toast.success("نقش‌های کاربر با موفقیت ویرایش شد.");
            setModalState({ type: null, user: null });
        },
        onError: (err: Error) => toast.error(`خطا: ${err.message}`),
    });

    const passwordMutation = useMutation({
        mutationFn: (data: { userId: number, newPassword: string }) => personsApi.resetPassword(data.userId, data.newPassword),
        onSuccess: () => {
            toast.success("رمز عبور با موفقیت بازنشانی شد.");
            setModalState({ type: null, user: null });
        },
        onError: (err: Error) => toast.error(`خطا: ${err.message}`),
    });

    const deleteUserMutation = useMutation({
        mutationFn: (userId: number) => personsApi.revokeAccess(userId),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['system_users'] });
            queryClient.invalidateQueries({ queryKey: ['eligible_persons_for_user_creation'] });
            toast.success("دسترسی کاربر با موفقیت لغو شد.");
            setModalState({ type: null, user: null });
        },
        onError: (err: Error) => toast.error(`خطا: ${err.message}`),
    });

    const handleOpenModal = (type: 'password' | 'delete' | 'edit', user: Person) => {
        pwdReset({ password: '' });
        setModalState({ type, user });
    };

    const onPasswordSubmit: SubmitHandler<z.infer<typeof UserPasswordResetSchema>> = (data) => {
        if (modalState.user) passwordMutation.mutate({ userId: modalState.user.id, newPassword: data.password });
    };
    
    const onEditSubmit: SubmitHandler<UserRolesEditFormData> = (data) => {
        if (modalState.user) editUserMutation.mutate({ formData: data, id: modalState.user.id });
    };
    
    if (!canRead) return <AccessDenied />;

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-800">مدیریت کاربران و امنیت</h2>
            <div className="border-b border-gray-200">
                <nav className="flex -mb-px gap-6">
                    <button onClick={() => setActiveTab('view')} className={`py-3 px-1 font-semibold text-sm ${activeTab === 'view' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}>مشاهده کاربران</button>
                    <button onClick={() => setActiveTab('create')} className={`py-3 px-1 font-semibold text-sm ${activeTab === 'create' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}>تعریف کاربر جدید</button>
                </nav>
            </div>
            
            {activeTab === 'view' && <ViewUsers onEditUser={(user) => handleOpenModal('edit', user)} onEditPassword={(user) => handleOpenModal('password', user)} onDeleteUser={(user) => handleOpenModal('delete', user)} />}
            {activeTab === 'create' && <CreateUser />}

             {modalState.type === 'edit' && modalState.user && (
                 <Modal title={`ویرایش نقش‌های ${modalState.user.fullName}`} onClose={() => setModalState({ type: null, user: null })} size="2xl">
                    <form onSubmit={handleEditSubmit(onEditSubmit)}>
                        <div className="p-6 space-y-4">
                            <div><h3 className="text-md font-semibold text-gray-800 mb-2">نقش‌ها</h3><div className="grid grid-cols-2 md:grid-cols-3 gap-2">{roles.map(role => (<label key={role.id} className="flex items-center gap-2 p-2 bg-white rounded-md border"><input type="checkbox" value={role.id} {...editRegister('roleIds')} />{role.name}</label>))}<br/>{editErrors.roleIds && <p className="text-red-500 text-xs mt-1 col-span-full">{String(editErrors.roleIds.message)}</p>}</div></div>
                            {showEditPettyCashFields && (
                                <div className="p-4 bg-yellow-50 border-l-4 border-yellow-400 space-y-4 rounded-md">
                                    <h4 className="font-bold text-yellow-800">اطلاعات تنخواه گردان</h4>
                                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                        <div><label className="block text-sm font-medium text-gray-700 mb-1">شماره حساب</label><input {...editRegister('accountNumber')} className="w-full border p-2 rounded-md" />{editErrors.accountNumber && <p className="text-red-500 text-xs mt-1">{String(editErrors.accountNumber.message)}</p>}</div>
                                        <div><label className="block text-sm font-medium text-gray-700 mb-1">شماره شبا (IBAN)</label><input {...editRegister('iban')} className="w-full border p-2 rounded-md" />{editErrors.iban && <p className="text-red-500 text-xs mt-1">{String(editErrors.iban.message)}</p>}</div>
                                        <div><label className="block text-sm font-medium text-gray-700 mb-1">سقف اعتبار تنخواه</label><input type="number" {...editRegister('pettyCashLimit')} className="w-full border p-2 rounded-md" />{editErrors.pettyCashLimit && <p className="text-red-500 text-xs mt-1">{String(editErrors.pettyCashLimit.message)}</p>}</div>
                                    </div>
                                </div>
                            )}
                        </div>
                        <div className="flex justify-end gap-2 p-4 border-t mt-4"><button type="button" onClick={() => setModalState({ type: null, user: null })} className="bg-gray-200 px-4 py-2 rounded font-semibold">لغو</button><button type="submit" disabled={editUserMutation.isPending} className="bg-green-500 text-white px-4 py-2 rounded disabled:bg-gray-400 font-semibold">ذخیره</button></div>
                    </form>
                </Modal>
            )}
            
            {modalState.type === 'password' && modalState.user && (
                 <Modal title={`بازنشانی رمز عبور برای ${modalState.user.fullName}`} onClose={() => setModalState({ type: null, user: null })}>
                    <form onSubmit={handlePwdSubmit(onPasswordSubmit)} className="p-6 space-y-4">
                        <div><label className="block text-sm font-medium text-gray-700 mb-1">رمز عبور جدید</label><input type="password" {...pwdRegister('password')} className="w-full border p-2 rounded-md" />{pwdErrors.password && <p className="text-red-500 text-xs mt-1">{String(pwdErrors.password.message)}</p>}</div>
                        <div className="flex justify-end gap-2 pt-4 border-t mt-4"><button type="button" onClick={() => setModalState({ type: null, user: null })} className="bg-gray-200 px-4 py-2 rounded font-semibold">لغو</button><button type="submit" disabled={passwordMutation.isPending} className="bg-green-500 text-white px-4 py-2 rounded disabled:bg-gray-400 font-semibold">ذخیره</button></div>
                    </form>
                </Modal>
            )}
            
            {modalState.type === 'delete' && modalState.user && (
                <Modal title={`حذف کاربر ${modalState.user.fullName}`} onClose={() => setModalState({ type: null, user: null })}>
                    <div className="p-6 space-y-4">
                        <p>آیا از حذف دسترسی کاربر <span className="font-bold">{modalState.user.fullName}</span> مطمئن هستید؟</p>
                        <p className="text-sm text-gray-600">این عمل نام کاربری و رمز عبور شخص را حذف کرده و او دیگر قادر به ورود به سیستم نخواهد بود، اما اطلاعات شخص در سیستم باقی خواهد ماند.</p>
                         <div className="flex justify-end gap-2 pt-4 border-t mt-4"><button type="button" onClick={() => setModalState({ type: null, user: null })} className="bg-gray-200 px-4 py-2 rounded font-semibold">انصراف</button><button onClick={() => deleteUserMutation.mutate(modalState.user!.id)} disabled={deleteUserMutation.isPending} className="bg-red-600 text-white px-4 py-2 rounded disabled:bg-gray-400 font-semibold">تایید و حذف کاربر</button></div>
                    </div>
                </Modal>
            )}
        </div>
    );
};

export default SecurityPage;