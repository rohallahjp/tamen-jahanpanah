import React from 'react';
import { useForm, SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation } from '@tanstack/react-query';
import { z } from 'zod';
import { ChangePasswordSchema } from '../../types';
import { personsApi } from '../../services/api';
import { useAuth } from '../../hooks/useAuth';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import { useToast } from '../../hooks/useToast';

type FormData = z.infer<typeof ChangePasswordSchema>;

const ChangePasswordPage: React.FC = () => {
    const { currentUser } = useAuth();
    const { read: canRead, update: canUpdate } = usePermissions('PROFILE');
    const { register, handleSubmit, reset, formState: { errors } } = useForm<FormData>({ resolver: zodResolver(ChangePasswordSchema) });
    const toast = useToast();

    const mutation = useMutation({
        mutationFn: (data: FormData) => {
            if (!currentUser) throw new Error("کاربر شناسایی نشد.");
            return personsApi.changePassword(currentUser.id, data.currentPassword, data.newPassword);
        },
        onSuccess: () => { 
            toast.success("گذرواژه با موفقیت تغییر کرد."); 
            reset(); 
        },
        onError: (error: Error) => toast.error(`خطا در تغییر گذرواژه: ${error.message}`)
    });

    const onSubmit: SubmitHandler<FormData> = (data) => mutation.mutate(data);

    if (!canRead) return <AccessDenied />;

    return (
        <section className="max-w-xl mx-auto">
            <div className="bg-white p-8 rounded-lg shadow-md">
                <h2 className="text-2xl font-bold text-gray-800 mb-6">تغییر گذرواژه</h2>
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">گذرواژه فعلی</label><input type="password" {...register("currentPassword")} className="w-full border p-2 rounded-md" />{errors.currentPassword && <p className="text-red-500 text-xs mt-1">{errors.currentPassword.message as string}</p>}</div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">گذرواژه جدید</label><input type="password" {...register("newPassword")} className="w-full border p-2 rounded-md" />{errors.newPassword && <p className="text-red-500 text-xs mt-1">{errors.newPassword.message as string}</p>}</div>
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">تکرار گذرواژه جدید</label><input type="password" {...register("confirmPassword")} className="w-full border p-2 rounded-md" />{errors.confirmPassword && <p className="text-red-500 text-xs mt-1">{errors.confirmPassword.message as string}</p>}</div>
                    {/* FIX: Replaced isPending with isPending for TanStack Query v5 compatibility. */}
                    <div className="flex justify-end pt-4 border-t"><button type="submit" disabled={mutation.isPending || !canUpdate} className="bg-blue-600 text-white px-6 py-2 rounded-md font-semibold hover:bg-blue-700 disabled:bg-gray-400">{mutation.isPending ? 'در حال ذخیره...' : 'ذخیره تغییرات'}</button></div>
                </form>
            </div>
        </section>
    );
};

export default ChangePasswordPage;