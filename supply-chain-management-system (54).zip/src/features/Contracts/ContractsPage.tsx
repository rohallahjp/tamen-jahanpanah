import React, { useState, useEffect, useMemo } from 'react';
// FIX: Removed `keepPreviousData` from import as it is not exported.
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { contractsApi, personsApi } from '../../services/api';
import { Contract, ContractData, Person, PaginatedResponse } from '../../types';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import { DataTable, ColumnDef } from '../../components/DataTable';
import { useDebounce } from '../../hooks/useDebounce';
import { useToast } from '../../hooks/useToast';
import { formatCurrency } from '../../utils/formatters';
import ContractForm from './ContractForm';

const ContractsPage: React.FC = () => {
    const { read: canRead, create: canCreate, update: canUpdate, delete: canDelete } = usePermissions('CONTRACTS');
    const queryClient = useQueryClient();
    const [page, setPage] = useState(1);
    const [searchQuery, setSearchQuery] = useState('');
    const debouncedSearch = useDebounce(searchQuery, 300);
    const toast = useToast();
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingContract, setEditingContract] = useState<Contract | null>(null);
    
    const { data: contractsResponse, isLoading: isContractsLoading } = useQuery<PaginatedResponse<Contract>>({
        queryKey: ['contracts', page, debouncedSearch],
        queryFn: () => contractsApi.getAll(page, debouncedSearch),
        // FIX: Replaced `keepPreviousData` with an inline function to preserve functionality.
        placeholderData: (previousData) => previousData,
    });
    
    const { data: persons, isLoading: isPersonsLoading } = useQuery<Person[]>({
        queryKey: ['persons_all_beneficiaries'],
        queryFn: () => personsApi.getAllUnpaginated({ isBeneficiary: true }),
    });
    
    useEffect(() => { setPage(1); }, [debouncedSearch]);
    
    const deleteMutation = useMutation({
        mutationFn: (id: number) => contractsApi.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['contracts'] });
            toast.success('قرارداد با موفقیت حذف شد.');
        },
        onError: (error: Error) => toast.error(`حذف با خطا مواجه شد: ${error.message}`),
    });
    
    const handleOpenModal = (contract: Contract | null = null) => {
        setEditingContract(contract);
        setIsModalOpen(true);
    };
    
    const handleDelete = (id: number) => {
        if (window.confirm('آیا از حذف این قرارداد مطمئن هستید؟')) {
            deleteMutation.mutate(id);
        }
    };
    
    const getStatusBadge = (status: Contract['status']) => {
        const statusMap = {
            'DRAFT': { text: 'پیش‌نویس', color: 'gray' },
            'ACTIVE': { text: 'فعال', color: 'green' },
            'COMPLETED': { text: 'تکمیل شده', color: 'blue' },
            'TERMINATED': { text: 'خاتمه یافته', color: 'red' },
        };
        const s = statusMap[status];
        return <span className={`bg-${s.color}-100 text-${s.color}-800 text-xs font-medium px-2.5 py-0.5 rounded-full`}>{s.text}</span>;
    };
    
    const columns: ColumnDef<Contract>[] = [
        { accessorKey: 'contractNumber', header: 'شماره قرارداد' },
        { accessorKey: 'title', header: 'عنوان' },
        { accessorKey: 'partyName', header: 'طرف قرارداد' },
        { accessorKey: 'totalAmount', header: 'مبلغ کل', cell: (c) => formatCurrency(c.totalAmount, 'RIAL') },
        { accessorKey: 'paidAmount', header: 'مبلغ پرداخت شده', cell: (c) => formatCurrency(c.paidAmount, 'RIAL') },
        { accessorKey: 'status', header: 'وضعیت', cell: (c) => getStatusBadge(c.status) },
        { accessorKey: 'actions', header: 'عملیات', width: '120px', cell: (contract) => (
            <div className="flex justify-center gap-4">
                <button onClick={() => handleOpenModal(contract)} disabled={!canUpdate} className="text-blue-600 hover:underline font-semibold disabled:text-gray-400">ویرایش</button>
                <button onClick={() => handleDelete(contract.id)} disabled={!canDelete} className="text-red-600 hover:underline font-semibold disabled:text-gray-400">حذف</button>
            </div>
        )},
    ];
    
    if (!canRead) return <AccessDenied />;
    
    return (
        <section className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-800">مدیریت قراردادها</h2>
                {canCreate && <button onClick={() => handleOpenModal()} className="bg-blue-600 text-white px-5 py-2 rounded-lg font-semibold hover:bg-blue-700 shadow-md flex items-center gap-2">افزودن قرارداد جدید</button>}
            </div>
            
            <div className="relative">
                <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="جستجو بر اساس شماره، عنوان یا طرف قرارداد..."
                    className="w-full p-2 pl-10 border rounded-md"
                />
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
            </div>
            
            {isContractsLoading ? <p>در حال بارگذاری قراردادها...</p> :
                <DataTable
                    columns={columns}
                    data={contractsResponse?.data || []}
                    pagination={{ page, total: contractsResponse?.total || 0, itemsPerPage: 20 }}
                    onPageChange={setPage}
                />
            }
            
            {isModalOpen && (
                <ContractForm
                    contract={editingContract}
                    persons={persons || []}
                    onClose={() => setIsModalOpen(false)}
                />
            )}
        </section>
    );
};

export default ContractsPage;