import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '../../hooks/useAuth';
import { expenseReportsApi, personsApi } from '../../services/api';
import { ExpenseReport, Person } from '../../types';
import { DataTable, ColumnDef } from '../../components/DataTable';
import { formatCurrency } from '../../utils/formatters';
import ExpenseReportForm from './ExpenseReportForm';
import { useToast } from '../../hooks/useToast';

const PettyCashPage: React.FC = () => {
    const { currentUser } = useAuth();
    const queryClient = useQueryClient();
    const [page, setPage] = useState(1);
    const [isFormOpen, setIsFormOpen] = useState(false);
    const toast = useToast();

    // Fetch the detailed info for the current user to get their credit status
    const { data: userDetails, isLoading: isUserLoading } = useQuery<Person | undefined>({
        queryKey: ['person_details', currentUser?.id],
        queryFn: () => personsApi.getAllUnpaginated().then(allPersons => allPersons.find(p => p.id === currentUser!.id)),
        enabled: !!currentUser,
    });
    
    // Fetch expense reports for the current user
    const { data: reportsResponse, isLoading: isReportsLoading } = useQuery({
        queryKey: ['expenseReports', page, currentUser?.id],
        queryFn: () => expenseReportsApi.getAll(page, undefined, { pettyCashHolderId: String(currentUser!.id) }),
        enabled: !!currentUser,
    });
    
    const getStatusBadge = (status: ExpenseReport['status']) => {
        const statusMap = { 'IN_REVIEW': { text: 'در حال بررسی', color: 'blue' }, 'APPROVED': { text: 'تایید شده', color: 'green' }, 'REJECTED': { text: 'رد شده', color: 'red' } };
        const s = statusMap[status] || { text: status, color: 'gray' };
        return <span className={`bg-${s.color}-100 text-${s.color}-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full`}>{s.text}</span>;
    };
    
    const columns: ColumnDef<ExpenseReport>[] = [
        { accessorKey: 'id', header: 'شماره گزارش' },
        { accessorKey: 'submissionDate', header: 'تاریخ ثبت', cell: (r) => new Date(r.submissionDate).toLocaleDateString('fa-IR') },
        { accessorKey: 'totalAmount', header: 'مبلغ کل', cell: (r) => formatCurrency(r.totalAmount, 'RIAL') },
        { accessorKey: 'status', header: 'وضعیت', cell: (r) => getStatusBadge(r.status) },
        { accessorKey: 'finalApprovalDate', header: 'تاریخ تایید نهایی', cell: (r) => r.finalApprovalDate ? new Date(r.finalApprovalDate).toLocaleDateString('fa-IR') : '---' },
    ];
    
    const handleFormSuccess = () => {
        setIsFormOpen(false);
        toast.success('گزارش هزینه با موفقیت ثبت شد و برای تایید ارسال گردید.');
        queryClient.invalidateQueries({ queryKey: ['expenseReports'] });
    };

    if (isUserLoading) {
        return <div className="flex justify-center items-center h-full"><div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div></div>;
    }

    return (
        <div className="space-y-6">
             <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-800">مدیریت تنخواه من</h2>
                <button onClick={() => setIsFormOpen(true)} className="bg-green-600 text-white px-5 py-2 rounded-lg font-semibold flex items-center gap-2 hover:bg-green-700 shadow-md">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M6 2a2 2 0 00-2 2v12a2 2 0 002 2h8a2 2 0 002-2V4a2 2 0 00-2-2H6zm1 2a1 1 0 000 2h6a1 1 0 100-2H7zm6 4a1 1 0 011 1v3a1 1 0 11-2 0v-3a1 1 0 011-1zm-3 0a1 1 0 011 1v3a1 1 0 11-2 0v-3a1 1 0 011-1zm-3 0a1 1 0 011 1v3a1 1 0 11-2 0v-3a1 1 0 011-1z" clipRule="evenodd" /></svg>
                    ثبت گزارش هزینه جدید
                </button>
            </div>

             <div>
                <h3 className="text-xl font-bold text-gray-800 mb-4">تاریخچه گزارشات هزینه من</h3>
                {isReportsLoading ? <p>در حال بارگذاری گزارشات...</p> :
                    <DataTable
                        columns={columns}
                        data={reportsResponse?.data || []}
                        pagination={{ page, total: reportsResponse?.total || 0, itemsPerPage: 20 }}
                        onPageChange={setPage}
                    />
                }
             </div>
             
             {isFormOpen && currentUser && (
                <ExpenseReportForm
                    onClose={() => setIsFormOpen(false)}
                    onSuccess={handleFormSuccess}
                    pettyCashHolderId={currentUser.id}
                />
             )}
        </div>
    );
};

export default PettyCashPage;