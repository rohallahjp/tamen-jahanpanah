import React from 'react';
import { useForm, useFieldArray, SubmitHandler, useWatch } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation } from '@tanstack/react-query';
import { z } from 'zod';
import { ExpenseReportData, ExpenseReportSchema } from '../../types';
import { expenseReportsApi } from '../../services/api';
import Modal from '../../components/Modal';
import { formatCurrency } from '../../utils/formatters';
import { useToast } from '../../hooks/useToast';

type FormData = z.infer<typeof ExpenseReportSchema>;

interface ExpenseReportFormProps {
    onClose: () => void;
    onSuccess: () => void;
    pettyCashHolderId: number;
}

const fileToBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
});

const ExpenseReportForm: React.FC<ExpenseReportFormProps> = ({ onClose, onSuccess, pettyCashHolderId }) => {
    const toast = useToast();
    const { register, handleSubmit, control, setValue, formState: { errors } } = useForm<FormData>({
        resolver: zodResolver(ExpenseReportSchema),
        defaultValues: {
            pettyCashHolderId,
            items: [{ description: '', amount: 0 }],
            totalAmount: 0,
        }
    });

    const { fields, append, remove } = useFieldArray({ control, name: "items" });
    const watchedItems = useWatch({ control, name: "items" });

    const totalAmount = React.useMemo(() => {
        const total = watchedItems.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
        setValue('totalAmount', total);
        return total;
    }, [watchedItems, setValue]);

    const mutation = useMutation({
        mutationFn: (data: ExpenseReportData) => expenseReportsApi.create(data),
        onSuccess,
        onError: (error: Error) => toast.error(`خطا در ثبت گزارش: ${error.message}`),
    });

    const onSubmit: SubmitHandler<FormData> = (data) => mutation.mutate(data);

    const handleAttachmentChange = async (e: React.ChangeEvent<HTMLInputElement>, index: number) => {
        const file = e.target.files?.[0];
        if (file) {
            try {
                const url = await fileToBase64(file);
                setValue(`items.${index}.attachmentName`, file.name, { shouldValidate: true });
                setValue(`items.${index}.attachmentUrl`, url, { shouldValidate: true });
            } catch {
                toast.error("خطا در پردازش فایل پیوست.");
            }
        }
    };

    return (
        <Modal title="ثبت گزارش هزینه تنخواه" onClose={onClose} size="3xl">
            <form onSubmit={handleSubmit(onSubmit)}>
                <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
                    {fields.map((field, index) => (
                        <div key={field.id} className="p-3 border rounded-lg bg-gray-50 grid grid-cols-1 md:grid-cols-[1fr_150px_1fr_auto] gap-3 items-end">
                            <div className="w-full">
                                <label className="text-xs font-medium">شرح هزینه</label>
                                <input {...register(`items.${index}.description`)} className="w-full border p-2 rounded-md" />
                                {errors.items?.[index]?.description && <p className="text-red-500 text-xs mt-1">{errors.items[index]?.description?.message}</p>}
                            </div>
                            <div className="w-full">
                                <label className="text-xs font-medium">مبلغ (ریال)</label>
                                <input type="number" {...register(`items.${index}.amount`, { valueAsNumber: true })} className="w-full border p-2 rounded-md" />
                                {errors.items?.[index]?.amount && <p className="text-red-500 text-xs mt-1">{errors.items[index]?.amount?.message}</p>}
                            </div>
                            <div className="w-full">
                                <label className="text-xs font-medium">پیوست (اختیاری)</label>
                                <input type="file" onChange={e => handleAttachmentChange(e, index)} className="w-full text-xs text-gray-500 file:py-1 file:px-2 file:rounded-full file:border-0 file:font-semibold file:bg-violet-50 file:text-violet-700 hover:file:bg-violet-100" />
                            </div>
                            <button type="button" onClick={() => remove(index)} className="bg-red-100 text-red-700 h-9 w-9 flex items-center justify-center rounded-md hover:bg-red-200 font-bold text-xl">&times;</button>
                        </div>
                    ))}
                     <button type="button" onClick={() => append({ description: '', amount: 0 })} className="text-sm text-blue-600 font-semibold hover:underline">+ افزودن هزینه</button>
                     {errors.items && typeof errors.items.message === 'string' && <p className="text-red-500 text-xs mt-1">{errors.items.message}</p>}
                </div>

                <div className="flex justify-between items-center p-4 border-t bg-gray-50">
                    <div className="text-lg font-bold text-gray-800">
                        مبلغ کل گزارش: <span className="font-mono text-blue-600">{formatCurrency(totalAmount, 'RIAL')}</span>
                    </div>
                    <div className="flex gap-2">
                        <button type="button" onClick={onClose} className="bg-gray-200 text-gray-800 px-4 py-2 rounded font-semibold">انصراف</button>
                        <button type="submit" disabled={mutation.isPending} className="bg-green-600 text-white px-4 py-2 rounded disabled:bg-gray-400 font-semibold">
                            {mutation.isPending ? 'در حال ثبت...' : 'ثبت و ارسال برای تایید'}
                        </button>
                    </div>
                </div>
            </form>
        </Modal>
    );
};

export default ExpenseReportForm;
