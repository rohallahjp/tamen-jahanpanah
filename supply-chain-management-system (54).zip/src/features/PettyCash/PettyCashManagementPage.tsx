import React, { useState, useEffect, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { personsApi, expenseReportsApi } from '../../services/api';
import { Person, ExpenseReport, PaginatedResponse } from '../../types';
import AccessDenied from '../../components/AccessDenied';
import { DataTable, ColumnDef } from '../../components/DataTable';
import { useDebounce } from '../../hooks/useDebounce';
import { useToast } from '../../hooks/useToast';
import { formatCurrency } from '../../utils/formatters';
import Modal from '../../components/Modal';
import { useAuth } from '../../hooks/useAuth';

const PETTY_CASH_ROLE_ID = 15;

const PettyCashManagementPage: React.FC = () => {
    const { currentUser } = useAuth();
    const userPermissions = useMemo(() => new Set(currentUser?.permissions || []), [currentUser]);
    
    const canReadAll = userPermissions.has('PETTY_CASH_MANAGEMENT:read_all');
    const canReadOwn = userPermissions.has('PETTY_CASH_MANAGEMENT:read_own_unit');
    const canUpdate = userPermissions.has('PETTY_CASH_MANAGEMENT:update');

    const queryClient = useQueryClient();
    const [page, setPage] = useState(1);
    const [searchQuery, setSearchQuery] = useState('');
    const debouncedSearch = useDebounce(searchQuery, 300);
    const toast = useToast();
    const [isLimitModalOpen, setIsLimitModalOpen] = useState(false);
    const [isReportsModalOpen, setIsReportsModalOpen] = useState(false);
    const [selectedPerson, setSelectedPerson] = useState<Person | null>(null);
    const [newLimit, setNewLimit] = useState(0);

    const { data: personsResponse, isLoading: isPersonsLoading } = useQuery<PaginatedResponse<Person>>({
        queryKey: ['persons_petty_cash_holders', page, debouncedSearch, currentUser?.id],
        queryFn: () => personsApi.getAll(page, debouncedSearch, { 
            roleId: PETTY_CASH_ROLE_ID, 
            actingUserId: currentUser!.id 
        }),
        enabled: !!currentUser && (canReadAll || canReadOwn),
    });
    
    const { data: pendingReports, isLoading: isReportsLoading } = useQuery<PaginatedResponse<ExpenseReport>>({
        queryKey: ['expense_reports_pending'],
        queryFn: () => expenseReportsApi.getAll(1, '', { status: 'IN_REVIEW' }),
        enabled: canUpdate, // Only fetch for users who can approve
    });

    useEffect(() => { setPage(1); }, [debouncedSearch]);

    const limitMutation = useMutation({
        mutationFn: (data: { personId: number; limit: number }) => 
            personsApi.update(data.personId, { 
                pettyCashLimit: data.limit, 
                pettyCashBalance: data.limit,
                actingUserId: currentUser!.id,
            }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['persons_petty_cash_holders'] });
            setIsLimitModalOpen(false);
            toast.success('سقف اعتبار با موفقیت به‌روزرسانی شد.');
        },
        onError: (error: Error) => toast.error(`خطا: ${error.message}`),
    });
    
    const approveReportMutation = useMutation({
        mutationFn: (reportId: number) => expenseReportsApi.approve({ reportId, actingUserId: currentUser!.id }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['expense_reports_pending'] });
            queryClient.invalidateQueries({ queryKey: ['persons_petty_cash_holders'] });
            toast.success('گزارش هزینه تایید و اعتبار شخص شارژ شد.');
        },
        onError: (error: Error) => toast.error(`خطا در تایید گزارش: ${error.message}`),
    });

    const handleOpenLimitModal = (person: Person) => {
        setSelectedPerson(person);
        setNewLimit(person.pettyCashLimit || 0);
        setIsLimitModalOpen(true);
    };
    
    const handleSetLimit = () => {
        if (selectedPerson) {
            limitMutation.mutate({ personId: selectedPerson.id, limit: newLimit });
        }
    };

    const handleApproveReport = (reportId: number) => {
        if (window.confirm('آیا از تایید این گزارش هزینه و بازگرداندن مبلغ به اعتبار تنخواه فرد مطمئن هستید؟')) {
            approveReportMutation.mutate(reportId);
        }
    };

    const columns: ColumnDef<Person>[] = [
        { accessorKey: 'fullName', header: 'نام تنخواه بگیر' },
        { accessorKey: 'unitName', header: 'واحد خدمتی' },
        { accessorKey: 'pettyCashLimit', header: 'سقف اعتبار', cell: (p) => formatCurrency(p.pettyCashLimit, 'RIAL') },
        { accessorKey: 'pettyCashBalance', header: 'موجودی باقیمانده', cell: (p) => formatCurrency(p.pettyCashBalance, 'RIAL') },
        { accessorKey: 'actions', header: 'عملیات', width: '150px', cell: (person) => (
            <div className="flex justify-center">
                <button onClick={() => handleOpenLimitModal(person)} disabled={!canUpdate} className="text-blue-600 hover:underline font-semibold disabled:text-gray-400">تخصیص اعتبار</button>
            </div>
        )},
    ];
    
    if (!canReadAll && !canReadOwn) return <AccessDenied />;

    return (
        <section className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-800">مدیریت تنخواه</h2>
                {canUpdate && (
                     <button onClick={() => setIsReportsModalOpen(true)} className="relative bg-yellow-500 text-white px-5 py-2 rounded-lg font-semibold hover:bg-yellow-600 shadow-md flex items-center gap-2">
                        بررسی گزارشات هزینه
                        {pendingReports && pendingReports.total > 0 && (
                            <span className="absolute -top-2 -right-2 bg-red-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                                {pendingReports.total}
                            </span>
                        )}
                    </button>
                )}
            </div>
            
            <div className="relative">
                <input
                    type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="جستجو بر اساس نام تنخواه بگیر..."
                    className="w-full p-2 pl-10 border rounded-md"
                />
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
            </div>
            
            {isPersonsLoading ? <p>در حال بارگذاری...</p> :
                <DataTable
                    columns={columns}
                    data={personsResponse?.data || []}
                    pagination={{ page, total: personsResponse?.total || 0, itemsPerPage: 20 }}
                    onPageChange={setPage}
                />
            }
            
            {isLimitModalOpen && selectedPerson && (
                <Modal title={`تخصیص اعتبار برای ${selectedPerson.fullName}`} onClose={() => setIsLimitModalOpen(false)} size="sm">
                    <div className="p-6 space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">سقف اعتبار جدید (ریال)</label>
                            <input type="number" value={newLimit} onChange={(e) => setNewLimit(Number(e.target.value))} className="w-full border p-2 rounded" />
                        </div>
                        <p className="text-xs text-gray-500">توجه: با تخصیص سقف جدید، موجودی فعلی فرد نیز به این مبلغ بازنشانی خواهد شد.</p>
                    </div>
                    <div className="flex justify-end gap-2 p-4 bg-gray-50 border-t">
                        <button type="button" onClick={() => setIsLimitModalOpen(false)} className="bg-gray-200 px-4 py-2 rounded font-semibold">لغو</button>
                        <button onClick={handleSetLimit} disabled={limitMutation.isPending} className="bg-green-500 text-white px-4 py-2 rounded disabled:bg-gray-400 font-semibold">ذخیره</button>
                    </div>
                </Modal>
            )}

            {isReportsModalOpen && (
                <Modal title="بررسی گزارشات هزینه" onClose={() => setIsReportsModalOpen(false)} size="3xl">
                    <div className="p-6 max-h-[70vh] overflow-y-auto">
                        {isReportsLoading ? <p>در حال بارگذاری گزارشات...</p> : 
                            pendingReports && pendingReports.total > 0 ? (
                                <div className="space-y-3">
                                    {pendingReports.data.map(report => (
                                        <div key={report.id} className="p-3 border rounded-lg bg-gray-50 flex justify-between items-center">
                                            <div>
                                                <p className="font-semibold">{report.pettyCashHolderName}</p>
                                                <p className="text-sm text-gray-600">مبلغ کل: {formatCurrency(report.totalAmount, 'RIAL')}</p>
                                                <p className="text-xs text-gray-500">تاریخ ثبت: {new Date(report.submissionDate).toLocaleDateString('fa-IR')}</p>
                                            </div>
                                            <button onClick={() => handleApproveReport(report.id)} disabled={approveReportMutation.isPending} className="bg-green-600 text-white px-4 py-1.5 rounded text-sm font-semibold disabled:bg-gray-400">تایید گزارش</button>
                                        </div>
                                    ))}
                                </div>
                            ) : <p className="text-center text-gray-500 py-8">هیچ گزارش هزینه‌ای در انتظار تایید وجود ندارد.</p>
                        }
                    </div>
                </Modal>
            )}
        </section>
    );
};

export default PettyCashManagementPage;