import React, { useState, useEffect } from 'react';
import { useForm, SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
// FIX: Removed `keepPreviousData` from import as it is not exported.
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { Role, RoleData, RoleSchema, PaginatedResponse, Person } from '../../types';
import { rolesApi, personsApi } from '../../services/api';
import Modal from '../../components/Modal';
import { DataTable, ColumnDef } from '../../components/DataTable';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import { ALL_PERMISSIONS_LIST, PERMISSION_MAP, PERMISSIONS } from '../../constants/resources';
import { useToast } from '../../hooks/useToast';
import { useDebounce } from '../../hooks/useDebounce';

type FormData = RoleData;

const RolesPage: React.FC = () => {
    const { read: canRead, create: canCreate, update: canUpdate, delete: canDelete } = usePermissions('ROLES');
    const queryClient = useQueryClient();
    const toast = useToast();
    const [page, setPage] = useState(1);
    const [searchQuery, setSearchQuery] = useState('');
    const debouncedSearch = useDebounce(searchQuery, 300);

    const { data: rolesResponse, isLoading: isRolesLoading } = useQuery<PaginatedResponse<Role>>({
        queryKey: ['roles', page, debouncedSearch],
        queryFn: () => rolesApi.getAll(page, debouncedSearch),
        // FIX: Replaced `keepPreviousData` with an inline function to preserve functionality.
        placeholderData: (previousData) => previousData,
    });
    
    const { data: persons, isLoading: isPersonsLoading } = useQuery<Person[]>({
        queryKey: ['persons_all'],
        queryFn: () => personsApi.getAllUnpaginated(),
    });

    const roles = rolesResponse?.data || [];
    
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [viewingUsersOfRole, setViewingUsersOfRole] = useState<Role | null>(null);
    const [selectedRole, setSelectedRole] = useState<Role | null>(null);
    const [activeTab, setActiveTab] = useState<'details' | 'permissions'>('details');
    const [currentPermissions, setCurrentPermissions] = useState<Set<string>>(new Set());

    const { register, handleSubmit, reset, formState: { errors } } = useForm<FormData>({ resolver: zodResolver(RoleSchema) });

    useEffect(() => {
        setPage(1);
    }, [debouncedSearch]);
    
    useEffect(() => {
        if (isModalOpen) {
            if (selectedRole) {
                reset({ name: selectedRole.name, description: selectedRole.description });
                setCurrentPermissions(new Set(selectedRole.permissions));
            } else {
                reset({ name: '', description: '' });
                setCurrentPermissions(new Set());
            }
            setActiveTab('details');
        }
    }, [selectedRole, isModalOpen, reset]);

    const mutation = useMutation({
        mutationFn: (data: { formData: RoleData, permissions: string[], id?: number }) => {
            const rolePayload: Partial<Role> = { ...data.formData, permissions: Array.from(data.permissions) };
            return data.id ? rolesApi.update(data.id, rolePayload) : rolesApi.create({ ...data.formData, permissions: Array.from(data.permissions) });
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['roles'] });
            queryClient.invalidateQueries({ queryKey: ['persons'] });
            queryClient.invalidateQueries({ queryKey: ['roles_all']});
            setIsModalOpen(false);
            toast.success('نقش با موفقیت ذخیره شد.');
        },
        onError: (err: Error) => toast.error(`خطا: ${err.message}`),
    });

    const deleteMutation = useMutation({
        mutationFn: (id: number) => rolesApi.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['roles'] });
            queryClient.invalidateQueries({ queryKey: ['roles_all']});
            toast.success('نقش با موفقیت حذف شد.');
        },
        onError: (err: Error) => toast.error(`خطا در حذف: ${err.message}`),
    });
    
    const handlePermissionChange = (permission: string, checked: boolean) => {
        const newPermissions = new Set(currentPermissions);
        if (checked) newPermissions.add(permission); else newPermissions.delete(permission);
        setCurrentPermissions(newPermissions);
    };

    const onSubmit: SubmitHandler<FormData> = (data) => mutation.mutate({ formData: data, permissions: Array.from(currentPermissions), id: selectedRole?.id });
    const handleDelete = (id: number) => { if (window.confirm('آیا از حذف این نقش مطمئن هستید؟')) deleteMutation.mutate(id); };
    const openModalToCreate = () => { setSelectedRole(null); setIsModalOpen(true); };
    const openModalToEdit = (role: Role) => { setSelectedRole(role); setIsModalOpen(true); };

    const columns: ColumnDef<Role>[] = [
        { accessorKey: 'name', header: 'عنوان نقش' },
        { accessorKey: 'description', header: 'توضیحات' },
        { accessorKey: 'actions', header: 'عملیات', width: '150px', cell: (role) => (
            <div className="flex flex-col items-center gap-1.5 text-xs"><button onClick={() => setViewingUsersOfRole(role)} className="text-gray-600 font-semibold hover:underline">صاحبان نقش</button><button onClick={() => openModalToEdit(role)} disabled={!canUpdate} className="text-blue-600 font-semibold hover:underline disabled:text-gray-400 disabled:no-underline">ویرایش</button><button onClick={() => handleDelete(role.id)} disabled={!canDelete} className="text-red-600 font-semibold hover:underline disabled:text-gray-400 disabled:no-underline">حذف</button></div>
        )},
    ];

    const usersWithRole = viewingUsersOfRole ? (persons || []).filter(p => p.roleIds?.includes(viewingUsersOfRole.id)) : [];
    if (!canRead) return <AccessDenied />;

    const isLoading = isRolesLoading || isPersonsLoading;

    return (
        <section className="space-y-6">
            <div className="flex justify-between items-center"><h2 className="text-2xl font-bold text-gray-800">مدیریت نقش‌ها و دسترسی‌ها</h2><button onClick={openModalToCreate} disabled={!canCreate} className="bg-blue-600 text-white px-5 py-2 rounded-lg font-semibold flex items-center gap-2 hover:bg-blue-700 disabled:bg-gray-400">افزودن نقش جدید</button></div>
            
             <div className="relative">
                <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="جستجو بر اساس عنوان یا توضیحات..."
                    className="w-full p-2 pl-10 border rounded-md"
                />
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
            </div>
            
            {isLoading ? <p>در حال بارگذاری...</p> : 
                <DataTable 
                    columns={columns} 
                    data={roles}
                    pagination={{ page, total: rolesResponse?.total || 0, itemsPerPage: 20 }}
                    onPageChange={setPage}
                />
            }
            {viewingUsersOfRole && <Modal title={`کاربران با نقش: ${viewingUsersOfRole.name}`} onClose={() => setViewingUsersOfRole(null)} size="md"><div className="p-4">{usersWithRole.length > 0 ? <ul className="space-y-2">{usersWithRole.map(p => <li key={p.id} className="p-2 bg-gray-100 rounded">{p.fullName}</li>)}</ul> : <p className="text-center text-gray-500 p-4">هیچ کاربری این نقش را ندارد.</p>}</div></Modal>}
            {isModalOpen && <Modal title={selectedRole ? 'ویرایش نقش' : 'ایجاد نقش جدید'} onClose={() => setIsModalOpen(false)} size="3xl"><form onSubmit={handleSubmit(onSubmit)}><div className="border-b border-gray-200"><nav className="flex -mb-px"><button type="button" onClick={() => setActiveTab('details')} className={`py-3 px-5 font-semibold text-sm ${activeTab === 'details' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}>مشخصات نقش</button><button type="button" onClick={() => setActiveTab('permissions')} className={`py-3 px-5 font-semibold text-sm ${activeTab === 'permissions' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}>دسترسی‌ها</button></nav></div><div className="p-6 max-h-[60vh] overflow-y-auto">{activeTab === 'details' && <div className="space-y-4"><div><label className="block text-sm font-medium text-gray-700 mb-1">عنوان نقش</label><input {...register('name')} className="w-full border p-2 rounded-md" />{errors.name && <p className="text-red-500 text-xs mt-1">{errors.name.message as string}</p>}</div><div><label className="block text-sm font-medium text-gray-700 mb-1">توضیحات</label><textarea {...register('description')} rows={3} className="w-full border p-2 rounded-md" /></div></div>}{activeTab === 'permissions' && <div className="space-y-4">{ALL_PERMISSIONS_LIST.map(({ resourceKey, resourceLabel, permissions }) => <div key={resourceKey} className="p-3 border rounded-lg"><h4 className="font-bold text-gray-800 mb-2">{resourceLabel}</h4><div className="grid grid-cols-2 sm:grid-cols-4 gap-3">{permissions.map(({ key, label }) => { const pStr = (PERMISSION_MAP[resourceKey as keyof typeof PERMISSION_MAP] as any)[key as keyof typeof PERMISSIONS]; return <label key={pStr} className="flex items-center gap-2 cursor-pointer"><input type="checkbox" checked={currentPermissions.has(pStr)} onChange={e => handlePermissionChange(pStr, e.target.checked)} /> {label}</label>; })}</div></div>)}</div>}</div><div className="flex justify-end gap-2 p-4 border-t bg-gray-50"><button type="button" onClick={() => setIsModalOpen(false)} className="bg-gray-200 px-4 py-2 rounded font-semibold">لغو</button><button type="submit" disabled={mutation.isPending} className="bg-green-500 text-white px-4 py-2 rounded disabled:bg-gray-400 font-semibold">{mutation.isPending ? '...' : 'ذخیره'}</button></div></form></Modal>}
        </section>
    );
};

export default RolesPage;