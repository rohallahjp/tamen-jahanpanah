declare const process: any;
// @ts-ignore
import { GoogleGenAI, Type } from '@google/genai';
import { Unit, Person, RequestCategory, PETTY_CASH_ROLE_ID } from '../types';

let ai: GoogleGenAI | null = null;
const apiKey = process.env.API_KEY;

if (apiKey) {
  ai = new GoogleGenAI({ apiKey });
}

export const parseQueryToFilters = async (
  query: string,
  units: Unit[],
  persons: Person[],
  categories: RequestCategory[]
): Promise<any> => {
  if (!ai) {
    throw new Error("سرویس دستیار هوشمند پیکربندی نشده است. لطفا کلید API را در فایل .env تعریف کنید.");
  }
  
  try {
    const today = new Date().toISOString().split('T')[0];

    // Prepare context data for the model
    const unitsContext = units.map(u => ({ id: u.id, name: u.name }));
    const personsContext = persons.map(p => ({ id: p.id, name: p.fullName }));
    const categoriesContext = categories.map(c => ({ id: c.id, label: c.label }));
    // FIX: Property 'isPettyCashHolder' does not exist on type 'Person'. A person is a petty cash holder if they have the correct role.
    const imprestHoldersContext = persons.filter(p => p.roleIds?.includes(PETTY_CASH_ROLE_ID)).map(p => ({ id: p.id, name: p.fullName }));

    const systemInstruction = `You are an expert at converting natural language into a JSON filter object for a database query.
The user is querying a list of supply requests.
Analyze the user's query and the provided context data to generate a JSON object with the appropriate keys and values for filtering.
- The JSON should only contain keys relevant to the user's query. If a filter is not mentioned, do not include its key in the JSON.
- Map names (of people, units, categories) to their corresponding stringified IDs from the context.
- For dates, use 'YYYY-MM-DD' format. Today's date is ${today}. Handle relative dates like 'last month', 'this year', 'yesterday'.
- Status values can be: IN_REVIEW, APPROVED, REJECTED. Map Farsi terms like 'تایید شده' to 'APPROVED'.
- Convert amounts with Farsi suffixes like 'میلیون' or 'هزار' to numbers (e.g., '1 میلیون' becomes 1000000).
- The user query is in Farsi.
- Return ONLY the raw JSON object. Do not include any other text, explanations, or markdown formatting like \`\`\`json.

Context Data:
- Units: ${JSON.stringify(unitsContext)}
- Persons (for requesterId): ${JSON.stringify(personsContext)}
- Request Categories: ${JSON.stringify(categoriesContext)}
- Imprest Holders (for imprestHolderId): ${JSON.stringify(imprestHoldersContext)}
`;

    const responseSchema = {
        type: Type.OBJECT,
        properties: {
            status: { type: Type.STRING, description: "Filter by request status. Can be IN_REVIEW, APPROVED, or REJECTED." },
            requestTypeId: { type: Type.STRING, description: "Filter by request category ID." },
            requesterId: { type: Type.STRING, description: "Filter by the ID of the person who submitted the request." },
            requestingUnitId: { type: Type.STRING, description: "Filter by the ID of the unit that submitted the request." },
            dateFrom: { type: Type.STRING, description: "Start date for filtering in YYYY-MM-DD format." },
            dateTo: { type: Type.STRING, description: "End date for filtering in YYYY-MM-DD format." },
            amountFrom: { type: Type.NUMBER, description: "Minimum request amount." },
            amountTo: { type: Type.NUMBER, description: "Maximum request amount." },
            imprestHolderId: { type: Type.STRING, description: "Filter by the ID of the imprest holder/petty cash holder." },
        },
    };
    
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `User query: "${query}"`,
        config: {
            systemInstruction,
            responseMimeType: 'application/json',
            responseSchema,
        }
    });

    const jsonString = response.text.trim();
    if (!jsonString) {
      throw new Error("دستیار هوشمند پاسخی ارائه نکرد.");
    }
    
    const parsedJson = JSON.parse(jsonString);
    return parsedJson;

  } catch (error: any) {
    console.error("Error parsing query with Gemini:", error);
    if (error.message && (error.message.includes('API key not valid') || error.message.includes('API_KEY'))) {
        throw new Error("سرویس دستیار هوشمند پیکربندی نشده است. کلید API نامعتبر است.");
    }
    const message = error.details || error.message || "متاسفانه در درک درخواست شما مشکلی پیش آمد.";
    throw new Error(message);
  }
};
