import {
    Role, Person, Unit, Workflow, SupplyRequest, RequestCategory, Project, DebitCard,
    PersonData, UnitData, SupplyRequestData, RoleData, WorkflowData, RequestCategoryData, ProjectData, DebitCardData,
    InternalWorkflow, InternalWorkflowData, SecuritySetting, SecuritySettingData,
    ExpenseReport, ExpenseReportData,
    Contract, ContractData,
    AppearanceSettings,
    ReportSummary,
    DashboardSummary,
    PaginatedResponse,
} from '../types.ts';
import { UnitNode } from '../features/Units/UnitsPage.tsx';

const API_BASE_URL = `http://${window.location.hostname}:4000/api`;

const apiFetch = async <T>(url: string, options: RequestInit = {}): Promise<T> => {
    try {
        const response = await fetch(`${API_BASE_URL}${url}`, {
            ...options,
            headers: {
                'Content-Type': 'application/json',
                ...options.headers,
            },
        });

        if (response.status === 204) {
            return {} as T;
        }

        const body = await response.json().catch(() => {
            return { message: `پاسخ دریافتی از سرور معتبر نبود. (وضعیت: ${response.status})` };
        });

        if (!response.ok) {
            const errorMessage = body.detail
                ? `${body.message} جزئیات: ${body.detail}`
                : body.message || 'یک خطای ناشناخته در سرور رخ داد.';
            throw new Error(errorMessage);
        }

        return body as T;

    } catch (error) {
        console.error(`API call failed: ${options.method || 'GET'} ${url}`, error);
        throw error;
    }
};

const createCrudApiService = <T extends { id: any }, U>(collectionName: string) => ({
    getAll: (page: number, q?: string, filters?: Record<string, string | boolean | number>): Promise<PaginatedResponse<T>> => {
        const params = new URLSearchParams({ page: String(page) });
        if (q) {
            params.append('q', q);
        }
        if (filters) {
            Object.entries(filters).forEach(([key, value]) => {
                if (value !== undefined && value !== null) {
                    params.append(key, String(value));
                }
            });
        }
        return apiFetch<PaginatedResponse<T>>(`/${collectionName}?${params.toString()}`);
    },
    
    getAllUnpaginated: (filters?: Record<string, string | boolean>): Promise<T[]> => {
        const params = new URLSearchParams({ _nopagination: 'true' });
        if (filters) {
            Object.entries(filters).forEach(([key, value]) => {
                if (value !== undefined && value !== null) {
                    params.append(key, String(value));
                }
            });
        }
        return apiFetch<PaginatedResponse<T>>(`/${collectionName}?${params.toString()}`).then(res => res.data);
    },
    
    create: (newItemData: U): Promise<T> => apiFetch<T>(`/${collectionName}`, {
        method: 'POST',
        body: JSON.stringify(newItemData),
    }),

    update: (id: any, updatedItemData: Partial<U>): Promise<T> => apiFetch<T>(`/${collectionName}/${id}`, {
        method: 'PUT',
        body: JSON.stringify(updatedItemData),
    }),

    delete: (id: any): Promise<{ success: boolean }> => apiFetch<{ success: boolean }>(`/${collectionName}/${id}`, {
        method: 'DELETE',
    }),
});


export const personsApi = {
    ...createCrudApiService<Person, PersonData & { actingUserId?: number }>('persons'),
    verifyPassword: (userId: number, passwordToCheck: string): Promise<{ success: boolean }> => 
        apiFetch(`/persons/${userId}/verify-password`, { method: 'POST', body: JSON.stringify({ password: passwordToCheck }) }),
    changePassword: (userId: number, currentPassword: string, newPassword: string): Promise<{ success: boolean }> =>
        apiFetch(`/persons/${userId}/change-password`, { method: 'PUT', body: JSON.stringify({ currentPassword, newPassword }) }),
    resetPassword: (userId: number, newPassword: string): Promise<{ success: boolean }> =>
        apiFetch(`/persons/${userId}/reset-password`, { method: 'PUT', body: JSON.stringify({ newPassword }) }),
    revokeAccess: (userId: number): Promise<{ success: boolean }> =>
        apiFetch(`/persons/${userId}/revoke-access`, { method: 'POST' }),
};

export const unitsApi = {
    ...createCrudApiService<Unit, UnitData>('units'),
    getTree: (): Promise<UnitNode[]> => apiFetch('/units/tree'),
    assignPerson: (unitId: number, personId: number): Promise<{ success: boolean }> =>
        apiFetch(`/units/${unitId}/persons`, { method: 'POST', body: JSON.stringify({ personId }) }),
    unassignPerson: (unitId: number, personId: number): Promise<{ success: boolean }> =>
        apiFetch(`/units/${unitId}/persons/${personId}`, { method: 'DELETE' }),
};

export const expenseReportsApi = {
    ...createCrudApiService<ExpenseReport, ExpenseReportData>('expenseReports'),
    approve: (data: { reportId: number, actingUserId: number }): Promise<ExpenseReport> => 
        apiFetch(`/expenseReports/${data.reportId}/approve`, { method: 'POST', body: JSON.stringify({ actingUserId: data.actingUserId }) }),
};
export const requestCategoriesApi = createCrudApiService<RequestCategory, RequestCategoryData>('requestCategories');
export const workflowsApi = createCrudApiService<Workflow, WorkflowData>('workflows');
export const rolesApi = createCrudApiService<Role, RoleData | Partial<Role>>('roles');
export const supplyRequestsApi = createCrudApiService<SupplyRequest, SupplyRequestData>('supplyRequests');
export const projectsApi = createCrudApiService<Project, ProjectData>('projects');
export const debitCardApi = createCrudApiService<DebitCard, DebitCardData>('debitCards');
export const internalWorkflowsApi = createCrudApiService<InternalWorkflow, InternalWorkflowData>('internalWorkflows');
export const securityApi = createCrudApiService<SecuritySetting, SecuritySettingData>('securitySettings');
export const contractsApi = createCrudApiService<Contract, ContractData>('contracts');
// positionsApi is removed as positions are now part of units
// export const positionsApi = createCrudApiService<Position, PositionData>('positions');

export const appearanceApi = {
    get: (): Promise<AppearanceSettings> => apiFetch<AppearanceSettings>('/appearanceSettings'),
    update: (settings: AppearanceSettings): Promise<AppearanceSettings> => apiFetch<AppearanceSettings>('/appearanceSettings', {
        method: 'POST',
        body: JSON.stringify(settings),
    }),
};

export const reportsApi = {
    search: (filters: any, page: number): Promise<PaginatedResponse<SupplyRequest>> => 
        apiFetch(`/reports/search?page=${page}`, { method: 'POST', body: JSON.stringify(filters) }),
    getSummary: (filters: any): Promise<ReportSummary> =>
        apiFetch('/reports/summary', { method: 'POST', body: JSON.stringify(filters) }),
};

export const dashboardApi = {
    getSummary: (userInfo: { userId: number }): Promise<DashboardSummary> =>
        apiFetch('/dashboard/summary', { method: 'POST', body: JSON.stringify(userInfo) }),
    getRequests: (userInfo: { userId: number }, page: number): Promise<PaginatedResponse<SupplyRequest>> =>
        apiFetch(`/dashboard/requests?page=${page}`, { method: 'POST', body: JSON.stringify(userInfo) }),
};

export const workflowEngineApi = {
    submitNewRequest: (requestData: SupplyRequestData): Promise<SupplyRequest> =>
        apiFetch('/requests/submit', { method: 'POST', body: JSON.stringify(requestData) }),
    
    approveStep: (requestId: string, currentStepId: number, personId: number, comment?: string): Promise<SupplyRequest> =>
        apiFetch(`/requests/${requestId}/approve`, { method: 'POST', body: JSON.stringify({ currentStepId, personId, comment }) }),

    rejectRequest: (requestId: string, currentStepId: number, personId: number, comment: string): Promise<SupplyRequest> =>
        apiFetch(`/requests/${requestId}/reject`, { method: 'POST', body: JSON.stringify({ currentStepId, personId, comment }) }),
    
    resubmitRejectedRequest: (requestId: string, updatedData: SupplyRequestData): Promise<SupplyRequest> =>
        apiFetch(`/requests/${requestId}/resubmit`, { method: 'POST', body: JSON.stringify(updatedData) }),
        
    startInternalReview: (requestId: string, mainStepId: number, mainAssigneeId: number, internalWorkflowId: number, comment?: string): Promise<SupplyRequest> =>
        apiFetch(`/requests/${requestId}/internal-review/start`, { method: 'POST', body: JSON.stringify({ mainStepId, mainAssigneeId, internalWorkflowId, comment }) }),
    
    advanceInternalReview: (requestId: string, currentInternalStepId: number, personId: number, action: 'FORWARD' | 'RETURN_TO_MANAGER', comment?: string): Promise<SupplyRequest> =>
        apiFetch(`/requests/${requestId}/internal-review/advance`, { method: 'POST', body: JSON.stringify({ currentInternalStepId, personId, action, comment }) }),
};

export const authApi = {
    login: (username: string, password: string): Promise<Person> =>
        apiFetch('/login', { method: 'POST', body: JSON.stringify({ username, password }) }),
};

export const diagnosticsApi = {
    getDbCounts: (): Promise<Record<string, number>> => apiFetch('/diagnostics/db-counts'),
};