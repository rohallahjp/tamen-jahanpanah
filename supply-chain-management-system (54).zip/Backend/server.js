const path = require('path');
const crypto = require('crypto');
// Load environment variables from .env file in the project root
require('dotenv').config({ path: path.resolve(__dirname, '..', '.env') });

const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');

// --- Check for required environment variables ---
const requiredEnvVars = ['DB_HOST', 'DB_DATABASE', 'DB_USER', 'DB_PASSWORD'];
const missingVars = requiredEnvVars.filter(v => !process.env[v]);

if (missingVars.length > 0) {
    console.error('\x1b[31m%s\x1b[0m', '[FATAL_ERROR] Missing required environment variables in .env file:');
    missingVars.forEach(v => console.error(`- ${v}`));
    console.error('\x1b[33m%s\x1b[0m', 'Please add them to your .env file in the project root.');
    process.exit(1);
}

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));

// Serve static files from the React build directory
app.use(express.static(path.join(__dirname, '..')));

// --- Configure Database Pool ---
const pool = new Pool({
    host: process.env.DB_HOST,
    database: process.env.DB_DATABASE,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT || 5432, // Default port for PostgreSQL
});


pool.on('error', (err) => {
    console.error('Unexpected error on idle client', err);
    process.exit(-1);
});

// --- Helper Functions ---
const hashPassword = (password) => {
    return crypto.createHash('sha256').update(password).digest('hex');
};

const processBodyForDb = (body) => {
    const processed = {};
    for (const key in body) {
        const value = body[key];
        if (value === '') {
            processed[key] = null;
        } else if (key === 'password' && value) {
            processed[key] = hashPassword(value);
        } else if (typeof value === 'object' && value !== null) {
            processed[key] = JSON.stringify(value);
        } else {
            processed[key] = value;
        }
    }
    return processed;
};

const persianToEnglishKey = (str) => {
    if (!str) return '';
    const persianMap = {
        'ا': 'A', 'آ': 'A', 'ب': 'B', 'پ': 'P', 'ت': 'T', 'ث': 'S', 'ج': 'J', 'چ': 'CH',
        'ح': 'H', 'خ': 'KH', 'د': 'D', 'ذ': 'Z', 'ر': 'R', 'ز': 'Z', 'ژ': 'ZH', 'س': 'S',
        'ش': 'SH', 'ص': 'S', 'ض': 'Z', 'ط': 'T', 'ظ': 'Z', 'ع': 'A', 'غ': 'GH', 'ف': 'F',
        'ق': 'GH', 'ک': 'K', 'گ': 'G', 'ل': 'L', 'م': 'M', 'ن': 'N', 'و': 'V', 'ه': 'H',
        'ی': 'Y', ' ': '_', 'ء': 'A', '۱': '1', '۲': '2', '۳': '3', '۴': '4', '۵': '5',
        '۶': '6', '۷': '7', '۸': '8', '۹': '9', '۰': '0'
    };
    return str.split('').map(char => persianMap[char] || char)
        .join('').toUpperCase().replace(/[^A-Z0-9_]/g, '').replace(/__+/g, '_');
};


const startServer = async () => {
    // --- Perform a single, upfront database connection test ---
    let client;
    try {
        client = await pool.connect();
        await client.query('SELECT NOW()');
        console.log('\x1b[32m%s\x1b[0m', 'Database connection successful.');
    } catch (err) {
        console.error('\x1b[31m%s\x1b[0m', '[FATAL_ERROR] Could not connect to the database.');
        console.error('Please check your .env file settings and ensure the database server is running.');
        console.error('Error details:', err.message);
        process.exit(1);
    } finally {
        if (client) {
            client.release();
        }
    }


    // --- Database Initialization Check API ---
    app.get('/api/init-check', async (req, res) => {
        try {
            await pool.query('SELECT 1 FROM "persons" LIMIT 1');
            res.json({ initialized: true });
        } catch (err) {
            if (err.code === '42P01') {
                res.json({ initialized: false });
            } else {
                console.error('Database initialization check failed unexpectedly:', err);
                res.status(500).json({ message: 'Error checking database status.', detail: err.message });
            }
        }
    });
    
    // --- Authentication ---
    app.post('/api/login', async (req, res) => {
        const { username, password } = req.body;
        try {
            const hashedPassword = hashPassword(password);
            const userRes = await pool.query('SELECT * FROM "persons" WHERE "isSystemUser" = true AND "username" = $1', [username]);
            const user = userRes.rows[0];

            if (user && user.password === hashedPassword) {
                const { password, ...userWithoutPassword } = user;
                const roleIds = user.roleIds || [];
                if (roleIds.length === 0) {
                    return res.json({ ...userWithoutPassword, permissions: [] });
                }
                
                const rolesRes = await pool.query(`SELECT "permissions" FROM "roles" WHERE id = ANY($1)`, [roleIds]);
                const permissions = [...new Set(rolesRes.rows.flatMap(role => role.permissions || []))];
                
                // Add position name from unit
                if(user.unitId) {
                    const unitRes = await pool.query('SELECT name FROM units WHERE id = $1', [user.unitId]);
                    userWithoutPassword.position = unitRes.rows[0]?.name;
                }

                const userWithPermissions = { ...userWithoutPassword, permissions };
                res.json(userWithPermissions);
            } else {
                return res.status(401).json({ message: 'نام کاربری یا رمز عبور اشتباه است.' });
            }
        } catch (err) {
            console.error("Login DB Error:", err);
            return res.status(500).json({ message: 'خطای داخلی سرور.', detail: err.message });
        }
    });

    app.post('/api/persons/:id/verify-password', async (req, res) => {
        const { id } = req.params;
        const { password } = req.body;
        try {
            const hashedPassword = hashPassword(password);
            const userRes = await pool.query('SELECT password FROM "persons" WHERE id = $1', [id]);
            const user = userRes.rows[0];
            if (user && user.password === hashedPassword) {
                res.json({ success: true });
            } else {
                res.json({ success: false });
            }
        } catch (err) {
            res.status(500).json({ message: 'خطای داخلی سرور.', detail: err.message });
        }
    });
    
    app.put('/api/persons/:id/change-password', async (req, res) => {
        const { id } = req.params;
        const { currentPassword, newPassword } = req.body;
        try {
            const hashedCurrentPassword = hashPassword(currentPassword);
            const userRes = await pool.query('SELECT password FROM "persons" WHERE id = $1', [id]);
            const user = userRes.rows[0];
            if (!user || user.password !== hashedCurrentPassword) {
                return res.status(403).json({ message: 'گذرواژه فعلی اشتباه است.' });
            }
            const hashedNewPassword = hashPassword(newPassword);
            await pool.query('UPDATE "persons" SET password = $1 WHERE id = $2', [hashedNewPassword, id]);
            res.json({ success: true });
        } catch (err) {
            res.status(500).json({ message: 'خطای داخلی سرور.', detail: err.message });
        }
    });

    app.put('/api/persons/:id/reset-password', async (req, res) => {
        const { id } = req.params;
        const { newPassword } = req.body;
        try {
            const hashedNewPassword = hashPassword(newPassword);
            await pool.query('UPDATE "persons" SET password = $1 WHERE id = $2', [hashedNewPassword, id]);
            res.json({ success: true });
        } catch(err) {
            res.status(500).json({ message: 'خطا در بازنشانی رمز عبور', detail: err.message });
        }
    });

    app.post('/api/persons/:id/revoke-access', async (req, res) => {
        const { id } = req.params;
        try {
            await pool.query(
                `UPDATE "persons" SET "isSystemUser" = false, username = NULL, password = NULL, "roleIds" = '[]' WHERE id = $1`,
                [id]
            );
            res.json({ success: true });
        } catch(err) {
            res.status(500).json({ message: 'خطا در لغو دسترسی کاربر', detail: err.message });
        }
    });

    // --- Special Endpoint for Optimized Org Chart ---
    app.get('/api/units/tree', async (req, res) => {
        const query = `
            WITH RECURSIVE unit_hierarchy AS (
                SELECT id, name, code, credit, "parentId", 0 as depth
                FROM units
                WHERE "parentId" IS NULL
                UNION ALL
                SELECT u.id, u.name, u.code, u.credit, u."parentId", uh.depth + 1
                FROM units u
                JOIN unit_hierarchy uh ON u."parentId" = uh.id
            ),
            unit_persons AS (
                SELECT
                    "unitId",
                    jsonb_agg(jsonb_build_object('id', p.id, 'fullName', p."fullName")) as persons
                FROM persons p
                WHERE p."unitId" IS NOT NULL
                GROUP BY "unitId"
            )
            SELECT
                uh.*,
                COALESCE(up.persons, '[]'::jsonb) as persons
            FROM unit_hierarchy uh
            LEFT JOIN unit_persons up ON uh.id = up."unitId";
        `;
        try {
            const { rows } = await pool.query(query);
            
            const unitMap = new Map(rows.map(row => {
                const { persons, ...unitData } = row;
                return [row.id, {
                    ...unitData,
                    persons: persons || [],
                    children: []
                }];
            }));

            const tree = [];
            unitMap.forEach(node => {
                if (node.parentId && unitMap.has(node.parentId)) {
                    unitMap.get(node.parentId).children.push(node);
                } else {
                    tree.push(node);
                }
            });
            res.json(tree);
        } catch (err) {
            console.error('[GET /units/tree] DB Error:', err);
            res.status(500).json({ message: 'خطا در ساختار سازمانی', detail: err.message });
        }
    });
    
    app.post('/api/units/:unitId/persons', async (req, res) => {
        const { unitId } = req.params;
        const { personId } = req.body;
        try {
            await pool.query('UPDATE "persons" SET "unitId" = $1 WHERE id = $2', [unitId, personId]);
            res.json({ success: true });
        } catch (err) {
            res.status(500).json({ message: 'خطا در انتصاب شخص', detail: err.message });
        }
    });

    app.delete('/api/units/:unitId/persons/:personId', async (req, res) => {
        const { personId } = req.params;
        try {
            await pool.query('UPDATE "persons" SET "unitId" = NULL WHERE id = $1', [personId]);
            res.json({ success: true });
        } catch (err) {
            res.status(500).json({ message: 'خطا در حذف انتصاب شخص', detail: err.message });
        }
    });


    // --- Workflow Engine API ---
    const findAssignee = async (client, rule, requestingUnitId) => {
        const { type, userId, roleId, unitId } = rule;
        let assigneeId = null;

        if (type === 'USER') {
            assigneeId = userId;
        } else if (type === 'UNIT_MANAGER') {
            const managerRoleRes = await client.query("SELECT id FROM roles WHERE name = 'مدیر واحد'");
            if (managerRoleRes.rows.length === 0) throw new Error("نقش 'مدیر واحد' یافت نشد.");
            const managerRoleId = managerRoleRes.rows[0].id;
            
            const managerRes = await client.query(
                `SELECT id FROM "persons" WHERE "unitId" = $1 AND "roleIds" @> $2::jsonb LIMIT 1`,
                [requestingUnitId, JSON.stringify([managerRoleId])]
            );

            if (managerRes.rows.length > 0) assigneeId = managerRes.rows[0].id;

        } else if (type === 'ROLE') {
            const userWithRoleRes = await client.query(
                `SELECT id FROM "persons" WHERE "roleIds" @> $1::jsonb LIMIT 1`,
                [JSON.stringify([roleId])]
            );
            if (userWithRoleRes.rows.length > 0) assigneeId = userWithRoleRes.rows[0].id;
        } else if (type === 'UNIT_AND_ROLE') {
            const userWithRoleInUnitRes = await client.query(
                `SELECT id FROM "persons" WHERE "unitId" = $1 AND "roleIds" @> $2::jsonb LIMIT 1`,
                [unitId, JSON.stringify([roleId])]
            );
            if (userWithRoleInUnitRes.rows.length > 0) assigneeId = userWithRoleInUnitRes.rows[0].id;
        }
        return assigneeId;
    };

    app.post('/api/requests/submit', async (req, res) => {
        const requestData = req.body;
        const client = await pool.connect();
        try {
            await client.query('BEGIN');
            const workflowRes = await client.query('SELECT * FROM "workflows" WHERE "requestCategoryId" = $1', [requestData.requestTypeId]);
            const workflow = workflowRes.rows[0];
            if (!workflow || !workflow.steps || workflow.steps.length === 0) {
                return res.status(400).json({ message: 'هیچ فرآیند معتبری برای این نوع درخواست تعریف نشده است.' });
            }
            const firstStep = workflow.steps[0];
            const assigneeId = await findAssignee(client, firstStep.assigneeRule, requestData.requestingUnitId);
            if (!assigneeId) {
                return res.status(400).json({ message: 'مسئول برای گام اول فرآیند یافت نشد. لطفا پیکربندی فرآیند را بررسی کنید.' });
            }
            const requestId = `${new Date().getFullYear().toString().slice(-2)}${String(new Date().getMonth() + 1).padStart(2, '0')}-${String(Math.floor(Math.random() * 9000) + 1000)}`;
            const newRequest = {
                id: requestId,
                workflowId: workflow.id,
                status: 'IN_REVIEW',
                _activeSteps: JSON.stringify([{ stepId: firstStep.id, assigneeId: assigneeId, startTimestamp: new Date().toISOString() }]),
                _history: '[]',
                ...requestData
            };
            const createData = processBodyForDb(newRequest);
            const keys = Object.keys(createData);
            const placeholders = keys.map((_, i) => `$${i + 1}`).join(',');
            const values = keys.map(key => createData[key]);
            const sql = `INSERT INTO "supplyRequests" (${keys.map(k => `"${k}"`).join(',')}) VALUES (${placeholders}) RETURNING *`;
            const result = await client.query(sql, values);
            await client.query('COMMIT');
            res.status(201).json(result.rows[0]);
        } catch (err) {
            await client.query('ROLLBACK');
            console.error('[POST /requests/submit] DB Error:', err);
            res.status(500).json({ message: 'خطا در ثبت درخواست در سرور.', detail: err.message });
        } finally {
            client.release();
        }
    });

    app.post('/api/requests/:requestId/approve', async (req, res) => {
        const { requestId } = req.params;
        const { currentStepId, personId, comment } = req.body;
        const client = await pool.connect();
        try {
            await client.query('BEGIN');
            const reqRes = await client.query('SELECT * FROM "supplyRequests" WHERE id = $1', [requestId]);
            if (reqRes.rows.length === 0) return res.status(404).json({ message: "درخواست یافت نشد." });
            let request = reqRes.rows[0];
            const activeStep = request["_activeSteps"].find(s => s.stepId === currentStepId && s.assigneeId === personId);
            if (!activeStep) return res.status(403).json({ message: "شما مجاز به انجام این عملیات نیستید." });

            const workflowRes = await client.query('SELECT * FROM "workflows" WHERE id = $1', [request.workflowId]);
            const workflow = workflowRes.rows[0];
            const currentStepIndex = workflow.steps.findIndex(s => s.id === currentStepId);

            request["_history"].push({ ...activeStep, personId, action: 'APPROVE', comment: comment || null, endTimestamp: new Date().toISOString() });

            if (currentStepIndex === workflow.steps.length - 1) {
                // Last step
                request.status = 'APPROVED';
                request["_activeSteps"] = [];

                // Petty Cash Logic: Deduct from balance on final approval
                const categoryRes = await client.query('SELECT key FROM "requestCategories" WHERE id = $1', [request.requestTypeId]);
                if (categoryRes.rows[0]?.key === 'PETTY_CASH' && request.imprestHolderId) {
                    await client.query(
                        'UPDATE "persons" SET "pettyCashBalance" = "pettyCashBalance" - $1 WHERE id = $2',
                        [request.amount, request.imprestHolderId]
                    );
                }

            } else {
                const nextStep = workflow.steps[currentStepIndex + 1];
                const nextAssigneeId = await findAssignee(client, nextStep.assigneeRule, request.requestingUnitId);
                if (!nextAssigneeId) return res.status(400).json({ message: `مسئول برای گام بعدی (${nextStep.name}) یافت نشد.` });
                request["_activeSteps"] = [{ stepId: nextStep.id, assigneeId: nextAssigneeId, startTimestamp: new Date().toISOString() }];
            }
            const updateRes = await client.query(
                'UPDATE "supplyRequests" SET status = $1, "_activeSteps" = $2, "_history" = $3 WHERE id = $4 RETURNING *',
                [request.status, JSON.stringify(request["_activeSteps"]), JSON.stringify(request["_history"]), requestId]
            );
            await client.query('COMMIT');
            res.json(updateRes.rows[0]);
        } catch (err) {
            await client.query('ROLLBACK');
            res.status(500).json({ message: 'خطا در تایید درخواست.', detail: err.message });
        } finally {
            client.release();
        }
    });
    
    app.post('/api/requests/:requestId/reject', async (req, res) => {
         const { requestId } = req.params;
        const { currentStepId, personId, comment } = req.body;
        if (!comment) return res.status(400).json({ message: 'دلیل رد درخواست الزامی است.' });

        const client = await pool.connect();
        try {
            await client.query('BEGIN');
            const reqRes = await client.query('SELECT * FROM "supplyRequests" WHERE id = $1', [requestId]);
            if (reqRes.rows.length === 0) return res.status(404).json({ message: "درخواست یافت نشد." });
            let request = reqRes.rows[0];
            const activeStep = request["_activeSteps"].find(s => s.stepId === currentStepId && s.assigneeId === personId);
            if (!activeStep) return res.status(403).json({ message: "شما مجاز به انجام این عملیات نیستید." });
            
            request["_history"].push({ ...activeStep, personId, action: 'REJECT', comment, endTimestamp: new Date().toISOString() });
            request.status = 'REJECTED';
            request["_activeSteps"] = [];

            const updateRes = await client.query(
                'UPDATE "supplyRequests" SET status = $1, "_activeSteps" = $2, "_history" = $3 WHERE id = $4 RETURNING *',
                [request.status, JSON.stringify(request["_activeSteps"]), JSON.stringify(request["_history"]), requestId]
            );
            await client.query('COMMIT');
            res.json(updateRes.rows[0]);
        } catch (err) {
            await client.query('ROLLBACK');
            res.status(500).json({ message: 'خطا در رد درخواست.', detail: err.message });
        } finally {
            client.release();
        }
    });

    app.post('/api/requests/:requestId/resubmit', async (req, res) => {
        const { requestId } = req.params;
        const updatedData = req.body;
        const client = await pool.connect();

        try {
            await client.query('BEGIN');
            const reqRes = await client.query('SELECT * FROM "supplyRequests" WHERE id = $1', [requestId]);
            if (reqRes.rows.length === 0) return res.status(404).json({ message: "درخواست یافت نشد." });
            let request = reqRes.rows[0];
            
            const workflowRes = await client.query('SELECT * FROM "workflows" WHERE id = $1', [request.workflowId]);
            const workflow = workflowRes.rows[0];
            const firstStep = workflow.steps[0];
            const assigneeId = await findAssignee(client, firstStep.assigneeRule, request.requestingUnitId);
            if (!assigneeId) return res.status(400).json({ message: 'مسئول برای گام اول فرآیند یافت نشد.' });

            request["_history"].push({ action: 'RESUBMIT', personId: request.requesterId, endTimestamp: new Date().toISOString(), startTimestamp: new Date().toISOString() });
            
            const newActiveSteps = [{ stepId: firstStep.id, assigneeId, startTimestamp: new Date().toISOString() }];

            const finalUpdateData = processBodyForDb({
                ...updatedData,
                status: 'IN_REVIEW',
                _activeSteps: JSON.stringify(newActiveSteps),
                _history: JSON.stringify(request["_history"]),
            });
            const keys = Object.keys(finalUpdateData);
            const setString = keys.map((key, i) => `"${key}" = $${i + 1}`).join(',');
            const values = keys.map(key => finalUpdateData[key]);
            
            const sql = `UPDATE "supplyRequests" SET ${setString} WHERE id = $${keys.length + 1} RETURNING *`;
            const updateRes = await client.query(sql, [...values, requestId]);

            await client.query('COMMIT');
            res.json(updateRes.rows[0]);

        } catch (err) {
            await client.query('ROLLBACK');
            res.status(500).json({ message: 'خطا در ارسال مجدد درخواست.', detail: err.message });
        } finally {
            client.release();
        }
    });

    app.post('/api/requests/:requestId/internal-review/start', async (req, res) => {
        const { requestId } = req.params;
        const { mainStepId, mainAssigneeId, internalWorkflowId, comment } = req.body;
        const client = await pool.connect();
        try {
            await client.query('BEGIN');

            const iwRes = await client.query('SELECT * FROM "internalWorkflows" WHERE id = $1', [internalWorkflowId]);
            const internalWorkflow = iwRes.rows[0];
            if (!internalWorkflow || !internalWorkflow.steps || internalWorkflow.steps.length === 0) {
                return res.status(400).json({ message: 'فرآیند داخلی نامعتبر است.' });
            }
            const firstInternalStep = internalWorkflow.steps[0];
            
            const internalReviewState = {
                mainStepId,
                mainAssigneeId,
                internalWorkflowId,
                history: [],
                activeInternalStepId: firstInternalStep.id,
                activeInternalAssigneeId: firstInternalStep.assigneeId,
                initiatorComment: comment,
            };

            const updateRes = await client.query(
                `UPDATE "supplyRequests" SET "_internalReview" = $1 WHERE id = $2 RETURNING *`,
                [JSON.stringify(internalReviewState), requestId]
            );

            await client.query('COMMIT');
            res.json(updateRes.rows[0]);
        } catch (err) {
            await client.query('ROLLBACK');
            res.status(500).json({ message: 'خطا در شروع فرآیند داخلی.', detail: err.message });
        } finally {
            client.release();
        }
    });

    app.post('/api/requests/:requestId/internal-review/advance', async (req, res) => {
        const { requestId } = req.params;
        const { currentInternalStepId, personId, action, comment } = req.body;
        const client = await pool.connect();
        try {
            await client.query('BEGIN');

            const reqRes = await client.query('SELECT * FROM "supplyRequests" WHERE id = $1', [requestId]);
            if (reqRes.rows.length === 0) return res.status(404).json({ message: "درخواست یافت نشد." });
            let request = reqRes.rows[0];

            if (!request["_internalReview"] || request["_internalReview"].activeInternalAssigneeId !== personId) {
                return res.status(403).json({ message: 'شما مجاز به انجام این عملیات نیستید.' });
            }

            const internalWorkflowRes = await client.query('SELECT * FROM "internalWorkflows" WHERE id = $1', [request["_internalReview"].internalWorkflowId]);
            const internalWorkflow = internalWorkflowRes.rows[0];
            const currentStepIndex = internalWorkflow.steps.findIndex(s => s.id === currentInternalStepId);

            request["_internalReview"].history.push({ stepId: currentInternalStepId, personId, action, comment, timestamp: new Date().toISOString() });
            
            if (action === 'RETURN_TO_MANAGER' || currentStepIndex === internalWorkflow.steps.length - 1) {
                // End of internal review, return control to main workflow
                const endedInternalReviewDetails = {
                    ...request["_internalReview"],
                    finalAction: action,
                    completionTimestamp: new Date().toISOString()
                };
                request["_history"].push({ action: 'INTERNAL_REVIEW_END', personId: personId, endTimestamp: new Date().toISOString(), startTimestamp: request["_activeSteps"][0].startTimestamp, stepId: request["_internalReview"].mainStepId, internalReviewDetails: endedInternalReviewDetails });
                request["_internalReview"] = null; // Clear active internal review
            } else {
                // Move to next internal step
                const nextStep = internalWorkflow.steps[currentStepIndex + 1];
                request["_internalReview"].activeInternalStepId = nextStep.id;
                request["_internalReview"].activeInternalAssigneeId = nextStep.assigneeId;
            }

            const updateRes = await client.query(
                `UPDATE "supplyRequests" SET "_internalReview" = $1, "_history" = $2 WHERE id = $3 RETURNING *`,
                [JSON.stringify(request["_internalReview"]), JSON.stringify(request["_history"]), requestId]
            );

            await client.query('COMMIT');
            res.json(updateRes.rows[0]);

        } catch (err) {
            await client.query('ROLLBACK');
            res.status(500).json({ message: 'خطا در پیشبرد فرآیند داخلی.', detail: err.message });
        } finally {
            client.release();
        }
    });

    // --- Petty Cash / Expense Report Approval ---
    app.post('/api/expenseReports/:id/approve', async (req, res) => {
        const { id } = req.params;
        const { actingUserId } = req.body;
        const client = await pool.connect();
        try {
            if (!actingUserId) {
                return res.status(401).json({ message: 'شناسه کاربر برای بررسی مجوزها ارسال نشده است.' });
            }

            // Permission Check
            const userRes = await client.query('SELECT "roleIds" FROM "persons" WHERE id = $1', [actingUserId]);
            const roleIds = userRes.rows[0]?.roleIds || [];
            const permsRes = await client.query('SELECT permissions FROM roles WHERE id = ANY($1)', [roleIds]);
            const userPermissions = new Set(permsRes.rows.flatMap(r => r.permissions));
            
            if (!userPermissions.has('PETTY_CASH_MANAGEMENT:update')) {
                return res.status(403).json({ message: 'شما دسترسی لازم برای تایید گزارشات هزینه را ندارید.' });
            }

            await client.query('BEGIN');

            const reportRes = await client.query('SELECT * FROM "expenseReports" WHERE id = $1', [id]);
            if (reportRes.rows.length === 0) {
                return res.status(404).json({ message: 'گزارش هزینه یافت نشد.' });
            }
            const report = reportRes.rows[0];

            if (report.status === 'APPROVED') {
                 return res.status(400).json({ message: 'این گزارش قبلا تایید شده است.' });
            }
            
            // Restore balance to the petty cash holder
            await client.query(
                `UPDATE "persons" 
                 SET "pettyCashBalance" = LEAST("pettyCashLimit", "pettyCashBalance" + $1) 
                 WHERE id = $2`,
                [report.totalAmount, report.pettyCashHolderId]
            );

            // Update the report status
            const updatedReportRes = await client.query(
                `UPDATE "expenseReports" 
                 SET status = 'APPROVED', "finalApprovalDate" = $1 
                 WHERE id = $2 RETURNING *`,
                [new Date().toISOString(), id]
            );
            
            await client.query('COMMIT');
            res.json(updatedReportRes.rows[0]);
        } catch (err) {
            await client.query('ROLLBACK');
            console.error('[POST /expenseReports/:id/approve] DB Error:', err);
            res.status(500).json({ message: 'خطا در تایید گزارش هزینه.', detail: err.message });
        } finally {
            client.release();
        }
    });


    // --- Dashboard API ---
    app.post('/api/dashboard/summary', async (req, res) => {
        const { userId } = req.body;
        if (!userId) {
            return res.status(400).json({ message: 'User ID is required.' });
        }

        try {
            const myPendingTasksQuery = `
                SELECT COUNT(*) FROM "supplyRequests" 
                WHERE status = 'IN_REVIEW' AND EXISTS (
                    SELECT 1 FROM jsonb_array_elements("_activeSteps") AS step WHERE (step->>'assigneeId')::int = $1
                );
            `;
            const myRecentSubmissionsQuery = `
                SELECT COUNT(*) FROM "supplyRequests" 
                WHERE "requesterId" = $1 AND "submissionDateForSort"::timestamp >= NOW() - INTERVAL '30 days';
            `;
            const totalPendingQuery = `SELECT COUNT(*) FROM "supplyRequests" WHERE status = 'IN_REVIEW'`;
            const totalApprovedThisMonthQuery = `
                SELECT COALESCE(SUM(amount), 0) AS total 
                FROM "supplyRequests" 
                WHERE status = 'APPROVED' 
                AND EXISTS (
                    SELECT 1 
                    FROM jsonb_array_elements("_history") as h 
                    WHERE h->>'action' = 'APPROVE' 
                    AND (h->>'endTimestamp')::timestamp >= date_trunc('month', NOW())
                );
            `;

            const [
                myPendingTasksRes,
                myRecentSubmissionsRes,
                totalPendingRes,
                totalApprovedThisMonthRes
            ] = await Promise.all([
                pool.query(myPendingTasksQuery, [userId]),
                pool.query(myRecentSubmissionsQuery, [userId]),
                pool.query(totalPendingQuery),
                pool.query(totalApprovedThisMonthQuery),
            ]);

            res.json({
                myPendingTasks: parseInt(myPendingTasksRes.rows[0].count, 10),
                myRecentSubmissions: parseInt(myRecentSubmissionsRes.rows[0].count, 10),
                totalPending: parseInt(totalPendingRes.rows[0].count, 10),
                totalApprovedThisMonth: parseFloat(totalApprovedThisMonthRes.rows[0].total),
            });

        } catch (err) {
            console.error('[POST /dashboard/summary] DB Error:', err);
            res.status(500).json({ message: 'خطا در دریافت خلاصه داشبورد', detail: err.message });
        }
    });

    app.post('/api/dashboard/requests', async (req, res) => {
        const { userId } = req.body;
        const page = parseInt(req.query.page || '1', 10);
        const limit = 20;
        const offset = (page - 1) * limit;

        if (!userId) {
            return res.status(400).json({ message: 'User ID is required.' });
        }
        
        try {
            const query = `
                SELECT 
                    s.*, 
                    p. "fullName" AS "requesterName", 
                    rc.label AS "requestCategoryLabel" 
                FROM 
                    "supplyRequests" s 
                    JOIN "persons" p ON s."requesterId" = p.id 
                    JOIN "requestCategories" rc ON s."requestTypeId" = rc.id 
                WHERE 
                    s."requesterId" = $1 
                    OR s.status = 'IN_REVIEW' AND EXISTS (
                        SELECT 1 FROM jsonb_array_elements(s."_activeSteps") AS step 
                        WHERE (step ->> 'assigneeId')::int = $1
                    ) 
                ORDER BY 
                    s."submissionDateForSort" DESC 
                LIMIT $2 OFFSET $3;
            `;

            const totalQuery = `
                SELECT COUNT(*) 
                FROM "supplyRequests" 
                WHERE 
                    "requesterId" = $1 
                    OR status = 'IN_REVIEW' AND EXISTS (
                        SELECT 1 FROM jsonb_array_elements("_activeSteps") AS step 
                        WHERE (step ->> 'assigneeId')::int = $1
                    );
            `;

            const [dataRes, totalRes] = await Promise.all([
                pool.query(query, [userId, limit, offset]),
                pool.query(totalQuery, [userId])
            ]);

            res.json({
                data: dataRes.rows,
                total: parseInt(totalRes.rows[0].count, 10),
            });
        } catch (err) {
             console.error('[POST /dashboard/requests] DB Error:', err);
            res.status(500).json({ message: 'خطا در دریافت درخواست‌های داشبورد', detail: err.message });
        }
    });

    // --- Reports API ---
    app.post('/api/reports/search', async (req, res) => {
        const filters = req.body;
        const page = parseInt(req.query.page || '1', 10);
        const limit = 20;
        const offset = (page - 1) * limit;

        let query = `
            SELECT 
                s.*, 
                p."fullName" AS "requesterName", 
                rc.label AS "requestCategoryLabel" 
            FROM 
                "supplyRequests" s
                JOIN "persons" p ON s."requesterId" = p.id
                JOIN "requestCategories" rc ON s."requestTypeId" = rc.id
        `;
        let whereClauses = [];
        let queryParams = [];
        let paramIndex = 1;

        Object.keys(filters).forEach(key => {
            const value = filters[key];
            if (value !== undefined && value !== '') {
                switch (key) {
                    case 'status':
                    case 'requestTypeId':
                    case 'requesterId':
                    case 'requestingUnitId':
                    case 'imprestHolderId':
                        whereClauses.push(`s."${key}" = $${paramIndex++}`);
                        queryParams.push(value);
                        break;
                    case 'dateFrom':
                        whereClauses.push(`s."submissionDateForSort"::date >= $${paramIndex++}`);
                        queryParams.push(value);
                        break;
                    case 'dateTo':
                        whereClauses.push(`s."submissionDateForSort"::date <= $${paramIndex++}`);
                        queryParams.push(value);
                        break;
                    case 'amountFrom':
                        whereClauses.push(`s.amount >= $${paramIndex++}`);
                        queryParams.push(value);
                        break;
                    case 'amountTo':
                        whereClauses.push(`s.amount <= $${paramIndex++}`);
                        queryParams.push(value);
                        break;
                    case 'assigneeId':
                         whereClauses.push(`EXISTS (
                            SELECT 1 FROM jsonb_array_elements(s."_activeSteps") AS step 
                            WHERE (step ->> 'assigneeId')::int = $${paramIndex++}
                         )`);
                         queryParams.push(value);
                        break;
                }
            }
        });

        if (whereClauses.length > 0) {
            query += ' WHERE ' + whereClauses.join(' AND ');
        }
        
        const countQuery = `SELECT COUNT(*) FROM (${query}) AS result`;
        query += ` ORDER BY s."submissionDateForSort" DESC LIMIT $${paramIndex++} OFFSET $${paramIndex++}`;
        queryParams.push(limit, offset);

        try {
            const [dataRes, totalRes] = await Promise.all([
                pool.query(query, queryParams),
                pool.query(countQuery, queryParams.slice(0, -2))
            ]);
            res.json({
                data: dataRes.rows,
                total: parseInt(totalRes.rows[0].count, 10),
            });
        } catch (err) {
            console.error('[POST /reports/search] DB Error:', err);
            res.status(500).json({ message: 'خطا در جستجوی گزارشات', detail: err.message });
        }
    });

    app.post('/api/reports/summary', async (req, res) => {
        const filters = req.body;
        let baseQuery = 'FROM "supplyRequests" s';
        let whereClauses = [];
        let queryParams = [];
        let paramIndex = 1;

        Object.keys(filters).forEach(key => {
            const value = filters[key];
            if (value !== undefined && value !== '') {
                // Similar to search, build where clauses
                 switch (key) {
                    case 'status': whereClauses.push(`s.status = $${paramIndex++}`); queryParams.push(value); break;
                    case 'requestTypeId': whereClauses.push(`s."requestTypeId" = $${paramIndex++}`); queryParams.push(value); break;
                    case 'requesterId': whereClauses.push(`s."requesterId" = $${paramIndex++}`); queryParams.push(value); break;
                    case 'requestingUnitId': whereClauses.push(`s."requestingUnitId" = $${paramIndex++}`); queryParams.push(value); break;
                    case 'dateFrom': whereClauses.push(`s."submissionDateForSort"::date >= $${paramIndex++}`); queryParams.push(value); break;
                    case 'dateTo': whereClauses.push(`s."submissionDateForSort"::date <= $${paramIndex++}`); queryParams.push(value); break;
                    case 'amountFrom': whereClauses.push(`s.amount >= $${paramIndex++}`); queryParams.push(value); break;
                    case 'amountTo': whereClauses.push(`s.amount <= $${paramIndex++}`); queryParams.push(value); break;
                 }
            }
        });

        if (whereClauses.length > 0) {
            baseQuery += ' WHERE ' + whereClauses.join(' AND ');
        }

        const totalRequestsQuery = `SELECT COUNT(*) AS total ${baseQuery}`;
        const totalApprovedAmountQuery = `SELECT COALESCE(SUM(amount), 0) AS total ${baseQuery} ${whereClauses.length > 0 ? 'AND' : 'WHERE'} s.status = 'APPROVED'`;
        const requestsByStatusQuery = `SELECT status, COUNT(*) AS count ${baseQuery} GROUP BY status`;
        const topUnitsQuery = `SELECT "requestingUnitId", SUM(amount) AS totalAmount ${baseQuery} ${whereClauses.length > 0 ? 'AND' : 'WHERE'} s.status = 'APPROVED' GROUP BY "requestingUnitId" ORDER BY totalAmount DESC LIMIT 5`;

        try {
            const [totalRes, amountRes, statusRes, topUnitsRes] = await Promise.all([
                pool.query(totalRequestsQuery, queryParams),
                pool.query(totalApprovedAmountQuery, queryParams),
                pool.query(requestsByStatusQuery, queryParams),
                pool.query(topUnitsQuery, queryParams),
            ]);
            
            const requestsByStatus = { IN_REVIEW: 0, APPROVED: 0, REJECTED: 0 };
            statusRes.rows.forEach(row => {
                if (requestsByStatus.hasOwnProperty(row.status)) {
                    requestsByStatus[row.status] = parseInt(row.count, 10);
                }
            });

            res.json({
                totalRequests: parseInt(totalRes.rows[0].total, 10),
                totalApprovedAmount: parseFloat(amountRes.rows[0].total),
                requestsByStatus,
                topRequestingUnits: topUnitsRes.rows.map(r => ({ ...r, totalAmount: parseFloat(r.totalamount) }))
            });

        } catch (err) {
            console.error('[POST /reports/summary] DB Error:', err);
            res.status(500).json({ message: 'خطا در دریافت خلاصه گزارش', detail: err.message });
        }
    });

    // --- Special handler for creating Units to ensure unique codes ---
    app.post('/api/units', async (req, res) => {
        const client = await pool.connect();
        try {
            const { name, ...otherData } = req.body;
            if (!name || name.trim() === '') {
                return res.status(400).json({ message: 'نام واحد الزامی است' });
            }

            let baseCode = persianToEnglishKey(name) || 'UNIT';
            let finalCode = baseCode;
            let counter = 2;

            while (true) {
                const checkRes = await client.query('SELECT id FROM "units" WHERE "code" = $1', [finalCode]);
                if (checkRes.rows.length === 0) {
                    break;
                }
                finalCode = `${baseCode}_${counter++}`;
            }
            
            const createData = processBodyForDb({ ...otherData, name, code: finalCode });
            const keys = Object.keys(createData);
            const placeholders = keys.map((_, i) => `$${i + 1}`).join(',');
            const values = keys.map(key => createData[key]);

            const sql = `INSERT INTO "units" (${keys.map(k => `"${k}"`).join(',')}) VALUES (${placeholders}) RETURNING *`;
            const result = await client.query(sql, values);
            res.status(201).json(result.rows[0]);
        } catch (err) {
             console.error(`[POST /units] DB Error:`, err);
             res.status(500).json({ message: `خطا در ایجاد واحد`, detail: err.message });
        } finally {
            client.release();
        }
    });

    // --- Universal CRUD Handlers ---
    const collections = ['persons', 'units', 'projects', 'debitCards', 'roles', 'workflows', 'requestCategories', 'internalWorkflows', 'securitySettings', 'expenseReports', 'contracts'];
    
    collections.forEach(collection => {
        // GET (all with pagination and search)
        app.get(`/api/${collection}`, async (req, res) => {
            const page = parseInt(req.query.page || '1', 10);
            const limit = req.query._nopagination ? 1000 : 20;
            const offset = (page - 1) * limit;
            const q = req.query.q;

            const filters = { ...req.query };
            delete filters.page;
            delete filters.q;
            delete filters._nopagination;

            let whereClauses = [];
            let queryParams = [];
            let paramIndex = 1;
            
            const tablePrefix = collection === 'persons' ? 'p' : `"${collection}"`;

            if (q) {
                const searchableFields = collection === 'persons' ? ['"fullName"', '"nationalId"'] : ['name'];
                const searchClauses = searchableFields.map(field => `CAST(${tablePrefix}.${field} AS TEXT) ILIKE $${paramIndex}`);
                whereClauses.push(`(${searchClauses.join(' OR ')})`);
                queryParams.push(`%${q}%`);
                paramIndex++;
            }
            
            const filterEntries = Object.entries(filters);
            
             // Special permission check for Petty Cash Management page
            if (collection === 'persons' && filters.roleId && filters.actingUserId) {
                try {
                    const userRes = await pool.query('SELECT "unitId", "roleIds" FROM "persons" WHERE id = $1', [filters.actingUserId]);
                    const actingUser = userRes.rows[0];
                    if (!actingUser) return res.status(403).json({ message: "کاربر اقدام کننده یافت نشد." });

                    const permsRes = await pool.query('SELECT permissions FROM roles WHERE id = ANY($1)', [actingUser.roleIds || []]);
                    const userPermissions = new Set(permsRes.rows.flatMap(r => r.permissions));

                    if (userPermissions.has('PETTY_CASH_MANAGEMENT:read_all')) {
                        // No extra filter needed
                    } else if (userPermissions.has('PETTY_CASH_MANAGEMENT:read_own_unit')) {
                        whereClauses.push(`${tablePrefix}."unitId" = $${paramIndex++}`);
                        queryParams.push(actingUser.unitId);
                    } else {
                        whereClauses.push('1=0'); // No permission, return no results
                    }
                } catch (err) {
                    return res.status(500).json({ message: 'خطا در بررسی دسترسی', detail: err.message });
                }
            }

            for (const [key, value] of filterEntries) {
                 if (key === 'actingUserId') continue; // Skip as it's for permission checks

                if (collection === 'persons' && key === 'hasUnit') {
                    whereClauses.push(`${tablePrefix}."unitId" IS ${String(value) === 'true' ? 'NOT NULL' : 'NULL'}`);
                } else if (collection === 'persons' && key === 'roleId') {
                    whereClauses.push(`CAST(${tablePrefix}."roleIds" AS JSONB) @> $${paramIndex++}::jsonb`);
                    queryParams.push(JSON.stringify([Number(value)]));
                }
                else {
                    whereClauses.push(`${tablePrefix}."${key}" = $${paramIndex++}`);
                    queryParams.push(value);
                }
            }

            const executeQuery = async () => {
                let whereClause = whereClauses.length > 0 ? ' WHERE ' + whereClauses.join(' AND ') : '';
                
                let dataQuery, countQuery;
                
                const countParams = [...queryParams];
                
                let limitOffsetParams = [];
                if (!req.query._nopagination) {
                    limitOffsetParams = [limit, offset];
                }
                const finalQueryParams = [...queryParams, ...limitOffsetParams];


                if (collection === 'persons') {
                    const baseQuery = `FROM "persons" p ${whereClause}`;
                    countQuery = `SELECT COUNT(*) ${baseQuery}`;
                    dataQuery = `
                        SELECT 
                            p.*, 
                            u.name AS "unitName"
                        FROM "persons" p
                        LEFT JOIN "units" u ON p."unitId" = u.id
                        ${whereClause}
                        ORDER BY p.id DESC 
                        ${req.query._nopagination ? '' : `LIMIT $${paramIndex++} OFFSET $${paramIndex++}`}
                    `;
                } else {
                    let selectClause = `SELECT "${collection}".*`;
                    let joinClause = '';
                     if (collection === 'expenseReports') {
                        selectClause += `, p."fullName" as "pettyCashHolderName"`;
                        joinClause = ` LEFT JOIN "persons" p ON "${collection}"."pettyCashHolderId" = p.id`;
                    }
                    if (collection === 'contracts') {
                        selectClause += `, p."fullName" as "partyName"`;
                        joinClause = ` LEFT JOIN "persons" p ON "${collection}"."partyId" = p.id`;
                    }
                    const baseQuery = `FROM "${collection}" ${joinClause} ${whereClause}`;
                    countQuery = `SELECT COUNT(*) ${baseQuery}`;
                    dataQuery = `${selectClause} ${baseQuery} ORDER BY id DESC ${req.query._nopagination ? '' : `LIMIT $${paramIndex++} OFFSET $${paramIndex++}`}`;
                }

                try {
                    const [dataRes, totalRes] = await Promise.all([
                        pool.query(dataQuery, finalQueryParams),
                        pool.query(countQuery, countParams)
                    ]);
                    
                    // Add roleNames to persons after the main query
                    if(collection === 'persons') {
                      const roleRes = await pool.query('SELECT id, name FROM roles');
                      const roleMap = new Map(roleRes.rows.map(r => [r.id, r.name]));
                      dataRes.rows.forEach(person => {
                        if (person.roleIds && Array.isArray(person.roleIds)) {
                          person.roleNames = person.roleIds.map(id => roleMap.get(id)).filter(Boolean);
                        } else {
                          person.roleNames = [];
                        }
                      });
                    }

                    const finalData = dataRes.rows.map(row => {
                        if (row.pettyCashLimit) row.pettyCashLimit = parseFloat(row.pettyCashLimit);
                        if (row.pettyCashBalance) row.pettyCashBalance = parseFloat(row.pettyCashBalance);
                        return row;
                    });

                    res.json({
                        data: finalData,
                        total: parseInt(totalRes.rows[0].count, 10),
                    });
                } catch (err) {
                    console.error(`[GET /${collection}] DB Error:`, err);
                    res.status(500).json({ message: `خطا در دریافت اطلاعات ${collection}`, detail: err.message });
                }
            };

            await executeQuery();
        });

        // POST (create new)
        app.post(`/api/${collection}`, async (req, res) => {
            try {
                const { actingUserId, ...dataToProcess } = req.body;

                // Special handling for persons with petty cash limits, needs permission check
                if (collection === 'persons') {
                    const hasPettyCashRole = dataToProcess.roleIds?.includes(15);
                    if (hasPettyCashRole) {
                         if (!actingUserId) {
                            return res.status(401).json({ message: 'شناسه کاربر برای بررسی مجوزها ارسال نشده است.' });
                         }
                         try {
                            const userRes = await pool.query('SELECT "roleIds" FROM "persons" WHERE id = $1', [actingUserId]);
                            if (userRes.rows.length === 0) throw new Error("کاربر اقدام کننده نامعتبر است.");
                            
                            const roleIds = userRes.rows[0].roleIds || [];
                            const permsRes = await pool.query('SELECT permissions FROM roles WHERE id = ANY($1)', [roleIds]);
                            const userPermissions = new Set(permsRes.rows.flatMap(r => r.permissions));

                            if (!userPermissions.has('PETTY_CASH_MANAGEMENT:update')) {
                                return res.status(403).json({ message: 'شما دسترسی لازم برای تخصیص اعتبار تنخواه را ندارید.' });
                            }
                         } catch(err) {
                            return res.status(500).json({ message: 'خطا در بررسی دسترسی', detail: err.message });
                         }
                    }
                }
                
                const createData = processBodyForDb(dataToProcess);
                const keys = Object.keys(createData);
                const placeholders = keys.map((_, i) => `$${i + 1}`).join(',');
                const values = keys.map(key => createData[key]);

                const sql = `INSERT INTO "${collection}" (${keys.map(k => `"${k}"`).join(',')}) VALUES (${placeholders}) RETURNING *`;
                const result = await pool.query(sql, values);
                res.status(201).json(result.rows[0]);
            } catch (err) {
                 console.error(`[POST /${collection}] DB Error:`, err);
                 res.status(500).json({ message: `خطا در ایجاد ${collection}`, detail: err.message });
            }
        });

        // PUT (update by id)
        app.put(`/api/${collection}/:id`, async (req, res) => {
            const { id } = req.params;
            const { actingUserId, ...updateData } = req.body;
            
            if (collection === 'persons') {
                const hasPettyCashRole = updateData.roleIds?.includes(15);
                if (hasPettyCashRole) {
                     if (!actingUserId) return res.status(401).json({ message: 'شناسه کاربر برای بررسی مجوزها ارسال نشده است.' });
                     try {
                        const userRes = await pool.query('SELECT "roleIds" FROM "persons" WHERE id = $1', [actingUserId]);
                        const roleIds = userRes.rows[0]?.roleIds || [];
                        const permsRes = await pool.query('SELECT permissions FROM roles WHERE id = ANY($1)', [roleIds]);
                        const userPermissions = new Set(permsRes.rows.flatMap(r => r.permissions));
                        if (!userPermissions.has('PETTY_CASH_MANAGEMENT:update')) {
                            return res.status(403).json({ message: 'شما دسترسی لازم برای تغییر اعتبار تنخواه را ندارید.' });
                        }
                     } catch(err) {
                        return res.status(500).json({ message: 'خطا در بررسی دسترسی', detail: err.message });
                     }
                }
            }

            try {
                const finalUpdateData = processBodyForDb(updateData);
                const keys = Object.keys(finalUpdateData);
                const setString = keys.map((key, i) => `"${key}" = $${i + 1}`).join(',');
                const values = keys.map(key => finalUpdateData[key]);
                
                const sql = `UPDATE "${collection}" SET ${setString} WHERE id = $${keys.length + 1} RETURNING *`;
                const result = await pool.query(sql, [...values, id]);
                res.json(result.rows[0]);
            } catch (err) {
                console.error(`[PUT /${collection}] DB Error:`, err);
                res.status(500).json({ message: `خطا در به‌روزرسانی ${collection}`, detail: err.message });
            }
        });

        // DELETE (by id)
        app.delete(`/api/${collection}/:id`, async (req, res) => {
            const { id } = req.params;
            try {
                await pool.query(`DELETE FROM "${collection}" WHERE id = $1`, [id]);
                res.status(204).send();
            } catch (err) {
                 console.error(`[DELETE /${collection}] DB Error:`, err);
                 res.status(500).json({ message: `خطا در حذف ${collection}`, detail: err.message });
            }
        });
    });

    // --- Serve React App for all other routes ---
    app.get('*', (req, res) => {
        res.sendFile(path.join(__dirname, '..', 'index.html'));
    });

    // --- Start Server ---
    const PORT = process.env.PORT || 4000;
    app.listen(PORT, '0.0.0.0', () => {
        console.log(`\x1b[36m%s\x1b[0m`, `Server is running on http://localhost:${PORT}`);
    });
};

startServer();